"""Stratify the complete RT2 audit by geometry distortion and cluster-bootstrap its median."""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
R=ROOT/'experiments'/'results'
ROWS=R/'independent_forcing_multicheckpoint_rt2_rows.csv'
REPORT=R/'independent_forcing_certificate_robustness.json'
TABLE=ROOT/'paper'/'tables'/'independent_forcing_geometry_robustness.tex'

def q(x,p): return float(np.quantile(np.asarray(x,dtype=float),p))

def main():
    df=pd.read_csv(ROWS)
    assert len(df)==270 and bool(df['covered'].all())
    # Geometry is the sampling unit; each cluster contains the three checkpoints.
    clusters=list(df.groupby(['split','geometry_id'],sort=True))
    assert len(clusters)==90 and all(len(g)==3 for _,g in clusters)
    rng=np.random.default_rng(20260803)
    boot=[]
    for _ in range(5000):
        idx=rng.integers(0,len(clusters),len(clusters))
        values=np.concatenate([clusters[i][1]['effectivity'].to_numpy(float) for i in idx])
        boot.append(float(np.median(values)))
    labels=['most distorted','middle','least distorted']
    df['distortion_tercile']=pd.qcut(df['minimum_jacobian_ratio'],3,labels=labels)
    bins=[]
    for label,g in df.groupby('distortion_tercile',observed=True,sort=False):
        bins.append({
            'tercile':str(label),'cases':len(g),
            'jacobian_min':float(g['minimum_jacobian_ratio'].min()),
            'jacobian_max':float(g['minimum_jacobian_ratio'].max()),
            'effectivity_median':float(g['effectivity'].median()),
            'effectivity_q95':q(g['effectivity'],.95),
            'effectivity_max':float(g['effectivity'].max()),
            'max_relative_linear_residual':float(g['relative_linear_residual'].max()),
        })
    report={
        'status':'PASS','cases':270,'geometry_clusters':90,
        'effectivity_median':float(df['effectivity'].median()),
        'cluster_bootstrap_95':{'draws':5000,'lower':q(boot,.025),'upper':q(boot,.975)},
        'minimum_jacobian_ratio_range':[float(df['minimum_jacobian_ratio'].min()),float(df['minimum_jacobian_ratio'].max())],
        'distortion_terciles':bins,
    }
    REPORT.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    display={'most distorted':'Most distorted','middle':'Middle','least distorted':'Least distorted'}
    lines=[
      r'\begin{table}[H]',
      r'\caption{Certificate behavior across geometry-distortion terciles in the complete 270-pair audit. The distortion statistic is the minimum oriented element-Jacobian ratio; smaller values indicate stronger deformation. The bins are descriptive and were not used for model or certificate selection.}',
      r'\label{tab:geometry-robustness}',r'\centering\small',
      r'\begin{tabular}{lrrrrrr}',r'\toprule',
      r'Tercile & Cases & Jacobian-ratio range & Median eff. & 95\% eff. & Max eff. & Max rel. residual \\',r'\midrule']
    for d in bins:
      lines.append(f"{display[d['tercile']]} & {d['cases']} & [{d['jacobian_min']:.3f}, {d['jacobian_max']:.3f}] & {d['effectivity_median']:.3f} & {d['effectivity_q95']:.3f} & {d['effectivity_max']:.3f} & {d['max_relative_linear_residual']:.1e} " + r"\\")
    lines += [r'\bottomrule',r'\end{tabular}',r'\end{table}']
    TABLE.write_text('\n'.join(lines)+'\n')
    print(f"CERTIFICATE_ROBUSTNESS_OK cluster_CI=[{report['cluster_bootstrap_95']['lower']:.3f},{report['cluster_bootstrap_95']['upper']:.3f}]")
if __name__=='__main__': main()
