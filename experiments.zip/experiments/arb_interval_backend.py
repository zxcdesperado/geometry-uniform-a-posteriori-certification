"""Arb-backed adapter for the machine RT interval algorithm.

The production enclosure algorithm is shared deliberately so that this audit
isolates the arithmetic backend.  ``python-flint`` supplies Arb balls for every
basic operation, square root, sine, cosine, and pi evaluation.  IEEE-754 input
floats are first converted to their exact rational values.
"""

from __future__ import annotations

import math
from contextlib import contextmanager
from typing import Any, Iterator

import numpy as np
from flint import arb, ctx, fmpq


def _rational(value: float | int | np.integer) -> fmpq:
    if isinstance(value, (int, np.integer)):
        return fmpq(int(value), 1)
    numerator, denominator = float(value).as_integer_ratio()
    return fmpq(numerator, denominator)


class ArbIVAdapter:
    """Small subset of the ``mpmath.iv`` interface used by the RT audit."""

    backend_label = "python-flint Arb balls with outward binary64 endpoints"

    @property
    def dps(self) -> int:
        return int(ctx.dps)

    @dps.setter
    def dps(self, value: int) -> None:
        ctx.dps = int(value)

    @property
    def pi(self) -> arb:
        return arb.pi()

    @staticmethod
    def mpf(value: Any) -> arb:
        if isinstance(value, arb):
            return value
        if isinstance(value, (list, tuple)) and len(value) == 2:
            lower = _rational(value[0])
            upper = _rational(value[1])
            if upper < lower:
                raise ValueError("invalid interval endpoints")
            return arb(lower).union(arb(upper))
        return arb(_rational(value))

    @staticmethod
    def sqrt(value: Any) -> arb:
        interval = arb(value)
        if interval.upper() < 0:
            raise ValueError("square root requested for a negative Arb ball")
        if interval.lower() < 0:
            # Every square-root argument in the enclosure engine is known
            # analytically to be nonnegative (a squared norm, discriminant,
            # or eigenvalue).  Ball dependency can nevertheless make the
            # represented lower endpoint slightly negative.  Intersect with
            # the proven domain [0,+inf) before applying sqrt.
            return arb(0).union(interval.upper().sqrt())
        return interval.sqrt()

    @staticmethod
    def sin(value: Any) -> arb:
        return arb(value).sin()

    @staticmethod
    def cos(value: Any) -> arb:
        return arb(value).cos()


def lower(value: arb) -> float:
    """Return a binary64 endpoint rounded beyond the Arb lower ball."""
    return math.nextafter(float(value.lower()), -math.inf)


def upper(value: arb) -> float:
    """Return a binary64 endpoint rounded beyond the Arb upper ball."""
    return math.nextafter(float(value.upper()), math.inf)


@contextmanager
def use_arb_backend(engine: Any) -> Iterator[None]:
    """Temporarily route one enclosure module through python-flint/Arb."""
    old_iv = engine.iv
    old_lower = engine._lower
    old_upper = engine._upper
    engine.iv = ArbIVAdapter()
    engine._lower = lower
    engine._upper = upper
    try:
        yield
    finally:
        engine.iv = old_iv
        engine._lower = old_lower
        engine._upper = old_upper
