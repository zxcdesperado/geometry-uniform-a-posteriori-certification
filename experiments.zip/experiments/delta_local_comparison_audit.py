"""Audit the sharp elementwise comparison for the Riesz residual density."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import sys
from pathlib import Path

import numpy as np

sys.dont_write_bytecode = True
SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from independent_flux_audit import (
    affine_matrices,
    assemble_dirichlet_problem_vectorized,
    build_mesh,
    coefficient,
    element_geometry,
    exact_reference_gradient,
    is_dirichlet_node,
    prediction_perturbation,
    solve_problem,
    triangle_rule,
)


def local_energy_norms(mesh, contrast: float, prediction: np.ndarray, fe: np.ndarray):
    _, gradients, areas = element_geometry(mesh)
    elements = mesh.elements
    reference = mesh.reference_nodes[elements]
    pred_grad = np.einsum("ti,tij->tj", prediction[elements], gradients)
    fe_grad = np.einsum("ti,tij->tj", fe[elements], gradients)
    rho_grad = fe_grad - pred_grad
    delta_squared = np.zeros(len(elements))
    true_squared = np.zeros(len(elements))
    fe_squared = np.zeros(len(elements))
    _, inverse_transpose = affine_matrices(mesh)
    for weight, barycentric in triangle_rule():
        bary = np.asarray(barycentric)
        points = np.einsum("i,eid->ed", bary, reference)
        exact_grad = exact_reference_gradient(points) @ inverse_transpose.T
        material = coefficient(points, contrast)
        scale = weight * areas * material
        delta_squared += scale * np.sum(rho_grad * rho_grad, axis=1)
        true_squared += scale * np.sum((exact_grad - pred_grad) ** 2, axis=1)
        fe_squared += scale * np.sum((exact_grad - fe_grad) ** 2, axis=1)
    return np.sqrt(delta_squared), np.sqrt(true_squared), np.sqrt(fe_squared)


def run(config: dict[str, object]) -> tuple[dict[str, object], list[dict[str, object]]]:
    rows: list[dict[str, object]] = []
    tolerance = 5.0e-12
    for n in config["levels"]:
        for geometry in config["geometries"]:
            mesh = build_mesh(n, geometry["shear"], geometry["stretch"])
            for contrast in config["contrasts"]:
                matrix, load = assemble_dirichlet_problem_vectorized(mesh, contrast)
                fe = solve_problem(matrix, load, is_dirichlet_node(mesh, "dirichlet"))
                for amplitude in config["perturbation_amplitudes"]:
                    prediction = fe + prediction_perturbation(mesh, amplitude)
                    delta, true_error, fe_error = local_energy_norms(
                        mesh, contrast, prediction, fe
                    )
                    violation = np.maximum(np.abs(delta - true_error) - fe_error, 0.0)
                    relative_gap = np.abs(delta - true_error) / np.maximum(fe_error, 1.0e-30)
                    rows.append(
                        {
                            "n": n,
                            "shear": geometry["shear"],
                            "stretch": geometry["stretch"],
                            "contrast": contrast,
                            "amplitude": amplitude,
                            "elements": len(mesh.elements),
                            "max_absolute_violation": float(np.max(violation)),
                            "max_reverse_triangle_ratio": float(np.max(relative_gap)),
                            "median_delta_over_true": float(
                                np.median(delta / np.maximum(true_error, 1.0e-30))
                            ),
                            "all_elements_pass": bool(np.max(violation) <= tolerance),
                        }
                    )
    summary = {
        "protocol": config["protocol"],
        "case_count": len(rows),
        "element_comparison_count": int(sum(row["elements"] for row in rows)),
        "all_cases_pass": all(row["all_elements_pass"] for row in rows),
        "max_absolute_violation": max(row["max_absolute_violation"] for row in rows),
        "max_reverse_triangle_ratio": max(
            row["max_reverse_triangle_ratio"] for row in rows
        ),
        "claim_scope": config["claim_scope"],
        "quadrature": config["quadrature"],
    }
    return summary, rows


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--config",
        type=Path,
        default=Path("experiments/configs/delta_local_comparison_prespecified_2026-08-01.json"),
    )
    parser.add_argument(
        "--summary-out",
        type=Path,
        default=Path("experiments/results/delta_local_comparison_summary.json"),
    )
    parser.add_argument(
        "--rows-out",
        type=Path,
        default=Path("experiments/results/delta_local_comparison_rows.csv"),
    )
    args = parser.parse_args()
    raw_config = args.config.read_bytes()
    config = json.loads(raw_config)
    summary, rows = run(config)
    summary["config_sha256"] = hashlib.sha256(raw_config).hexdigest()
    if not summary["all_cases_pass"]:
        raise AssertionError("local comparison audit failed")
    args.summary_out.parent.mkdir(parents=True, exist_ok=True)
    args.summary_out.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    with args.rows_out.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
