"""Predeclared machine-rigorous affine-geometry mixed-elasticity suite."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import sys
from fractions import Fraction
from pathlib import Path

sys.dont_write_bytecode = True
SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from elasticity_machine_strict_mixed_interval import build_result


def parse_fraction(value: str) -> Fraction:
    return Fraction(value)


def run_suite(config: dict[str, object]) -> tuple[dict[str, object], list[dict[str, object]]]:
    alpha = parse_fraction(str(config["alpha"]))
    beta = parse_fraction(str(config["beta"]))
    mu = parse_fraction(str(config["mu"]))
    rows: list[dict[str, object]] = []
    all_checks = True
    for geometry in config["geometries"]:
        jacobian = tuple(
            tuple(parse_fraction(str(value)) for value in row)
            for row in geometry["jacobian"]
        )
        for lambda_text in config["lambda_values"]:
            lame_lambda = parse_fraction(str(lambda_text))
            result = build_result(
                alpha,
                beta,
                lame_lambda,
                mu,
                jacobian,
                str(geometry["name"]),
            )
            checks_pass = all(bool(value) for value in result["checks"].values())
            all_checks = all_checks and checks_pass
            rows.append(
                {
                    "geometry": geometry["name"],
                    "lambda": str(lame_lambda),
                    "mu": str(mu),
                    "lambda_over_mu": float(lame_lambda / mu),
                    "determinant": result["geometry"]["determinant"],
                    "energy_squared_fraction": result["energy_norm_squared_fraction"],
                    "primal_majorant_upper": result["primal_majorant_enclosure"]["upper_decimal_outward"],
                    "goal_radius_upper": result["goal_radius_enclosure"]["upper_decimal_outward"],
                    "qoi_interval_lower": result["certified_qoi_interval"]["lower_decimal_outward"],
                    "qoi_interval_upper": result["certified_qoi_interval"]["upper_decimal_outward"],
                    "all_checks_pass": checks_pass,
                }
            )
    summary = {
        "protocol": config["protocol"],
        "case_count": len(rows),
        "geometry_count": len(config["geometries"]),
        "lambda_over_mu_min": min(row["lambda_over_mu"] for row in rows),
        "lambda_over_mu_max": max(row["lambda_over_mu"] for row in rows),
        "all_machine_checks_pass": all_checks,
        "arithmetic": "exact rational polynomial integration plus rational bisection enclosures",
        "quadrature": "none",
        "claim_scope": config["claim_scope"],
        "non_claim": (
            "This does not make the inexpensive non-equilibrated recovered stress "
            "machine-rigorous and is not a heterogeneous-coefficient robustness test."
        ),
    }
    return summary, rows


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--config",
        type=Path,
        default=Path("experiments/configs/elasticity_machine_strict_affine_suite_2026-08-01.json"),
    )
    parser.add_argument(
        "--summary-out",
        type=Path,
        default=Path("experiments/results/elasticity_machine_strict_affine_suite_summary.json"),
    )
    parser.add_argument(
        "--rows-out",
        type=Path,
        default=Path("experiments/results/elasticity_machine_strict_affine_suite_rows.csv"),
    )
    args = parser.parse_args()
    raw_config = args.config.read_bytes()
    config = json.loads(raw_config)
    summary, rows = run_suite(config)
    summary["config_sha256"] = hashlib.sha256(raw_config).hexdigest()
    if not summary["all_machine_checks_pass"]:
        raise AssertionError("at least one affine elasticity case failed")
    args.summary_out.parent.mkdir(parents=True, exist_ok=True)
    args.summary_out.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    with args.rows_out.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
