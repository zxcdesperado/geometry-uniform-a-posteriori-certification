"""Machine-rigorous mixed-boundary elasticity hypercircle example.

The displacement is the polynomial manufactured field already used by the
project.  The exact symmetric stress is treated as a statically admissible
stress: its divergence defines the body force and its normal trace defines the
Neumann traction.  Consequently the guaranteed majorant contains only the
constitutive mismatch and needs neither Korn nor trace constants.

This validates the exactly equilibrated branch.  It does not claim that the
project's inexpensive recovered stress is exactly equilibrated.
"""

from __future__ import annotations

import argparse
import csv
import json
import sys
from fractions import Fraction
from pathlib import Path
from typing import TypeAlias

sys.dont_write_bytecode = True
SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from poisson_machine_strict_interval import Interval, interval_mul, interval_record


Polynomial: TypeAlias = dict[tuple[int, int], Fraction]


def poly_add(*polynomials: Polynomial) -> Polynomial:
    result: Polynomial = {}
    for polynomial in polynomials:
        for power, coefficient in polynomial.items():
            result[power] = result.get(power, Fraction(0)) + coefficient
    return {power: value for power, value in result.items() if value}


def poly_scale(polynomial: Polynomial, factor: Fraction) -> Polynomial:
    return {power: factor * value for power, value in polynomial.items() if factor * value}


def poly_multiply(first: Polynomial, second: Polynomial) -> Polynomial:
    result: Polynomial = {}
    for (first_x, first_y), first_value in first.items():
        for (second_x, second_y), second_value in second.items():
            power = (first_x + second_x, first_y + second_y)
            result[power] = result.get(power, Fraction(0)) + first_value * second_value
    return {power: value for power, value in result.items() if value}


def poly_derivative(polynomial: Polynomial, axis: int) -> Polynomial:
    result: Polynomial = {}
    for powers, value in polynomial.items():
        exponent = powers[axis]
        if exponent == 0:
            continue
        new_power = list(powers)
        new_power[axis] -= 1
        result[tuple(new_power)] = value * exponent
    return result


def poly_integral_unit_square(polynomial: Polynomial) -> Fraction:
    return sum(
        value / Fraction(power_x + 1) / Fraction(power_y + 1)
        for (power_x, power_y), value in polynomial.items()
    )


def square_integral(polynomial: Polynomial) -> Fraction:
    return poly_integral_unit_square(poly_multiply(polynomial, polynomial))


def sqrt_fraction_interval(value: Fraction, steps: int = 512) -> Interval:
    if value < 0:
        raise ValueError("cannot enclose a negative square root")
    if value == 0:
        return Fraction(0), Fraction(0)
    lower = Fraction(0)
    upper = max(Fraction(1), value)
    while upper * upper < value:
        upper *= 2
    for _ in range(steps):
        midpoint = (lower + upper) / 2
        if midpoint * midpoint < value:
            lower = midpoint
        else:
            upper = midpoint
    return lower, upper


def displacement_polynomials() -> tuple[Polynomial, Polynomial]:
    u1 = {
        (2, 0): Fraction(1, 5),
        (2, 1): Fraction(1, 10),
        (2, 2): Fraction(1, 20),
    }
    u2 = {
        (2, 0): Fraction(2, 5),
        (2, 1): Fraction(1, 5),
        (3, 1): Fraction(1, 20),
        (3, 2): Fraction(-1, 20),
    }
    return u1, u2


def exact_energy_squared_affine(
    lame_lambda: Fraction,
    lame_mu: Fraction,
    jacobian: tuple[tuple[Fraction, Fraction], tuple[Fraction, Fraction]],
) -> Fraction:
    """Integrate physical elastic energy after an exact affine pullback."""
    (j11, j12), (j21, j22) = jacobian
    determinant = j11 * j22 - j12 * j21
    if determinant <= 0:
        raise ValueError("the affine geometry must have positive determinant")
    inverse = (
        (j22 / determinant, -j12 / determinant),
        (-j21 / determinant, j11 / determinant),
    )
    u1, u2 = displacement_polynomials()
    du1_dxi = poly_derivative(u1, 0)
    du1_deta = poly_derivative(u1, 1)
    du2_dxi = poly_derivative(u2, 0)
    du2_deta = poly_derivative(u2, 1)
    du1_dx = poly_add(
        poly_scale(du1_dxi, inverse[0][0]),
        poly_scale(du1_deta, inverse[1][0]),
    )
    du1_dy = poly_add(
        poly_scale(du1_dxi, inverse[0][1]),
        poly_scale(du1_deta, inverse[1][1]),
    )
    du2_dx = poly_add(
        poly_scale(du2_dxi, inverse[0][0]),
        poly_scale(du2_deta, inverse[1][0]),
    )
    du2_dy = poly_add(
        poly_scale(du2_dxi, inverse[0][1]),
        poly_scale(du2_deta, inverse[1][1]),
    )
    epsilon_11 = du1_dx
    epsilon_22 = du2_dy
    epsilon_12 = poly_scale(
        poly_add(du1_dy, du2_dx),
        Fraction(1, 2),
    )
    trace = poly_add(epsilon_11, epsilon_22)
    strain_contraction = (
        square_integral(epsilon_11)
        + square_integral(epsilon_22)
        + 2 * square_integral(epsilon_12)
    )
    return determinant * (
        lame_lambda * square_integral(trace) + 2 * lame_mu * strain_contraction
    )


def exact_energy_squared(lame_lambda: Fraction, lame_mu: Fraction) -> Fraction:
    return exact_energy_squared_affine(
        lame_lambda,
        lame_mu,
        ((Fraction(1), Fraction(0)), (Fraction(0), Fraction(1))),
    )


def interval_add(first: Interval, second: Interval) -> Interval:
    return first[0] + second[0], first[1] + second[1]


def interval_scale(interval: Interval, factor: Fraction) -> Interval:
    if factor < 0:
        return factor * interval[1], factor * interval[0]
    return factor * interval[0], factor * interval[1]


def build_result(
    alpha: Fraction,
    beta: Fraction,
    lame_lambda: Fraction,
    lame_mu: Fraction,
    jacobian: tuple[tuple[Fraction, Fraction], tuple[Fraction, Fraction]] = (
        (Fraction(1), Fraction(0)),
        (Fraction(0), Fraction(1)),
    ),
    geometry_name: str = "unit_square",
) -> dict[str, object]:
    if not 0 < alpha < 1 or not 0 < beta < 1:
        raise ValueError("alpha and beta must lie in (0,1)")
    if lame_lambda <= 0 or lame_mu <= 0:
        raise ValueError("Lame parameters must be positive")
    determinant = (
        jacobian[0][0] * jacobian[1][1]
        - jacobian[0][1] * jacobian[1][0]
    )
    if determinant <= 0:
        raise ValueError("the affine geometry must have positive determinant")
    energy_squared = exact_energy_squared_affine(lame_lambda, lame_mu, jacobian)
    energy_norm = sqrt_fraction_interval(energy_squared)
    primal_factor = 1 - alpha
    adjoint_factor = 1 - beta
    primal_majorant = interval_scale(energy_norm, primal_factor)
    adjoint_majorant = interval_scale(energy_norm, adjoint_factor)
    primal_true = primal_majorant
    adjoint_true = adjoint_majorant

    exact_qoi: Interval = (energy_squared, energy_squared)
    reconstructed_qoi = interval_scale(exact_qoi, alpha)
    true_goal_error = interval_scale(exact_qoi, primal_factor)
    discrete_residual = interval_scale(exact_qoi, beta * primal_factor)
    product = interval_mul(primal_majorant, adjoint_majorant)
    goal_radius = interval_add(discrete_residual, product)
    qoi_interval = (
        reconstructed_qoi[0] - goal_radius[1],
        reconstructed_qoi[1] + goal_radius[1],
    )
    checks = {
        "positive_exact_energy": energy_squared > 0,
        "primal_majorant_covers": primal_majorant[1] >= primal_true[1],
        "adjoint_majorant_covers": adjoint_majorant[1] >= adjoint_true[1],
        "goal_radius_covers": goal_radius[1] >= true_goal_error[1],
        "qoi_interval_contains_exact": qoi_interval[0] <= energy_squared <= qoi_interval[1],
        "exact_factor_identity": (
            beta * primal_factor + primal_factor * adjoint_factor == primal_factor
        ),
    }
    return {
        "benchmark": "machine_rigorous_mixed_boundary_elasticity_hypercircle",
        "domain": f"rational affine image of unit square ({geometry_name})",
        "geometry": {
            "name": geometry_name,
            "jacobian": [[str(value) for value in row] for row in jacobian],
            "determinant": str(determinant),
            "map": "x=J*xi; no translation (translation would not affect the proof)",
        },
        "boundary_conditions": (
            "clamped image of xi=0; exact manufactured traction on the remaining boundary"
        ),
        "constitutive_model": {
            "type": "two-dimensional isotropic linear elasticity",
            "lambda": str(lame_lambda),
            "mu": str(lame_mu),
        },
        "reconstructions": {
            "primal": f"v=({alpha})u",
            "adjoint": f"z_h=({beta})u",
        },
        "admissible_stress": (
            "tau=C epsilon(u) is symmetric, polynomial, H(div), satisfies "
            "div(tau)+f=0, and has tau*n=g on Gamma_N by the manufactured data definitions"
        ),
        "majorant": (
            "Because tau is exactly statically admissible, only the compliance-norm "
            "constitutive mismatch remains; no Korn or trace constant is used."
        ),
        "arithmetic": "exact Fraction polynomial integration and rational square-root bisection",
        "quadrature": "none",
        "linear_solver_error": "none",
        "geometry_error": "none; the rational affine pullback is evaluated exactly",
        "energy_norm_squared_fraction": f"{energy_squared.numerator}/{energy_squared.denominator}",
        "energy_norm_enclosure": interval_record(energy_norm),
        "primal_majorant_enclosure": interval_record(primal_majorant),
        "adjoint_majorant_enclosure": interval_record(adjoint_majorant),
        "exact_qoi_enclosure": interval_record(exact_qoi),
        "true_goal_error_enclosure": interval_record(true_goal_error),
        "discrete_adjoint_residual_enclosure": interval_record(discrete_residual),
        "primal_dual_product_enclosure": interval_record(product),
        "goal_radius_enclosure": interval_record(goal_radius),
        "certified_qoi_interval": interval_record(qoi_interval),
        "checks": checks,
        "claim_scope": (
            "This closes an exactly equilibrated mixed-elasticity branch. It does "
            "not certify the inexpensive non-equilibrated recovered stress used "
            "in the broader floating experiments."
        ),
        "practical_recovered_stress_status": (
            "not machine-rigorous and not a strict continuous-PDE elasticity "
            "certificate; reported only as a residual diagnostic unless explicit "
            "Korn/trace constants and enclosed equilibrium residuals are supplied"
        ),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--alpha-numerator", type=int, default=7)
    parser.add_argument("--alpha-denominator", type=int, default=10)
    parser.add_argument("--beta-numerator", type=int, default=3)
    parser.add_argument("--beta-denominator", type=int, default=5)
    parser.add_argument("--lambda-numerator", type=int, default=2)
    parser.add_argument("--lambda-denominator", type=int, default=1)
    parser.add_argument("--mu-numerator", type=int, default=1)
    parser.add_argument("--mu-denominator", type=int, default=1)
    parser.add_argument("--j11-numerator", type=int, default=1)
    parser.add_argument("--j11-denominator", type=int, default=1)
    parser.add_argument("--j12-numerator", type=int, default=0)
    parser.add_argument("--j12-denominator", type=int, default=1)
    parser.add_argument("--j21-numerator", type=int, default=0)
    parser.add_argument("--j21-denominator", type=int, default=1)
    parser.add_argument("--j22-numerator", type=int, default=1)
    parser.add_argument("--j22-denominator", type=int, default=1)
    parser.add_argument("--geometry-name", default="unit_square")
    parser.add_argument(
        "--summary-out",
        type=Path,
        default=Path("experiments/results/elasticity_machine_strict_mixed_interval_summary.json"),
    )
    parser.add_argument(
        "--rows-out",
        type=Path,
        default=Path("experiments/results/elasticity_machine_strict_mixed_interval_rows.csv"),
    )
    args = parser.parse_args()
    result = build_result(
        Fraction(args.alpha_numerator, args.alpha_denominator),
        Fraction(args.beta_numerator, args.beta_denominator),
        Fraction(args.lambda_numerator, args.lambda_denominator),
        Fraction(args.mu_numerator, args.mu_denominator),
        (
            (
                Fraction(args.j11_numerator, args.j11_denominator),
                Fraction(args.j12_numerator, args.j12_denominator),
            ),
            (
                Fraction(args.j21_numerator, args.j21_denominator),
                Fraction(args.j22_numerator, args.j22_denominator),
            ),
        ),
        args.geometry_name,
    )
    failed = [name for name, passed in result["checks"].items() if not passed]
    if failed:
        raise AssertionError(f"strict mixed-elasticity checks failed: {failed}")
    args.summary_out.parent.mkdir(parents=True, exist_ok=True)
    args.summary_out.write_text(json.dumps(result, indent=2), encoding="utf-8")
    row = {
        "energy_norm_squared_fraction": result["energy_norm_squared_fraction"],
        "primal_majorant_upper": result["primal_majorant_enclosure"]["upper_decimal_outward"],
        "adjoint_majorant_upper": result["adjoint_majorant_enclosure"]["upper_decimal_outward"],
        "goal_radius_upper": result["goal_radius_enclosure"]["upper_decimal_outward"],
        "qoi_interval_lower": result["certified_qoi_interval"]["lower_decimal_outward"],
        "qoi_interval_upper": result["certified_qoi_interval"]["upper_decimal_outward"],
        **result["checks"],
    }
    with args.rows_out.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(row))
        writer.writeheader()
        writer.writerow(row)
    print(json.dumps(result["checks"], indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
