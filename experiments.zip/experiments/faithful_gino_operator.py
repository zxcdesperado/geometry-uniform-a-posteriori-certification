"""A geometry-informed neural operator with integral transforms and an FNO core.

This is a faithful, compact implementation of the defining GINO composition:

    physical point cloud --kernel integral--> latent regular grid
    --Fourier operator--> latent regular grid
    --kernel integral--> physical point cloud.

It is not labelled an official upstream implementation.  Unlike the earlier
``GINO-style`` graph network, geometry enters both learned integral kernels and
the physical coordinates used by the encoder/decoder, while the latent operator
is a genuine spectral Fourier neural operator.
"""

from __future__ import annotations

import math

import torch

from poisson_grid_fno_operator_certification import FNOBlock


class KernelIntegralTransform(torch.nn.Module):
    """Normalized Gaussian-localized learned integral transform."""

    def __init__(
        self,
        source_channels: int,
        output_channels: int,
        hidden_channels: int,
        sigma: float,
    ) -> None:
        super().__init__()
        self.sigma = float(sigma)
        # source features, source/target coordinates, difference, and distance
        input_channels = source_channels + 2 + 2 + 2 + 1
        self.kernel = torch.nn.Sequential(
            torch.nn.Linear(input_channels, hidden_channels),
            torch.nn.GELU(),
            torch.nn.Linear(hidden_channels, hidden_channels),
            torch.nn.GELU(),
            torch.nn.Linear(hidden_channels, output_channels),
        )

    def forward(
        self,
        source_features: torch.Tensor,
        source_coordinates: torch.Tensor,
        target_coordinates: torch.Tensor,
    ) -> torch.Tensor:
        """Map ``[B,N,C]`` source data to ``[B,M,C_out]`` targets."""
        source = source_coordinates[:, None, :, :]
        target = target_coordinates[:, :, None, :]
        difference = target - source
        distance = torch.linalg.vector_norm(difference, dim=-1, keepdim=True)
        source_expanded = source_features[:, None, :, :].expand(
            -1, target_coordinates.shape[1], -1, -1
        )
        pair_features = torch.cat(
            [
                source_expanded,
                source.expand(-1, target_coordinates.shape[1], -1, -1),
                target.expand(-1, -1, source_coordinates.shape[1], -1),
                difference,
                distance,
            ],
            dim=-1,
        )
        messages = self.kernel(pair_features)
        weight = torch.exp(-0.5 * (distance / self.sigma) ** 2)
        denominator = torch.sum(weight, dim=2).clamp_min(1.0e-12)
        return torch.sum(weight * messages, dim=2) / denominator


class FaithfulGINO(torch.nn.Module):
    """Point-cloud integral encoder, spectral grid core, integral decoder."""

    def __init__(
        self,
        input_channels: int,
        side: int,
        width: int = 32,
        modes: int = 6,
        layers: int = 4,
        kernel_hidden: int = 48,
        kernel_sigma: float = 0.24,
    ) -> None:
        super().__init__()
        self.side = int(side)
        self.width = int(width)
        self.encoder = KernelIntegralTransform(
            input_channels, width, kernel_hidden, kernel_sigma
        )
        self.reference_injection = torch.nn.Linear(2, width)
        self.fno_blocks = torch.nn.ModuleList(
            [FNOBlock(width, modes) for _ in range(layers)]
        )
        self.decoder = KernelIntegralTransform(
            width, 1, kernel_hidden, kernel_sigma
        )
        # GINO implementations commonly retain a pointwise lifting/projection
        # path alongside the nonlocal integral/Fourier operator.  This skip is
        # particularly important for resolving boundary-compatible local
        # gradients; it is trained from the same inputs and contains no label
        # or analytic-solution feature.
        self.local_projection = torch.nn.Sequential(
            torch.nn.Linear(input_channels, width),
            torch.nn.GELU(),
            torch.nn.Linear(width, width),
            torch.nn.GELU(),
            torch.nn.Linear(width, 1),
        )

    def forward(
        self,
        input_features: torch.Tensor,
        physical_coordinates: torch.Tensor,
        latent_reference_coordinates: torch.Tensor,
        latent_physical_coordinates: torch.Tensor,
        boundary_mask: torch.Tensor,
    ) -> torch.Tensor:
        return self.forward_query(
            input_features,
            physical_coordinates,
            latent_reference_coordinates,
            latent_physical_coordinates,
            input_features,
            physical_coordinates,
            boundary_mask,
        )

    def forward_query(
        self,
        input_features: torch.Tensor,
        input_physical_coordinates: torch.Tensor,
        latent_reference_coordinates: torch.Tensor,
        latent_physical_coordinates: torch.Tensor,
        query_features: torch.Tensor,
        query_physical_coordinates: torch.Tensor,
        query_boundary_mask: torch.Tensor,
    ) -> torch.Tensor:
        """Evaluate one encoded field on an independently refined query mesh.

        The encoder and spectral latent grid retain the training resolution;
        only the grid-to-point transform and local projection are evaluated at
        the supplied query points.  Calling :meth:`forward` is exactly the
        same as querying at the input points.
        """
        latent = self.encoder(
            input_features,
            input_physical_coordinates,
            latent_physical_coordinates,
        )
        latent = latent + self.reference_injection(latent_reference_coordinates)
        grid = latent.transpose(1, 2).reshape(
            latent.shape[0], self.width, self.side, self.side
        )
        for block in self.fno_blocks:
            grid = block(grid)
        latent = grid.reshape(grid.shape[0], self.width, -1).transpose(1, 2)
        values = self.decoder(
            latent,
            latent_physical_coordinates,
            query_physical_coordinates,
        ).squeeze(-1)
        values = values + self.local_projection(query_features).squeeze(-1)
        return values * query_boundary_mask


def parameter_count(model: torch.nn.Module) -> int:
    return int(sum(parameter.numel() for parameter in model.parameters()))


def relative_energy_loss(
    prediction: torch.Tensor,
    target: torch.Tensor,
    horizontal_edges: torch.Tensor,
    vertical_edges: torch.Tensor,
    diagonal_edges: torch.Tensor,
    weight: float,
) -> torch.Tensor:
    """MSE plus a mesh-edge seminorm used only as a training loss."""
    mse = torch.mean((prediction - target) ** 2)
    gradient_loss = prediction.new_tensor(0.0)
    for edges in (horizontal_edges, vertical_edges, diagonal_edges):
        pred_difference = prediction[:, edges[:, 1]] - prediction[:, edges[:, 0]]
        target_difference = target[:, edges[:, 1]] - target[:, edges[:, 0]]
        gradient_loss = gradient_loss + torch.mean(
            (pred_difference - target_difference) ** 2
        )
    return mse + float(weight) * gradient_loss / 3.0


def grid_edge_sets(side: int) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    horizontal = []
    vertical = []
    diagonal = []
    for i in range(side):
        for j in range(side):
            index = i * side + j
            if j + 1 < side:
                horizontal.append((index, index + 1))
            if i + 1 < side:
                vertical.append((index, index + side))
            if i + 1 < side and j + 1 < side:
                diagonal.append((index, index + side + 1))
    return tuple(
        torch.tensor(edges, dtype=torch.long)
        for edges in (horizontal, vertical, diagonal)
    )
