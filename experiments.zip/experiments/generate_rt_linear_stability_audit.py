"""Derive the released RT2 linear-stability record from the complete 270-row audit."""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--checkpoint-seed', type=int, default=27182)
    parser.add_argument(
        '--rows', type=Path,
        default=Path('experiments/results/independent_forcing_multicheckpoint_rt2_rows.csv'),
    )
    parser.add_argument(
        '--out', type=Path,
        default=Path('experiments/results/rt_linear_stability_audit.json'),
    )
    args = parser.parse_args()
    rows_path = args.rows if args.rows.is_absolute() else ROOT / args.rows
    out_path = args.out if args.out.is_absolute() else ROOT / args.out
    with rows_path.open(newline='', encoding='utf-8') as handle:
        rows = list(csv.DictReader(handle))
    selected = [row for row in rows if int(row['seed']) == args.checkpoint_seed]
    if not selected:
        raise AssertionError('requested checkpoint seed is absent from the complete audit')
    row = max(selected, key=lambda item: float(item['max_local_basis_condition']))
    condition = float(row['max_local_basis_condition'])
    residual = float(row['relative_linear_residual'])
    if residual > 1.0e-11:
        raise AssertionError('released linear solve does not satisfy the stated safeguard')
    report = {
        'benchmark': 'independent_forcing_rt2_high_condition_linear_stability',
        'source_rows': str(args.rows),
        'source_rows_sha256': sha256(rows_path),
        'checkpoint_seed': int(row['seed']),
        'split': row['split'],
        'geometry_id': int(row['geometry_id']),
        'max_local_basis_condition': condition,
        'same_space_error': float(row['same_space_error']),
        'majorant': float(row['majorant']),
        'effectivity': float(row['effectivity']),
        'relative_linear_residual': residual,
        'certification_seconds': float(row['certification_seconds']),
        'solver_safeguard': (
            'direct sparse solve, explicit residual check, and one correction solve '
            'if the relative residual exceeds 1e-11'
        ),
        'status': 'PASS',
    }
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(report, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print(json.dumps(report, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
