"""Higher-order H(div) flux minimization with analytic Taylor upper sums.

The optimizer is assembled with scikit-fem RT spaces.  The selected flux is
then reconstructed elementwise as a physical vector polynomial in the global
reference coordinates.  Its polynomial derivatives, together with analytic
derivatives of the manufactured data, provide an independent Taylor upper sum
for all three functional-majorant terms.

The formulas define a rigorous majorant in exact arithmetic.  This program is
an ordinary floating implementation and is not labelled machine-rigorous.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import statistics
import sys
import time
from pathlib import Path
from typing import Any, Callable

import numpy as np
from scipy.sparse.linalg import spsolve
from skfem import Basis, BilinearForm, FacetBasis, LinearForm, MeshTri, asm
from skfem.element import ElementTriRT1, ElementTriRT2
from skfem.helpers import div, dot

sys.dont_write_bytecode = True
SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from independent_flux_audit import (
    affine_matrices,
    assemble_problem,
    boundary_edges,
    build_mesh,
    coefficient,
    energy_error_diagnostic,
    edge_topology,
    exact_neumann,
    exact_reference_gradient,
    explicit_constants,
    forcing,
    is_dirichlet_node,
    is_neumann_edge,
    recover_flux_independently,
    solve_problem,
    subdivisions,
)
from optimized_rt0_majorant import (
    forcing_reference_gradient,
    forcing_reference_hessian_bound,
    neumann_reference_gradient,
    neumann_reference_hessian_bound,
)


def physical_to_reference(mesh: Any, coordinates: np.ndarray) -> np.ndarray:
    eta = coordinates[1] / mesh.stretch
    xi = coordinates[0] - mesh.shear * eta
    return np.stack([xi, eta], axis=0)


def vectorized_neumann(
    mesh: Any,
    physical_points: np.ndarray,
    physical_normals: np.ndarray,
    contrast: float,
) -> np.ndarray:
    reference = np.moveaxis(
        physical_to_reference(mesh, physical_points), 0, -1
    )
    normals = np.moveaxis(physical_normals, 0, -1)
    _, inverse_transpose = affine_matrices(mesh)
    physical_gradient = exact_reference_gradient(reference) @ inverse_transpose.T
    return coefficient(reference, contrast) * np.sum(
        physical_gradient * normals, axis=-1
    )


def neumann_facets(sk_mesh: MeshTri, mesh: Any) -> np.ndarray:
    boundary = sk_mesh.boundary_facets()
    midpoints = np.mean(sk_mesh.p[:, sk_mesh.facets[:, boundary]], axis=1)
    reference = physical_to_reference(mesh, midpoints)
    return boundary[reference[0] > 1.0e-12]


def optimize_flux(
    mesh: Any,
    prediction: np.ndarray,
    boundary_mode: str,
    contrast: float,
    element: Any,
    quadrature_order: int,
    reweight_iterations: int,
    forcing_override: Callable[[Any, np.ndarray, float], np.ndarray] | None = None,
) -> dict[str, Any]:
    sk_mesh = MeshTri(mesh.physical_nodes.T, mesh.elements.T)
    basis = Basis(sk_mesh, element, intorder=quadrature_order)
    _, field_gradients, _, _ = recover_flux_independently(
        mesh, prediction, contrast
    )

    def material(physical: np.ndarray) -> np.ndarray:
        reference = np.moveaxis(physical_to_reference(mesh, physical), 0, -1)
        return coefficient(reference, contrast)

    def source(physical: np.ndarray) -> np.ndarray:
        reference = np.moveaxis(physical_to_reference(mesh, physical), 0, -1)
        if forcing_override is None:
            return forcing(mesh, reference, contrast)
        return forcing_override(mesh, reference, contrast)

    @BilinearForm
    def mismatch_matrix(trial: Any, test: Any, data: Any) -> Any:
        return dot(trial, test) / material(data.x)

    @LinearForm
    def mismatch_linear(test: Any, data: Any) -> Any:
        return dot(field_gradients.T[:, :, None], test)

    @BilinearForm
    def residual_matrix(trial: Any, test: Any, data: Any) -> Any:
        del data
        return div(trial) * div(test)

    @LinearForm
    def residual_linear(test: Any, data: Any) -> Any:
        return -source(data.x) * div(test)

    matrices = [asm(mismatch_matrix, basis), asm(residual_matrix, basis)]
    linears = [asm(mismatch_linear, basis), asm(residual_linear, basis)]
    facet_basis = None
    if boundary_mode == "mixed":
        facet_basis = FacetBasis(
            sk_mesh,
            element,
            facets=neumann_facets(sk_mesh, mesh),
            intorder=quadrature_order,
        )

        @BilinearForm
        def boundary_matrix(trial: Any, test: Any, data: Any) -> Any:
            return dot(trial, data.n) * dot(test, data.n)

        @LinearForm
        def boundary_linear(test: Any, data: Any) -> Any:
            target = vectorized_neumann(mesh, data.x, data.n, contrast)
            return target * dot(test, data.n)

        matrices.append(asm(boundary_matrix, facet_basis))
        linears.append(asm(boundary_linear, facet_basis))
    else:
        matrices.append(matrices[0] * 0.0)
        linears.append(np.zeros(basis.N, dtype=float))

    poincare, trace = explicit_constants(mesh, boundary_mode)
    scales = np.array([1.0, poincare**2, trace**2], dtype=float)
    active = scales > 0.0
    weights = np.zeros(3, dtype=float)
    weights[active] = 1.0 / int(np.sum(active))
    solution = np.zeros(basis.N, dtype=float)
    history = []
    start = time.perf_counter()
    for iteration in range(reweight_iterations):
        system = matrices[0] * 0.0
        right = np.zeros(basis.N, dtype=float)
        for component in range(3):
            if not active[component]:
                continue
            factor = scales[component] / max(weights[component], 1.0e-12)
            system = system + factor * matrices[component]
            right += factor * linears[component]
        solution = np.asarray(spsolve(system.tocsr(), right))
        field = basis.interpolate(solution)
        physical = basis.global_coordinates()
        reference = np.moveaxis(physical_to_reference(mesh, physical), 0, -1)
        diffusivity = coefficient(reference, contrast)
        values = np.moveaxis(field.value, 0, -1)
        mismatch = values - diffusivity[..., None] * field_gradients[:, None, :]
        mismatch_squared = float(
            np.sum(basis.dx * np.sum(mismatch**2, axis=-1) / diffusivity)
        )
        residual_squared = float(
            np.sum(basis.dx * (source(physical) + field.div) ** 2)
        )
        boundary_squared = 0.0
        if facet_basis is not None:
            boundary_field = facet_basis.interpolate(solution)
            target = vectorized_neumann(
                mesh,
                facet_basis.global_coordinates(),
                facet_basis.normals,
                contrast,
            )
            normal_values = np.sum(
                np.moveaxis(boundary_field.value, 0, -1)
                * np.moveaxis(facet_basis.normals, 0, -1),
                axis=-1,
            )
            boundary_squared = float(
                np.sum(facet_basis.dx * (target - normal_values) ** 2)
            )
        component_norms = np.sqrt(
            np.maximum(
                scales
                * np.array(
                    [mismatch_squared, residual_squared, boundary_squared]
                ),
                0.0,
            )
        )
        total = float(np.sum(component_norms[active]))
        next_weights = np.zeros(3, dtype=float)
        if total > 0.0:
            next_weights[active] = np.maximum(
                component_norms[active] / total, 1.0e-12
            )
            next_weights[active] /= np.sum(next_weights[active])
        else:
            next_weights[active] = 1.0 / int(np.sum(active))
        weights = next_weights
        history.append(
            {
                "iteration": iteration,
                "quadrature_component_norms": component_norms.tolist(),
                "quadrature_majorant": total,
            }
        )
    return {
        "basis": basis,
        "facet_basis": facet_basis,
        "solution": solution,
        "field_gradients": field_gradients,
        "optimization_seconds": time.perf_counter() - start,
        "history": history,
        "quadrature_majorant": history[-1]["quadrature_majorant"],
        "quadrature_component_norms": history[-1]["quadrature_component_norms"],
    }


def polynomial_features(points: np.ndarray) -> np.ndarray:
    xi, eta = points[..., 0], points[..., 1]
    return np.stack([np.ones_like(xi), xi, eta, xi**2, xi * eta, eta**2], axis=-1)


def fit_element_polynomials(
    mesh: Any, optimized: dict[str, Any]
) -> dict[str, Any]:
    basis = optimized["basis"]
    field = basis.interpolate(optimized["solution"])
    physical = basis.global_coordinates()
    reference = np.moveaxis(physical_to_reference(mesh, physical), 0, -1)
    features = polynomial_features(reference)
    values = np.moveaxis(field.value, 0, -1)
    value_coefficients = np.zeros((len(mesh.elements), 6, 2), dtype=float)
    divergence_coefficients = np.zeros((len(mesh.elements), 3), dtype=float)
    max_value_fit_defect = 0.0
    max_divergence_fit_defect = 0.0
    max_condition = 0.0
    for element in range(len(mesh.elements)):
        local_features = features[element]
        max_condition = max(max_condition, float(np.linalg.cond(local_features)))
        value_coefficients[element] = np.linalg.lstsq(
            local_features, values[element], rcond=None
        )[0]
        divergence_features = local_features[:, :3]
        divergence_coefficients[element] = np.linalg.lstsq(
            divergence_features, field.div[element], rcond=None
        )[0]
        max_value_fit_defect = max(
            max_value_fit_defect,
            float(
                np.max(
                    np.abs(local_features @ value_coefficients[element] - values[element])
                )
            ),
        )
        max_divergence_fit_defect = max(
            max_divergence_fit_defect,
            float(
                np.max(
                    np.abs(
                        divergence_features @ divergence_coefficients[element]
                        - field.div[element]
                    )
                )
            ),
        )
    # The upper-sum evaluator uses the fitted polynomial rather than the
    # scikit-fem object directly.  Audit the actual fitted field on both sides
    # of every interior facet so a small least-squares defect is not silently
    # treated as exact H(div) conformity in floating arithmetic.
    maximum_normal_jump = 0.0
    edges, adjacent = edge_topology(mesh)
    edge_parameters = np.linspace(0.0, 1.0, 9)
    for (first, second), entries in zip(edges, adjacent):
        if len(entries) != 2:
            continue
        first_reference = mesh.reference_nodes[first]
        second_reference = mesh.reference_nodes[second]
        points = (
            (1.0 - edge_parameters[:, None]) * first_reference
            + edge_parameters[:, None] * second_reference
        )
        edge_features = polynomial_features(points)
        normal_traces = []
        for element, _, _, outward_normal in entries:
            values_on_edge = edge_features @ value_coefficients[element]
            normal_traces.append(values_on_edge @ outward_normal)
        maximum_normal_jump = max(
            maximum_normal_jump,
            float(np.max(np.abs(normal_traces[0] + normal_traces[1]))),
        )
    return {
        "value_coefficients": value_coefficients,
        "divergence_coefficients": divergence_coefficients,
        "max_value_fit_defect": max_value_fit_defect,
        "max_divergence_fit_defect": max_divergence_fit_defect,
        "max_fit_condition": max_condition,
        "max_fitted_interior_normal_jump": maximum_normal_jump,
    }


def evaluate_polynomial(
    coefficients: np.ndarray, points: np.ndarray
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    features = polynomial_features(points)
    values = np.einsum("tsk,tkc->tsc", features, coefficients)
    xi, eta = points[..., 0], points[..., 1]
    jacobian = np.empty((*xi.shape, 2, 2), dtype=float)
    jacobian[..., :, 0] = (
        coefficients[:, None, 1, :]
        + 2.0 * xi[..., None] * coefficients[:, None, 3, :]
        + eta[..., None] * coefficients[:, None, 4, :]
    )
    jacobian[..., :, 1] = (
        coefficients[:, None, 2, :]
        + xi[..., None] * coefficients[:, None, 4, :]
        + 2.0 * eta[..., None] * coefficients[:, None, 5, :]
    )
    hessian = np.zeros((len(coefficients), 2, 2, 2), dtype=float)
    hessian[:, :, 0, 0] = 2.0 * coefficients[:, 3, :]
    hessian[:, :, 0, 1] = coefficients[:, 4, :]
    hessian[:, :, 1, 0] = coefficients[:, 4, :]
    hessian[:, :, 1, 1] = 2.0 * coefficients[:, 5, :]
    return values, jacobian, hessian


def taylor_upper_sum(
    mesh: Any,
    prediction: np.ndarray,
    boundary_mode: str,
    contrast: float,
    polynomial: dict[str, Any],
    depth: int,
) -> dict[str, float]:
    coefficients = polynomial["value_coefficients"]
    divergence_coefficients = polynomial["divergence_coefficients"]
    _, field_gradients, _, areas = recover_flux_independently(
        mesh, prediction, contrast
    )
    reference_elements = mesh.reference_nodes[mesh.elements]
    pieces = subdivisions(depth)
    centers = np.mean(pieces, axis=1)
    points = np.einsum("sb,tbd->tsd", centers, reference_elements)
    vertices = np.einsum("svb,tbd->tsvd", pieces, reference_elements)
    radius = np.max(
        np.linalg.norm(vertices - points[:, :, None, :], axis=-1), axis=2
    )
    flux_values, flux_jacobian, flux_hessian = evaluate_polynomial(
        coefficients, points
    )
    diffusivity = coefficient(points, contrast)
    vertex_diffusivity = coefficient(vertices, contrast)
    diffusivity_min = np.min(vertex_diffusivity, axis=2)
    mismatch = flux_values - diffusivity[..., None] * field_gradients[:, None, :]
    coefficient_gradient = np.array([contrast - 1.0, 0.0])
    mismatch_jacobian = (
        flux_jacobian
        - field_gradients[:, None, :, None]
        * coefficient_gradient[None, None, None, :]
    )
    mismatch_hessian_bound = np.sqrt(
        np.sum(flux_hessian**2, axis=(1, 2, 3))
    )
    mismatch_upper = (
        np.linalg.norm(mismatch, axis=2)
        + np.linalg.norm(mismatch_jacobian, axis=(2, 3)) * radius
        + 0.5 * mismatch_hessian_bound[:, None] * radius**2
    ) / np.sqrt(diffusivity_min)
    mismatch_squared_upper = float(
        np.sum(areas[:, None] * mismatch_upper**2 / len(pieces))
    )

    divergence = (
        divergence_coefficients[:, None, 0]
        + divergence_coefficients[:, None, 1] * points[..., 0]
        + divergence_coefficients[:, None, 2] * points[..., 1]
    )
    residual = forcing(mesh, points, contrast) + divergence
    residual_gradient = (
        forcing_reference_gradient(mesh, points, contrast)
        + divergence_coefficients[:, None, 1:3]
    )
    residual_upper = (
        np.abs(residual)
        + np.linalg.norm(residual_gradient, axis=2) * radius
        + 0.5 * forcing_reference_hessian_bound(mesh, contrast) * radius**2
    )
    residual_squared_upper = float(
        np.sum(areas[:, None] * residual_upper**2 / len(pieces))
    )

    neumann_squared_upper = 0.0
    segments = 2 ** (depth + 1)
    for first, second, element, normal in boundary_edges(mesh):
        if not is_neumann_edge(mesh, first, second, boundary_mode):
            continue
        first_ref, second_ref = mesh.reference_nodes[[first, second]]
        reference_length = float(np.linalg.norm(second_ref - first_ref))
        physical_length = float(
            np.linalg.norm(mesh.physical_nodes[second] - mesh.physical_nodes[first])
        )
        for segment in range(segments):
            parameter = (segment + 0.5) / segments
            point = (1.0 - parameter) * first_ref + parameter * second_ref
            local_points = point[None, None, :]
            local_coefficients = coefficients[element : element + 1]
            value, jacobian, hessian = evaluate_polynomial(
                local_coefficients, local_points
            )
            residual_value = float(
                exact_neumann(mesh, point, normal, contrast)
                - np.dot(value[0, 0], normal)
            )
            residual_gradient = (
                neumann_reference_gradient(mesh, point, normal, contrast)
                - normal @ jacobian[0, 0]
            )
            normal_hessian = np.einsum("c,cij->ij", normal, hessian[0])
            hessian_bound = (
                neumann_reference_hessian_bound(mesh, normal, contrast)
                + float(np.linalg.norm(normal_hessian))
            )
            radius_1d = reference_length / (2.0 * segments)
            upper = (
                abs(residual_value)
                + float(np.linalg.norm(residual_gradient)) * radius_1d
                + 0.5 * hessian_bound * radius_1d**2
            )
            neumann_squared_upper += physical_length / segments * upper**2

    poincare, trace = explicit_constants(mesh, boundary_mode)
    mismatch_norm = math.sqrt(max(mismatch_squared_upper, 0.0))
    residual_norm = math.sqrt(max(residual_squared_upper, 0.0))
    boundary_norm = math.sqrt(max(neumann_squared_upper, 0.0))
    return {
        "flux_mismatch_upper": mismatch_norm,
        "equilibrium_residual_upper": residual_norm,
        "neumann_residual_upper": boundary_norm,
        "functional_majorant": mismatch_norm + poincare * residual_norm + trace * boundary_norm,
        "poincare_constant": poincare,
        "trace_constant": trace,
    }


def run_case(
    n: int,
    shear: float,
    stretch: float,
    contrast: float,
    boundary_mode: str,
    depth: int,
    quadrature_order: int,
    reweight_iterations: int,
) -> list[dict[str, Any]]:
    mesh = build_mesh(n, shear, stretch)
    fixed = is_dirichlet_node(mesh, boundary_mode)
    cold_times = []
    matrix = load = fe = None
    for _ in range(5):
        start = time.perf_counter()
        matrix, load = assemble_problem(mesh, boundary_mode, contrast)
        fe = solve_problem(matrix, load, fixed)
        cold_times.append(time.perf_counter() - start)
    assert matrix is not None and load is not None and fe is not None
    warm_times = []
    for _ in range(5):
        start = time.perf_counter()
        solve_problem(matrix, load, fixed)
        warm_times.append(time.perf_counter() - start)
    direct_fe_cold_seconds = statistics.median(cold_times)
    direct_fe_warm_seconds = statistics.median(warm_times)
    xi, eta = mesh.reference_nodes[:, 0], mesh.reference_nodes[:, 1]
    prediction = fe + 0.04 * np.sin(2.0 * math.pi * xi) * np.sin(math.pi * eta)
    prediction[fixed] = 0.0
    error = energy_error_diagnostic(mesh, prediction, contrast)
    rows = []
    for name, element in (("RT1", ElementTriRT1()), ("RT2", ElementTriRT2())):
        certification_start = time.perf_counter()
        optimized = optimize_flux(
            mesh,
            prediction,
            boundary_mode,
            contrast,
            element,
            quadrature_order,
            reweight_iterations,
        )
        fit_start = time.perf_counter()
        polynomial = fit_element_polynomials(mesh, optimized)
        polynomial_fit_seconds = time.perf_counter() - fit_start
        upper_sum_start = time.perf_counter()
        upper = taylor_upper_sum(
            mesh, prediction, boundary_mode, contrast, polynomial, depth
        )
        upper_sum_seconds = time.perf_counter() - upper_sum_start
        certification_seconds = time.perf_counter() - certification_start
        rows.append(
            {
                "case_id": f"n{n}_{boundary_mode}_s{shear:g}_t{stretch:g}_c{contrast:g}",
                "method": name,
                "n": n,
                "boundary_mode": boundary_mode,
                "shear": shear,
                "stretch": stretch,
                "contrast": contrast,
                "dofs": int(optimized["basis"].N),
                "energy_error": error,
                "quadrature_majorant": optimized["quadrature_majorant"],
                "quadrature_effectivity": optimized["quadrature_majorant"] / max(error, 1.0e-30),
                "taylor_majorant": upper["functional_majorant"],
                "taylor_effectivity": upper["functional_majorant"] / max(error, 1.0e-30),
                "floating_coverage": bool(upper["functional_majorant"] + 1.0e-10 >= error),
                "flux_mismatch_upper": upper["flux_mismatch_upper"],
                "equilibrium_residual_upper": upper["equilibrium_residual_upper"],
                "neumann_residual_upper": upper["neumann_residual_upper"],
                "optimization_seconds": optimized["optimization_seconds"],
                "polynomial_fit_seconds": polynomial_fit_seconds,
                "upper_sum_seconds": upper_sum_seconds,
                "certification_seconds": certification_seconds,
                "direct_fe_cold_seconds": direct_fe_cold_seconds,
                "direct_fe_warm_seconds": direct_fe_warm_seconds,
                "certification_over_fe_cold": certification_seconds / direct_fe_cold_seconds,
                "certification_over_fe_warm": certification_seconds / direct_fe_warm_seconds,
                "max_value_polynomial_fit_defect": polynomial["max_value_fit_defect"],
                "max_divergence_polynomial_fit_defect": polynomial["max_divergence_fit_defect"],
                "max_fitted_interior_normal_jump": polynomial["max_fitted_interior_normal_jump"],
                "max_polynomial_fit_condition": polynomial["max_fit_condition"],
            }
        )
    return rows


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def summarize(rows: list[dict[str, Any]], method: str) -> dict[str, Any]:
    group = [row for row in rows if row["method"] == method]
    effects = [float(row["taylor_effectivity"]) for row in group]
    return {
        "cases": len(group),
        "floating_coverage_rate": statistics.fmean(
            float(row["floating_coverage"]) for row in group
        ),
        "effectivity_mean": statistics.fmean(effects),
        "effectivity_median": statistics.median(effects),
        "effectivity_min": min(effects),
        "effectivity_max": max(effects),
        "optimization_seconds_median": statistics.median(
            float(row["optimization_seconds"]) for row in group
        ),
        "certification_seconds_median": statistics.median(
            float(row["certification_seconds"]) for row in group
        ),
        "certification_over_fe_cold_median": statistics.median(
            float(row["certification_over_fe_cold"]) for row in group
        ),
        "certification_over_fe_warm_median": statistics.median(
            float(row["certification_over_fe_warm"]) for row in group
        ),
        "certification_faster_than_fe_cold_rate": statistics.fmean(
            float(row["certification_over_fe_cold"] < 1.0) for row in group
        ),
        "certification_faster_than_fe_warm_rate": statistics.fmean(
            float(row["certification_over_fe_warm"] < 1.0) for row in group
        ),
        "max_value_polynomial_fit_defect": max(
            float(row["max_value_polynomial_fit_defect"]) for row in group
        ),
        "max_divergence_polynomial_fit_defect": max(
            float(row["max_divergence_polynomial_fit_defect"]) for row in group
        ),
        "max_fitted_interior_normal_jump": max(
            float(row["max_fitted_interior_normal_jump"]) for row in group
        ),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--quick", action="store_true")
    parser.add_argument("--levels", nargs="+", type=int)
    parser.add_argument("--depth", type=int, default=3)
    parser.add_argument("--quadrature-order", type=int, default=12)
    parser.add_argument("--reweight-iterations", type=int, default=8)
    parser.add_argument(
        "--summary-out", type=Path,
        default=Path("experiments/results/sidebranch_higher_order_flux_summary.json"),
    )
    parser.add_argument(
        "--rows-out", type=Path,
        default=Path("experiments/results/sidebranch_higher_order_flux_rows.csv"),
    )
    args = parser.parse_args()
    levels = args.levels or ([8] if args.quick else [8, 16])
    geometries = [(0.85, 0.3)] if args.quick else [(0.35, 0.8), (0.6, 1.4), (0.85, 0.3)]
    contrasts = [100.0] if args.quick else [1.0, 10.0, 100.0]
    modes = ["dirichlet", "mixed"]
    rows: list[dict[str, Any]] = []
    for mode in modes:
        for shear, stretch in geometries:
            for contrast in contrasts:
                for n in levels:
                    case_rows = run_case(
                        n,
                        shear,
                        stretch,
                        contrast,
                        mode,
                        args.depth,
                        args.quadrature_order,
                        args.reweight_iterations,
                    )
                    rows.extend(case_rows)
                    print(
                        case_rows[0]["case_id"],
                        " ".join(
                            f"{row['method']}={row['taylor_effectivity']:.3f}"
                            for row in case_rows
                        ),
                    )
    failures = [row for row in rows if not row["floating_coverage"]]
    report = {
        "benchmark": "sidebranch_higher_order_hdiv_functional_majorant",
        "scope": {
            "optimizer": "global RT functional-majorant minimization",
            "upper_sum": "element polynomial derivatives plus analytic data Hessian bounds",
            "fit_boundary": "polynomial reconstruction is audited at redundant quadrature points",
            "floating_scope": "mathematically certified formula in exact arithmetic; ordinary floating implementation, not machine-rigorous",
        },
        "config": {
            "levels": levels,
            "geometries": geometries,
            "contrasts": contrasts,
            "boundary_modes": modes,
            "depth": args.depth,
            "quadrature_order": args.quadrature_order,
            "reweight_iterations": args.reweight_iterations,
        },
        "methods": {method: summarize(rows, method) for method in ("RT1", "RT2")},
        "coverage_failures": failures,
        "rows": rows,
    }
    args.summary_out.parent.mkdir(parents=True, exist_ok=True)
    args.summary_out.write_text(json.dumps(report, indent=2, sort_keys=True), encoding="utf-8")
    write_csv(args.rows_out, rows)
    if failures:
        raise AssertionError(f"higher-order floating coverage failed in {len(failures)} rows")


if __name__ == "__main__":
    main()
