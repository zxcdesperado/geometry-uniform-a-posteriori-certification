"""Independent audit of recovered-flux certificates.

This file deliberately does not import any project mesh, assembly, residual,
flux-recovery, or majorant implementation.  It rebuilds those ingredients to
test the production experiment by an independent code path.

The audit covers affine geometries, full Dirichlet and mixed boundaries, and a
smooth coefficient with a prescribed contrast.  Its functional bounds use
explicit Poincare/trace constants and upper sums based on analytic Lipschitz
bounds.  Reported comparisons with the manufactured error still use floating
quadrature and are therefore diagnostics, not machine-rigorous intervals.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import platform
import statistics
import sys
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import scipy
from scipy.sparse import coo_matrix, csr_matrix, diags
from scipy.sparse.linalg import spsolve

sys.dont_write_bytecode = True


@dataclass(frozen=True)
class AuditMesh:
    reference_nodes: np.ndarray
    physical_nodes: np.ndarray
    elements: np.ndarray
    boundary_tags: np.ndarray
    shear: float
    stretch: float


def triangle_rule() -> list[tuple[float, tuple[float, float, float]]]:
    a1, b1 = 0.059715871789770, 0.470142064105115
    a2, b2 = 0.797426985353087, 0.101286507323456
    return [
        (0.225000000000000, (1.0 / 3.0,) * 3),
        (0.132394152788506, (a1, b1, b1)),
        (0.132394152788506, (b1, a1, b1)),
        (0.132394152788506, (b1, b1, a1)),
        (0.125939180544827, (a2, b2, b2)),
        (0.125939180544827, (b2, a2, b2)),
        (0.125939180544827, (b2, b2, a2)),
    ]


def gauss_rule_1d() -> tuple[np.ndarray, np.ndarray]:
    points, weights = np.polynomial.legendre.leggauss(8)
    return 0.5 * (points + 1.0), 0.5 * weights


def build_mesh(n: int, shear: float, stretch: float) -> AuditMesh:
    grid = np.linspace(0.0, 1.0, n + 1)
    reference = np.array([(x, y) for y in grid for x in grid], dtype=float)
    physical = np.column_stack(
        [reference[:, 0] + shear * reference[:, 1], stretch * reference[:, 1]]
    )
    elements: list[tuple[int, int, int]] = []
    for j in range(n):
        for i in range(n):
            lower_left = j * (n + 1) + i
            lower_right = lower_left + 1
            upper_left = lower_left + n + 1
            upper_right = upper_left + 1
            elements.extend(
                [
                    (lower_left, lower_right, upper_right),
                    (lower_left, upper_right, upper_left),
                ]
            )
    tolerance = 10.0 * np.finfo(float).eps
    tags = np.zeros(len(reference), dtype=np.int8)
    tags[np.abs(reference[:, 0]) <= tolerance] |= 1
    tags[np.abs(reference[:, 0] - 1.0) <= tolerance] |= 2
    tags[np.abs(reference[:, 1]) <= tolerance] |= 4
    tags[np.abs(reference[:, 1] - 1.0) <= tolerance] |= 8
    return AuditMesh(
        reference,
        physical,
        np.asarray(elements, dtype=np.int64),
        tags,
        shear,
        stretch,
    )


def affine_matrices(mesh: AuditMesh) -> tuple[np.ndarray, np.ndarray]:
    jacobian = np.array(
        [[1.0, mesh.shear], [0.0, mesh.stretch]], dtype=float
    )
    return jacobian, np.linalg.inv(jacobian).T


def element_geometry(mesh: AuditMesh) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    coordinates = mesh.physical_nodes[mesh.elements]
    x, y = coordinates[:, :, 0], coordinates[:, :, 1]
    double_area = (
        (x[:, 1] - x[:, 0]) * (y[:, 2] - y[:, 0])
        - (x[:, 2] - x[:, 0]) * (y[:, 1] - y[:, 0])
    )
    gradients = np.stack(
        [
            np.stack([y[:, 1] - y[:, 2], x[:, 2] - x[:, 1]], axis=1),
            np.stack([y[:, 2] - y[:, 0], x[:, 0] - x[:, 2]], axis=1),
            np.stack([y[:, 0] - y[:, 1], x[:, 1] - x[:, 0]], axis=1),
        ],
        axis=1,
    )
    gradients /= double_area[:, None, None]
    return coordinates, gradients, 0.5 * np.abs(double_area)


def exact_reference_value(points: np.ndarray) -> np.ndarray:
    return np.sin(math.pi * points[..., 0]) * np.sin(math.pi * points[..., 1])


def exact_reference_gradient(points: np.ndarray) -> np.ndarray:
    xi, eta = points[..., 0], points[..., 1]
    return np.stack(
        [
            math.pi * np.cos(math.pi * xi) * np.sin(math.pi * eta),
            math.pi * np.sin(math.pi * xi) * np.cos(math.pi * eta),
        ],
        axis=-1,
    )


def coefficient(points: np.ndarray, contrast: float) -> np.ndarray:
    return 1.0 + (contrast - 1.0) * points[..., 0]


def forcing(mesh: AuditMesh, points: np.ndarray, contrast: float) -> np.ndarray:
    xi, eta = points[..., 0], points[..., 1]
    jacobian, inverse_transpose = affine_matrices(mesh)
    inverse = np.linalg.inv(jacobian)
    pulled = mesh.stretch * inverse @ inverse.T
    sine = math.pi**2 * (pulled[0, 0] + pulled[1, 1]) / mesh.stretch
    cosine = -2.0 * math.pi**2 * pulled[0, 1] / mesh.stretch
    minus_laplacian = (
        sine * np.sin(math.pi * xi) * np.sin(math.pi * eta)
        + cosine * np.cos(math.pi * xi) * np.cos(math.pi * eta)
    )
    physical_gradient = exact_reference_gradient(points) @ inverse_transpose.T
    coefficient_gradient = (contrast - 1.0) * inverse_transpose[:, 0]
    return coefficient(points, contrast) * minus_laplacian - np.einsum(
        "...i,i->...", physical_gradient, coefficient_gradient
    )


def boundary_edges(mesh: AuditMesh) -> list[tuple[int, int, int, np.ndarray]]:
    incidence: dict[tuple[int, int], list[int]] = {}
    for element_index, triangle in enumerate(mesh.elements):
        for first, second in (
            (triangle[0], triangle[1]),
            (triangle[1], triangle[2]),
            (triangle[2], triangle[0]),
        ):
            key = tuple(sorted((int(first), int(second))))
            incidence.setdefault(key, []).append(element_index)
    output = []
    for (first, second), adjacent in incidence.items():
        if len(adjacent) != 1:
            continue
        element = adjacent[0]
        edge_vector = mesh.physical_nodes[second] - mesh.physical_nodes[first]
        normal = np.array([edge_vector[1], -edge_vector[0]], dtype=float)
        normal /= np.linalg.norm(normal)
        midpoint = 0.5 * (mesh.physical_nodes[first] + mesh.physical_nodes[second])
        centroid = np.mean(mesh.physical_nodes[mesh.elements[element]], axis=0)
        if float(np.dot(normal, centroid - midpoint)) > 0.0:
            normal *= -1.0
        output.append((first, second, element, normal))
    return output


def is_dirichlet_node(mesh: AuditMesh, boundary_mode: str) -> np.ndarray:
    if boundary_mode == "dirichlet":
        return mesh.boundary_tags != 0
    return (mesh.boundary_tags & 1) != 0


def is_neumann_edge(mesh: AuditMesh, first: int, second: int, mode: str) -> bool:
    if mode == "dirichlet":
        return False
    return not (
        (mesh.boundary_tags[first] & 1) != 0
        and (mesh.boundary_tags[second] & 1) != 0
    )


def exact_neumann(
    mesh: AuditMesh,
    points: np.ndarray,
    normal: np.ndarray,
    contrast: float,
) -> np.ndarray:
    _, inverse_transpose = affine_matrices(mesh)
    physical_gradient = exact_reference_gradient(points) @ inverse_transpose.T
    return coefficient(points, contrast) * (physical_gradient @ normal)


def assemble_problem(
    mesh: AuditMesh, boundary_mode: str, contrast: float
) -> tuple[csr_matrix, np.ndarray]:
    _, gradients, areas = element_geometry(mesh)
    rows: list[int] = []
    columns: list[int] = []
    data: list[float] = []
    load = np.zeros(len(mesh.physical_nodes), dtype=float)
    rule = triangle_rule()
    for element_index, triangle in enumerate(mesh.elements):
        reference = mesh.reference_nodes[triangle]
        centroid = np.mean(reference, axis=0)
        local_stiffness = (
            areas[element_index]
            * coefficient(centroid, contrast)
            * (gradients[element_index] @ gradients[element_index].T)
        )
        for local_i in range(3):
            for local_j in range(3):
                rows.append(int(triangle[local_i]))
                columns.append(int(triangle[local_j]))
                data.append(float(local_stiffness[local_i, local_j]))
        for weight, barycentric in rule:
            bary = np.asarray(barycentric)
            point = bary @ reference
            value = float(forcing(mesh, point, contrast))
            load[triangle] += weight * areas[element_index] * value * bary
    if boundary_mode == "mixed":
        points_1d, weights_1d = gauss_rule_1d()
        for first, second, _, normal in boundary_edges(mesh):
            if not is_neumann_edge(mesh, first, second, boundary_mode):
                continue
            first_ref = mesh.reference_nodes[first]
            second_ref = mesh.reference_nodes[second]
            length = float(
                np.linalg.norm(mesh.physical_nodes[second] - mesh.physical_nodes[first])
            )
            points = (
                (1.0 - points_1d[:, None]) * first_ref
                + points_1d[:, None] * second_ref
            )
            values = exact_neumann(mesh, points, normal, contrast)
            load[first] += length * float(
                np.dot(weights_1d, values * (1.0 - points_1d))
            )
            load[second] += length * float(np.dot(weights_1d, values * points_1d))
    matrix = coo_matrix(
        (data, (rows, columns)),
        shape=(len(mesh.physical_nodes), len(mesh.physical_nodes)),
    ).tocsr()
    return matrix, load


def assemble_dirichlet_problem_vectorized(
    mesh: AuditMesh, contrast: float
) -> tuple[csr_matrix, np.ndarray]:
    """Vectorized equivalent of ``assemble_problem(..., 'dirichlet', ...)``.

    The routine preserves the same seven-point triangle rule and P1 assembly,
    but evaluates all elements in NumPy batches.  It deliberately supports only
    the full-Dirichlet branch so that no mixed-boundary operation is silently
    changed.  A regression test and the cost benchmark compare it with the
    independent element-loop implementation.
    """

    _, gradients, areas = element_geometry(mesh)
    elements = mesh.elements
    references = mesh.reference_nodes[elements]
    centroids = np.mean(references, axis=1)
    material = coefficient(centroids, contrast)
    gradient_products = np.einsum(
        "eik,ejk->eij", gradients, gradients, optimize=True
    )
    local_stiffness = (
        areas[:, None, None]
        * material[:, None, None]
        * gradient_products
    )
    rows = np.repeat(elements, 3, axis=1).reshape(-1)
    columns = np.tile(elements, (1, 3)).reshape(-1)
    matrix = coo_matrix(
        (local_stiffness.reshape(-1), (rows, columns)),
        shape=(len(mesh.physical_nodes), len(mesh.physical_nodes)),
    ).tocsr()

    rule = triangle_rule()
    weights = np.asarray([item[0] for item in rule], dtype=float)
    barycentric = np.asarray([item[1] for item in rule], dtype=float)
    points = np.einsum(
        "qi,eid->eqd", barycentric, references, optimize=True
    )
    values = forcing(mesh, points, contrast)
    local_load = areas[:, None] * np.einsum(
        "q,eq,qi->ei", weights, values, barycentric, optimize=True
    )
    load = np.zeros(len(mesh.physical_nodes), dtype=float)
    np.add.at(load, elements.reshape(-1), local_load.reshape(-1))
    return matrix, load


def solve_problem(
    matrix: csr_matrix, load: np.ndarray, dirichlet: np.ndarray
) -> np.ndarray:
    free = np.flatnonzero(~dirichlet)
    values = np.zeros_like(load)
    values[free] = spsolve(matrix[free][:, free], load[free])
    return values


def prediction_perturbation(mesh: AuditMesh, amplitude: float) -> np.ndarray:
    xi, eta = mesh.reference_nodes[:, 0], mesh.reference_nodes[:, 1]
    return amplitude * np.sin(2.0 * math.pi * xi) * np.sin(math.pi * eta)


def recover_flux_independently(
    mesh: AuditMesh,
    values: np.ndarray,
    contrast: float,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    _, gradients, areas = element_geometry(mesh)
    field_gradients = np.einsum(
        "ti,tij->tj", values[mesh.elements], gradients
    )
    centroids = np.mean(mesh.reference_nodes[mesh.elements], axis=1)
    raw_flux = coefficient(centroids, contrast)[:, None] * field_gradients
    nodal_flux = np.zeros((len(mesh.physical_nodes), 2), dtype=float)
    nodal_weights = np.zeros(len(mesh.physical_nodes), dtype=float)
    for local in range(3):
        nodes = mesh.elements[:, local]
        np.add.at(nodal_flux, nodes, areas[:, None] * raw_flux)
        np.add.at(nodal_weights, nodes, areas)
    nodal_flux /= nodal_weights[:, None]
    return nodal_flux, field_gradients, gradients, areas


def triangle_forcing_moments(
    mesh: AuditMesh, contrast: float, order: int
) -> np.ndarray:
    """Integrate the forcing independently with a tensor-product Duffy rule."""
    points_1d, weights_1d = np.polynomial.legendre.leggauss(order)
    points_1d = 0.5 * (points_1d + 1.0)
    weights_1d = 0.5 * weights_1d
    reference = mesh.reference_nodes[mesh.elements]
    _, _, areas = element_geometry(mesh)
    moments = np.zeros(len(mesh.elements), dtype=float)
    for r, weight_r in zip(points_1d, weights_1d):
        for s, weight_s in zip(points_1d, weights_1d):
            barycentric = np.array(
                [(1.0 - r) * (1.0 - s), r, (1.0 - r) * s]
            )
            points = np.einsum("i,tid->td", barycentric, reference)
            moments += (
                2.0
                * areas
                * weight_r
                * weight_s
                * (1.0 - r)
                * forcing(mesh, points, contrast)
            )
    return moments


def neumann_flux_moment(
    mesh: AuditMesh,
    first: int,
    second: int,
    normal: np.ndarray,
    contrast: float,
    order: int,
) -> float:
    points_1d, weights_1d = np.polynomial.legendre.leggauss(order)
    points_1d = 0.5 * (points_1d + 1.0)
    weights_1d = 0.5 * weights_1d
    first_ref, second_ref = mesh.reference_nodes[[first, second]]
    points = (
        (1.0 - points_1d[:, None]) * first_ref
        + points_1d[:, None] * second_ref
    )
    length = float(
        np.linalg.norm(mesh.physical_nodes[second] - mesh.physical_nodes[first])
    )
    return length * float(
        np.dot(weights_1d, exact_neumann(mesh, points, normal, contrast))
    )


def edge_topology(
    mesh: AuditMesh,
) -> tuple[
    list[tuple[int, int]],
    list[list[tuple[int, int, float, np.ndarray]]],
]:
    """Return edges and adjacent (element, opposite vertex, sign, normal)."""
    incidence: dict[tuple[int, int], list[tuple[int, int, np.ndarray]]] = {}
    coordinates = mesh.physical_nodes[mesh.elements]
    centroids = np.mean(coordinates, axis=1)
    for element, triangle in enumerate(mesh.elements):
        for opposite in range(3):
            local = [index for index in range(3) if index != opposite]
            first, second = int(triangle[local[0]]), int(triangle[local[1]])
            key = tuple(sorted((first, second)))
            tangent = mesh.physical_nodes[second] - mesh.physical_nodes[first]
            normal = np.array([tangent[1], -tangent[0]], dtype=float)
            normal /= np.linalg.norm(normal)
            midpoint = 0.5 * (
                mesh.physical_nodes[first] + mesh.physical_nodes[second]
            )
            if float(np.dot(normal, centroids[element] - midpoint)) > 0.0:
                normal *= -1.0
            incidence.setdefault(key, []).append((element, opposite, normal))
    edges = sorted(incidence)
    adjacent: list[list[tuple[int, int, float, np.ndarray]]] = []
    for edge in edges:
        entries = incidence[edge]
        canonical = entries[0][2]
        current = []
        for element, opposite, normal in entries:
            sign = 1.0 if float(np.dot(normal, canonical)) >= 0.0 else -1.0
            current.append((element, opposite, sign, normal))
        adjacent.append(current)
    return edges, adjacent


def equilibrate_rt0_flux(
    mesh: AuditMesh,
    values: np.ndarray,
    boundary_mode: str,
    contrast: float,
    moment_order: int = 12,
    verification_order: int = 16,
) -> dict[str, object]:
    """Project raw edge fluxes onto an exactly conservative RT0 space.

    The constrained minimization is global, so this audit does not disguise it
    as a patch-local algorithm.  Its purpose is to close the mathematical
    equilibrium condition and to measure the cost of doing so.
    """
    edges, adjacent = edge_topology(mesh)
    _, field_gradients, _, areas = recover_flux_independently(
        mesh, values, contrast
    )
    reference_elements = mesh.reference_nodes[mesh.elements]
    edge_indices = {edge: index for index, edge in enumerate(edges)}
    rows: list[int] = []
    columns: list[int] = []
    data: list[float] = []
    raw_integrals = np.zeros(len(edges), dtype=float)
    lengths = np.zeros(len(edges), dtype=float)
    fixed = np.zeros(len(edges), dtype=bool)
    fixed_values = np.zeros(len(edges), dtype=float)
    for edge_index, ((first, second), edge_adjacent) in enumerate(
        zip(edges, adjacent)
    ):
        lengths[edge_index] = float(
            np.linalg.norm(mesh.physical_nodes[second] - mesh.physical_nodes[first])
        )
        canonical_values = []
        for element, _, sign, normal in edge_adjacent:
            midpoint = 0.5 * (
                mesh.reference_nodes[first] + mesh.reference_nodes[second]
            )
            raw = coefficient(midpoint, contrast) * field_gradients[element]
            outward_integral = lengths[edge_index] * float(np.dot(raw, normal))
            canonical_values.append(sign * outward_integral)
        raw_integrals[edge_index] = float(np.mean(canonical_values))
        if len(edge_adjacent) == 1 and is_neumann_edge(
            mesh, first, second, boundary_mode
        ):
            element, _, sign, normal = edge_adjacent[0]
            del element
            fixed[edge_index] = True
            fixed_values[edge_index] = sign * neumann_flux_moment(
                mesh,
                first,
                second,
                normal,
                contrast,
                moment_order,
            )
    for element, triangle in enumerate(mesh.elements):
        for opposite in range(3):
            local = [index for index in range(3) if index != opposite]
            edge = tuple(
                sorted((int(triangle[local[0]]), int(triangle[local[1]])))
            )
            edge_index = edge_indices[edge]
            entry = next(item for item in adjacent[edge_index] if item[0] == element)
            rows.append(element)
            columns.append(edge_index)
            data.append(entry[2])
    incidence = coo_matrix(
        (data, (rows, columns)),
        shape=(len(mesh.elements), len(edges)),
    ).tocsr()
    forcing_moments = triangle_forcing_moments(mesh, contrast, moment_order)
    free = np.flatnonzero(~fixed)
    target = -forcing_moments.copy()
    if np.any(fixed):
        target -= incidence[:, fixed] @ fixed_values[fixed]
    free_incidence = incidence[:, free]
    inverse_weights = np.maximum(lengths[free], np.finfo(float).tiny)
    schur = free_incidence @ diags(inverse_weights) @ free_incidence.T
    defect = target - free_incidence @ raw_integrals[free]
    multiplier = spsolve(schur.tocsr(), defect)
    integrals = fixed_values.copy()
    integrals[free] = raw_integrals[free] + inverse_weights * (
        free_incidence.T @ multiplier
    )
    local_outward = np.zeros((len(mesh.elements), 3), dtype=float)
    for edge_index, edge_adjacent in enumerate(adjacent):
        for element, opposite, sign, _ in edge_adjacent:
            local_outward[element, opposite] = sign * integrals[edge_index]
    verification_moments = triangle_forcing_moments(
        mesh, contrast, verification_order
    )
    algebraic_defects = forcing_moments + np.sum(local_outward, axis=1)
    independent_defects = verification_moments + np.sum(local_outward, axis=1)
    flux_scale = max(1.0, float(np.max(np.abs(integrals))))
    algebraic_tolerance = (
        2.0e4
        * np.finfo(float).eps
        * max(1.0, float(np.max(np.abs(forcing_moments))), flux_scale)
    )
    maximum_normal_jump = 0.0
    interior_edges = 0
    maximum_neumann_moment_defect = 0.0
    for edge_index, ((first, second), edge_adjacent) in enumerate(
        zip(edges, adjacent)
    ):
        if len(edge_adjacent) == 2:
            interior_edges += 1
            first_trace = integrals[edge_index] / lengths[edge_index]
            second_trace = integrals[edge_index] / lengths[edge_index]
            maximum_normal_jump = max(
                maximum_normal_jump, abs(first_trace - second_trace)
            )
        elif fixed[edge_index]:
            _, _, sign, normal = edge_adjacent[0]
            verified = sign * neumann_flux_moment(
                mesh,
                first,
                second,
                normal,
                contrast,
                verification_order,
            )
            maximum_neumann_moment_defect = max(
                maximum_neumann_moment_defect,
                abs(integrals[edge_index] - verified),
            )
    return {
        "edge_integrals": integrals,
        "local_outward_integrals": local_outward,
        "field_gradients": field_gradients,
        "areas": areas,
        "reference_elements": reference_elements,
        "algebraic_balance_defects": algebraic_defects,
        "independent_balance_defects": independent_defects,
        "max_abs_algebraic_balance_defect": float(
            np.max(np.abs(algebraic_defects))
        ),
        "max_abs_independent_balance_defect": float(
            np.max(np.abs(independent_defects))
        ),
        "signed_global_independent_balance_defect": float(
            np.sum(independent_defects)
        ),
        "max_interior_normal_trace_difference": maximum_normal_jump,
        "max_neumann_flux_moment_defect": maximum_neumann_moment_defect,
        "balance_tolerance": algebraic_tolerance,
        "local_integral_equilibrium_passed": bool(
            np.max(np.abs(algebraic_defects)) <= algebraic_tolerance
        ),
        "independent_quadrature_consistent": bool(
            np.max(np.abs(independent_defects))
            <= algebraic_tolerance
            + 10.0 * np.max(np.abs(verification_moments - forcing_moments))
        ),
        "hdiv_conformity_passed": bool(
            maximum_normal_jump <= algebraic_tolerance
        ),
        "neumann_moment_balance_passed": bool(
            maximum_neumann_moment_defect
            <= algebraic_tolerance
            + 10.0 * np.max(np.abs(verification_moments - forcing_moments))
        ),
        "interior_edges_checked": interior_edges,
        "moment_order": moment_order,
        "verification_order": verification_order,
        "flux_space": "independently equilibrated RT0 edge flux",
        "equilibration_scope": (
            "global constrained projection onto RT0; not claimed to be a "
            "patch-local solve"
        ),
    }


def subdivisions(depth: int) -> np.ndarray:
    triangles = [np.eye(3, dtype=float)]
    for _ in range(depth):
        refined = []
        for vertices in triangles:
            first, second, third = vertices
            midpoint_12 = 0.5 * (first + second)
            midpoint_23 = 0.5 * (second + third)
            midpoint_31 = 0.5 * (third + first)
            refined.extend(
                [
                    np.array([first, midpoint_12, midpoint_31]),
                    np.array([midpoint_12, second, midpoint_23]),
                    np.array([midpoint_31, midpoint_23, third]),
                    np.array([midpoint_12, midpoint_23, midpoint_31]),
                ]
            )
        triangles = refined
    return np.asarray(triangles)


def forcing_reference_lipschitz_bound(
    mesh: AuditMesh, contrast: float
) -> float:
    jacobian, inverse_transpose = affine_matrices(mesh)
    inverse = np.linalg.inv(jacobian)
    pulled = mesh.stretch * inverse @ inverse.T
    sine = math.pi**2 * (pulled[0, 0] + pulled[1, 1]) / mesh.stretch
    cosine = -2.0 * math.pi**2 * pulled[0, 1] / mesh.stretch
    base = abs(sine) + abs(cosine)
    inverse_norm = float(np.linalg.norm(inverse_transpose, 2))
    coefficient_gradient_norm = (
        (contrast - 1.0) * float(np.linalg.norm(inverse_transpose[:, 0]))
    )
    hessian_column_bound = inverse_norm * math.pi**2 * math.sqrt(2.0)
    common = coefficient_gradient_norm * hessian_column_bound
    derivative_xi = (
        (contrast - 1.0) * base + contrast * math.pi * base + common
    )
    derivative_eta = contrast * math.pi * base + common
    return math.hypot(derivative_xi, derivative_eta)


def exact_flux_reference_lipschitz_bound(
    mesh: AuditMesh, contrast: float
) -> float:
    _, inverse_transpose = affine_matrices(mesh)
    inverse_norm = float(np.linalg.norm(inverse_transpose, 2))
    gradient_bound = inverse_norm * math.pi * math.sqrt(2.0)
    hessian_column_bound = inverse_norm * math.pi**2 * math.sqrt(2.0)
    first = (contrast - 1.0) * gradient_bound + contrast * hessian_column_bound
    second = contrast * hessian_column_bound
    return math.hypot(first, second)


def explicit_constants(mesh: AuditMesh, boundary_mode: str) -> tuple[float, float]:
    jacobian, _ = affine_matrices(mesh)
    sigma_max = float(np.linalg.svd(jacobian, compute_uv=False)[0])
    if boundary_mode == "dirichlet":
        return sigma_max / (math.pi * math.sqrt(2.0)), 0.0
    max_edge_scale = max(1.0, math.hypot(mesh.shear, mesh.stretch))
    trace = math.sqrt(7.0 * max_edge_scale) * sigma_max / math.sqrt(mesh.stretch)
    return 1.0 / math.sqrt(2.0), trace


def functional_upper_sum(
    mesh: AuditMesh,
    values: np.ndarray,
    boundary_mode: str,
    contrast: float,
    depth: int,
) -> dict[str, float]:
    nodal_flux, field_gradients, gradients, areas = recover_flux_independently(
        mesh, values, contrast
    )
    local_flux = nodal_flux[mesh.elements]
    divergences = np.einsum(
        "tij,tij->t", local_flux, gradients
    )
    reference_elements = mesh.reference_nodes[mesh.elements]
    pieces = subdivisions(depth)
    centers = np.mean(pieces, axis=1)
    points = np.einsum("sb,tbd->tsd", centers, reference_elements)
    max_reference_diameter = np.maximum.reduce(
        [
            np.linalg.norm(reference_elements[:, 0] - reference_elements[:, 1], axis=1),
            np.linalg.norm(reference_elements[:, 1] - reference_elements[:, 2], axis=1),
            np.linalg.norm(reference_elements[:, 2] - reference_elements[:, 0], axis=1),
        ]
    )
    radius = max_reference_diameter[:, None] / (2.0**depth)

    forcing_values = forcing(mesh, points, contrast)
    residual_upper = (
        np.abs(forcing_values + divergences[:, None])
        + forcing_reference_lipschitz_bound(mesh, contrast) * radius
    )
    residual_squared_upper = float(
        np.sum(areas[:, None] * residual_upper**2 / len(pieces))
    )

    barycentric_values = np.einsum("sb,tbi->tsi", centers, local_flux)
    k_values = coefficient(points, contrast)
    mismatch_values = barycentric_values - k_values[..., None] * field_gradients[:, None, :]
    reference_flux_gradients = np.einsum(
        "tni,tnj->tij", local_flux, np.einsum(
            "tnp,pq->tnq", gradients, np.array([[1.0, mesh.shear], [0.0, mesh.stretch]])
        )
    )
    correction = np.zeros_like(reference_flux_gradients)
    correction[:, :, 0] = (contrast - 1.0) * field_gradients
    mismatch_lipschitz = np.linalg.norm(
        reference_flux_gradients - correction, axis=(1, 2)
    )
    mismatch_upper = np.linalg.norm(mismatch_values, axis=2) + mismatch_lipschitz[:, None] * radius
    mismatch_squared_upper = float(
        np.sum(areas[:, None] * mismatch_upper**2 / len(pieces))
    )

    neumann_squared_upper = 0.0
    neumann_integral = 0.0
    neumann_edges = 0
    segments = 2 ** (depth + 1)
    exact_flux_lipschitz = exact_flux_reference_lipschitz_bound(mesh, contrast)
    for first, second, element, normal in boundary_edges(mesh):
        if not is_neumann_edge(mesh, first, second, boundary_mode):
            continue
        neumann_edges += 1
        first_ref, second_ref = mesh.reference_nodes[[first, second]]
        edge_reference_length = float(np.linalg.norm(second_ref - first_ref))
        edge_physical_length = float(
            np.linalg.norm(mesh.physical_nodes[second] - mesh.physical_nodes[first])
        )
        local_triangle = mesh.elements[element]
        local_first = int(np.flatnonzero(local_triangle == first)[0])
        local_second = int(np.flatnonzero(local_triangle == second)[0])
        for segment in range(segments):
            parameter = (segment + 0.5) / segments
            point = (1.0 - parameter) * first_ref + parameter * second_ref
            flux_value = (
                (1.0 - parameter) * local_flux[element, local_first]
                + parameter * local_flux[element, local_second]
            )
            residual_value = float(
                exact_neumann(mesh, point, normal, contrast)
                - np.dot(flux_value, normal)
            )
            local_flux_slope = (
                local_flux[element, local_second] - local_flux[element, local_first]
            )
            residual_lipschitz = exact_flux_lipschitz + float(
                np.linalg.norm(local_flux_slope)
            ) / max(edge_reference_length, np.finfo(float).tiny)
            half_reference_segment = edge_reference_length / (2.0 * segments)
            upper = abs(residual_value) + residual_lipschitz * half_reference_segment
            physical_segment = edge_physical_length / segments
            neumann_squared_upper += physical_segment * upper**2
            neumann_integral += physical_segment * residual_value

    poincare, trace = explicit_constants(mesh, boundary_mode)
    mismatch_norm = math.sqrt(max(mismatch_squared_upper, 0.0))
    residual_norm = math.sqrt(max(residual_squared_upper, 0.0))
    boundary_norm = math.sqrt(max(neumann_squared_upper, 0.0))
    majorant = mismatch_norm + poincare * residual_norm + trace * boundary_norm
    return {
        "flux_mismatch_upper": mismatch_norm,
        "equilibrium_residual_upper": residual_norm,
        "neumann_residual_upper": boundary_norm,
        "poincare_constant": poincare,
        "trace_constant": trace,
        "functional_majorant": majorant,
        "neumann_edges": neumann_edges,
        "neumann_residual_signed_midpoint_integral": neumann_integral,
    }


def equilibrated_functional_upper_sum(
    mesh: AuditMesh,
    boundary_mode: str,
    contrast: float,
    depth: int,
    equilibrated: dict[str, object],
) -> dict[str, float]:
    """Upper-sum functional majorant for the equilibrated RT0 field."""
    areas = np.asarray(equilibrated["areas"])
    field_gradients = np.asarray(equilibrated["field_gradients"])
    local_outward = np.asarray(equilibrated["local_outward_integrals"])
    reference_elements = mesh.reference_nodes[mesh.elements]
    physical_elements = mesh.physical_nodes[mesh.elements]
    pieces = subdivisions(depth)
    centers = np.mean(pieces, axis=1)
    reference_points = np.einsum(
        "sb,tbd->tsd", centers, reference_elements
    )
    physical_points = np.einsum(
        "sb,tbd->tsd", centers, physical_elements
    )
    maximum_reference_diameter = np.maximum.reduce(
        [
            np.linalg.norm(
                reference_elements[:, 0] - reference_elements[:, 1], axis=1
            ),
            np.linalg.norm(
                reference_elements[:, 1] - reference_elements[:, 2], axis=1
            ),
            np.linalg.norm(
                reference_elements[:, 2] - reference_elements[:, 0], axis=1
            ),
        ]
    )
    radius = maximum_reference_diameter[:, None] / (2.0**depth)
    differences = (
        physical_points[:, :, None, :] - physical_elements[:, None, :, :]
    )
    flux_values = np.einsum(
        "ti,tsid->tsd", local_outward, differences
    ) / (2.0 * areas[:, None, None])
    divergences = np.sum(local_outward, axis=1) / areas
    forcing_values = forcing(mesh, reference_points, contrast)
    residual_upper = (
        np.abs(forcing_values + divergences[:, None])
        + forcing_reference_lipschitz_bound(mesh, contrast) * radius
    )
    residual_squared_upper = float(
        np.sum(areas[:, None] * residual_upper**2 / len(pieces))
    )

    coefficient_values = coefficient(reference_points, contrast)
    mismatch_values = (
        flux_values
        - coefficient_values[..., None] * field_gradients[:, None, :]
    )
    jacobian, _ = affine_matrices(mesh)
    dilation = np.sum(local_outward, axis=1) / (2.0 * areas)
    flux_reference_gradients = dilation[:, None, None] * jacobian[None, :, :]
    coefficient_reference_gradient = np.array([contrast - 1.0, 0.0])
    mismatch_reference_gradients = (
        flux_reference_gradients
        - field_gradients[:, :, None]
        * coefficient_reference_gradient[None, None, :]
    )
    mismatch_lipschitz = np.linalg.norm(
        mismatch_reference_gradients, axis=(1, 2)
    )
    mismatch_upper = (
        np.linalg.norm(mismatch_values, axis=2)
        + mismatch_lipschitz[:, None] * radius
    )
    mismatch_squared_upper = float(
        np.sum(areas[:, None] * mismatch_upper**2 / len(pieces))
    )

    neumann_squared_upper = 0.0
    neumann_edges = 0
    segments = 2 ** (depth + 1)
    exact_flux_lipschitz = exact_flux_reference_lipschitz_bound(mesh, contrast)
    for first, second, element, normal in boundary_edges(mesh):
        if not is_neumann_edge(mesh, first, second, boundary_mode):
            continue
        neumann_edges += 1
        triangle = mesh.elements[element]
        local_edge_vertices = {
            int(np.flatnonzero(triangle == first)[0]),
            int(np.flatnonzero(triangle == second)[0]),
        }
        opposite = next(index for index in range(3) if index not in local_edge_vertices)
        physical_length = float(
            np.linalg.norm(mesh.physical_nodes[second] - mesh.physical_nodes[first])
        )
        first_ref, second_ref = mesh.reference_nodes[[first, second]]
        reference_length = float(np.linalg.norm(second_ref - first_ref))
        normal_trace = local_outward[element, opposite] / physical_length
        for segment in range(segments):
            parameter = (segment + 0.5) / segments
            point = (1.0 - parameter) * first_ref + parameter * second_ref
            residual_value = float(
                exact_neumann(mesh, point, normal, contrast) - normal_trace
            )
            half_reference_segment = reference_length / (2.0 * segments)
            upper = (
                abs(residual_value)
                + exact_flux_lipschitz * half_reference_segment
            )
            neumann_squared_upper += physical_length / segments * upper**2

    poincare, trace = explicit_constants(mesh, boundary_mode)
    mismatch_norm = math.sqrt(max(mismatch_squared_upper, 0.0))
    residual_norm = math.sqrt(max(residual_squared_upper, 0.0))
    boundary_norm = math.sqrt(max(neumann_squared_upper, 0.0))
    majorant = mismatch_norm + poincare * residual_norm + trace * boundary_norm
    return {
        "flux_mismatch_upper": mismatch_norm,
        "equilibrium_residual_upper": residual_norm,
        "neumann_residual_upper": boundary_norm,
        "functional_majorant": majorant,
        "poincare_constant": poincare,
        "trace_constant": trace,
        "neumann_edges": neumann_edges,
    }


def edge_and_balance_audit(
    mesh: AuditMesh,
    values: np.ndarray,
    boundary_mode: str,
    contrast: float,
) -> dict[str, float | int | bool | str]:
    nodal_flux, _, gradients, areas = recover_flux_independently(
        mesh, values, contrast
    )
    local_flux = nodal_flux[mesh.elements]
    divergences = np.einsum("tij,tij->t", local_flux, gradients)
    incidence: dict[tuple[int, int], list[tuple[int, int, int]]] = {}
    for element_index, triangle in enumerate(mesh.elements):
        for local_first, local_second in ((0, 1), (1, 2), (2, 0)):
            edge = tuple(
                sorted(
                    (
                        int(triangle[local_first]),
                        int(triangle[local_second]),
                    )
                )
            )
            incidence.setdefault(edge, []).append(
                (element_index, local_first, local_second)
            )
    maximum_jump = 0.0
    interior_edges = 0
    for (first, second), adjacent in incidence.items():
        if len(adjacent) != 2:
            continue
        interior_edges += 1
        tangent = mesh.physical_nodes[second] - mesh.physical_nodes[first]
        normal = np.array([tangent[1], -tangent[0]], dtype=float)
        normal /= np.linalg.norm(normal)
        traces = []
        for element, _, _ in adjacent:
            triangle = mesh.elements[element]
            first_local = int(np.flatnonzero(triangle == first)[0])
            second_local = int(np.flatnonzero(triangle == second)[0])
            midpoint_flux = 0.5 * (
                local_flux[element, first_local] + local_flux[element, second_local]
            )
            traces.append(float(np.dot(midpoint_flux, normal)))
        maximum_jump = max(maximum_jump, abs(traces[0] - traces[1]))

    centers = np.mean(mesh.reference_nodes[mesh.elements], axis=1)
    element_defects = areas * (forcing(mesh, centers, contrast) + divergences)
    forcing_scale = math.sqrt(
        float(np.sum(areas * forcing(mesh, centers, contrast) ** 2))
    )
    balance_l2 = math.sqrt(float(np.sum(element_defects**2 / areas)))
    flux_scale = float(np.max(np.linalg.norm(nodal_flux, axis=1)))
    tolerance = 500.0 * np.finfo(float).eps * max(1.0, flux_scale)
    return {
        "flux_space": "independently recovered continuous vector P1",
        "interior_edges_checked": interior_edges,
        "max_interior_normal_trace_difference": maximum_jump,
        "normal_continuity_tolerance": tolerance,
        "hdiv_conformity_passed": bool(maximum_jump <= tolerance),
        "max_abs_element_balance_defect": float(np.max(np.abs(element_defects))),
        "median_abs_element_balance_defect": float(np.median(np.abs(element_defects))),
        "piecewise_midpoint_balance_l2": balance_l2,
        "balance_l2_over_forcing_l2": balance_l2 / max(forcing_scale, 1.0e-30),
        "signed_global_volume_balance_defect": float(np.sum(element_defects)),
        "local_equilibrium_exact": False,
        "equilibrium_interpretation": (
            "H(div) conformity passes independently; local equilibrium is not "
            "imposed and is covered by the majorant residual term."
        ),
        "boundary_mode": boundary_mode,
    }


def energy_error_diagnostic(
    mesh: AuditMesh, values: np.ndarray, contrast: float
) -> float:
    _, gradients, areas = element_geometry(mesh)
    field_gradients = np.einsum("ti,tij->tj", values[mesh.elements], gradients)
    total = 0.0
    for element_index, triangle in enumerate(mesh.elements):
        reference = mesh.reference_nodes[triangle]
        for weight, barycentric in triangle_rule():
            point = np.asarray(barycentric) @ reference
            _, inverse_transpose = affine_matrices(mesh)
            exact_gradient = exact_reference_gradient(point) @ inverse_transpose.T
            difference = exact_gradient - field_gradients[element_index]
            total += (
                weight
                * areas[element_index]
                * float(coefficient(point, contrast))
                * float(np.dot(difference, difference))
            )
    return math.sqrt(max(total, 0.0))


def residual_indicator(
    mesh: AuditMesh, values: np.ndarray, contrast: float
) -> float:
    nodal_flux, field_gradients, _, areas = recover_flux_independently(
        mesh, values, contrast
    )
    del nodal_flux
    reference = mesh.reference_nodes[mesh.elements]
    physical = mesh.physical_nodes[mesh.elements]
    centroids = np.mean(reference, axis=1)
    diameters = np.maximum.reduce(
        [
            np.linalg.norm(physical[:, 0] - physical[:, 1], axis=1),
            np.linalg.norm(physical[:, 1] - physical[:, 2], axis=1),
            np.linalg.norm(physical[:, 2] - physical[:, 0], axis=1),
        ]
    )
    volume = float(
        np.sum(areas * diameters**2 * forcing(mesh, centroids, contrast) ** 2)
    )
    raw_flux = coefficient(centroids, contrast)[:, None] * field_gradients
    incidence: dict[tuple[int, int], list[int]] = {}
    for element_index, triangle in enumerate(mesh.elements):
        for first, second in ((triangle[0], triangle[1]), (triangle[1], triangle[2]), (triangle[2], triangle[0])):
            incidence.setdefault(tuple(sorted((int(first), int(second)))), []).append(element_index)
    jump = 0.0
    for (first, second), adjacent in incidence.items():
        if len(adjacent) != 2:
            continue
        tangent = mesh.physical_nodes[second] - mesh.physical_nodes[first]
        length = float(np.linalg.norm(tangent))
        normal = np.array([tangent[1], -tangent[0]], dtype=float) / length
        value = float(np.dot(raw_flux[adjacent[0]] - raw_flux[adjacent[1]], normal))
        jump += length**2 * value**2
    return math.sqrt(max(volume + jump, 0.0))


def discrete_residual_bounds(
    mesh: AuditMesh,
    matrix: csr_matrix,
    load: np.ndarray,
    values: np.ndarray,
    dirichlet: np.ndarray,
    boundary_mode: str,
) -> tuple[float, float, float]:
    free = np.flatnonzero(~dirichlet)
    residual = (load - matrix @ values)[free]
    free_matrix = matrix[free][:, free]
    correction = spsolve(free_matrix, residual)
    exact_squared = max(float(np.dot(residual, correction)), 0.0)
    _, _, areas = element_geometry(mesh)
    lumped = np.zeros(len(mesh.physical_nodes), dtype=float)
    for local in range(3):
        np.add.at(lumped, mesh.elements[:, local], areas / 3.0)
    poincare, _ = explicit_constants(mesh, boundary_mode)
    gamma = 1.0 / (4.0 * poincare**2)
    diagonal_squared = float(np.sum(residual**2 / lumped[free])) / gamma
    return math.sqrt(exact_squared), math.sqrt(diagonal_squared), gamma


def run_case(
    n: int,
    shear: float,
    stretch: float,
    contrast: float,
    boundary_mode: str,
    perturbation: float,
    depths: list[int],
) -> tuple[dict[str, object], list[dict[str, object]]]:
    mesh = build_mesh(n, shear, stretch)
    matrix, load = assemble_problem(mesh, boundary_mode, contrast)
    dirichlet = is_dirichlet_node(mesh, boundary_mode)
    finite_element = solve_problem(matrix, load, dirichlet)
    prediction = finite_element + prediction_perturbation(mesh, perturbation)
    prediction[dirichlet] = 0.0
    error = energy_error_diagnostic(mesh, prediction, contrast)
    delta, diagonal, gamma = discrete_residual_bounds(
        mesh, matrix, load, prediction, dirichlet, boundary_mode
    )
    residual = residual_indicator(mesh, prediction, contrast)
    balance = edge_and_balance_audit(mesh, prediction, boundary_mode, contrast)
    equilibrated = equilibrate_rt0_flux(
        mesh, prediction, boundary_mode, contrast
    )
    depth_rows = []
    for depth in depths:
        majorant = functional_upper_sum(
            mesh, prediction, boundary_mode, contrast, depth
        )
        equilibrated_majorant = equilibrated_functional_upper_sum(
            mesh,
            boundary_mode,
            contrast,
            depth,
            equilibrated,
        )
        depth_rows.append(
            {
                "n": n,
                "shear": shear,
                "stretch": stretch,
                "contrast": contrast,
                "boundary_mode": boundary_mode,
                "perturbation": perturbation,
                "upper_sum_depth": depth,
                "energy_error_floating_quadrature": error,
                "functional_majorant_float": majorant["functional_majorant"],
                "functional_effectivity_float": majorant["functional_majorant"] / error,
                "floating_coverage_diagnostic": bool(
                    majorant["functional_majorant"] + 1.0e-11 >= error
                ),
                "equilibrated_functional_majorant_float": equilibrated_majorant[
                    "functional_majorant"
                ],
                "equilibrated_functional_effectivity_float": equilibrated_majorant[
                    "functional_majorant"
                ]
                / error,
                "equilibrated_floating_coverage_diagnostic": bool(
                    equilibrated_majorant["functional_majorant"] + 1.0e-11
                    >= error
                ),
                "equilibrated_flux_mismatch_upper": equilibrated_majorant[
                    "flux_mismatch_upper"
                ],
                "equilibrated_equilibrium_residual_upper": equilibrated_majorant[
                    "equilibrium_residual_upper"
                ],
                "equilibrated_neumann_residual_upper": equilibrated_majorant[
                    "neumann_residual_upper"
                ],
                **majorant,
            }
        )
    finest = depth_rows[-1]
    row: dict[str, object] = {
        "n": n,
        "nodes": len(mesh.physical_nodes),
        "elements": len(mesh.elements),
        "shear": shear,
        "stretch": stretch,
        "contrast": contrast,
        "boundary_mode": boundary_mode,
        "perturbation": perturbation,
        "energy_error_floating_quadrature": error,
        "residual_indicator": residual,
        "exact_delta_h": delta,
        "diagonal_delta_upper": diagonal,
        "diagonal_gamma": gamma,
        "diagonal_covers_exact_delta": bool(diagonal + 1.0e-11 >= delta),
        "functional_majorant_finest": finest["functional_majorant_float"],
        "functional_effectivity_finest": finest["functional_effectivity_float"],
        "floating_coverage_finest": finest["floating_coverage_diagnostic"],
        "equilibrated_functional_majorant_finest": finest[
            "equilibrated_functional_majorant_float"
        ],
        "equilibrated_functional_effectivity_finest": finest[
            "equilibrated_functional_effectivity_float"
        ],
        "equilibrated_floating_coverage_finest": finest[
            "equilibrated_floating_coverage_diagnostic"
        ],
        "equilibrated_flux_space": equilibrated["flux_space"],
        "equilibration_scope": equilibrated["equilibration_scope"],
        "equilibrated_max_abs_algebraic_balance_defect": equilibrated[
            "max_abs_algebraic_balance_defect"
        ],
        "equilibrated_max_abs_independent_balance_defect": equilibrated[
            "max_abs_independent_balance_defect"
        ],
        "equilibrated_signed_global_balance_defect": equilibrated[
            "signed_global_independent_balance_defect"
        ],
        "equilibrated_max_interior_normal_trace_difference": equilibrated[
            "max_interior_normal_trace_difference"
        ],
        "equilibrated_max_neumann_flux_moment_defect": equilibrated[
            "max_neumann_flux_moment_defect"
        ],
        "equilibrated_balance_tolerance": equilibrated["balance_tolerance"],
        "equilibrated_local_integral_equilibrium_passed": equilibrated[
            "local_integral_equilibrium_passed"
        ],
        "equilibrated_independent_quadrature_consistent": equilibrated[
            "independent_quadrature_consistent"
        ],
        "equilibrated_hdiv_conformity_passed": equilibrated[
            "hdiv_conformity_passed"
        ],
        "equilibrated_neumann_moment_balance_passed": equilibrated[
            "neumann_moment_balance_passed"
        ],
        **balance,
    }
    return row, depth_rows


def confidence_interval(values: list[float]) -> tuple[float, float]:
    if len(values) < 2:
        return values[0], values[0]
    mean = statistics.mean(values)
    half_width = 1.96 * statistics.stdev(values) / math.sqrt(len(values))
    return mean - half_width, mean + half_width


def summarize(rows: list[dict[str, object]]) -> dict[str, object]:
    effectivities = [float(row["functional_effectivity_finest"]) for row in rows]
    balance_ratios = [float(row["balance_l2_over_forcing_l2"]) for row in rows]
    interval = confidence_interval(effectivities)
    equilibrated_effectivities = [
        float(row["equilibrated_functional_effectivity_finest"])
        for row in rows
    ]
    return {
        "cases": len(rows),
        "hdiv_pass_rate": statistics.mean(
            float(bool(row["hdiv_conformity_passed"])) for row in rows
        ),
        "diagonal_bound_pass_rate": statistics.mean(
            float(bool(row["diagonal_covers_exact_delta"])) for row in rows
        ),
        "floating_majorant_coverage_rate": statistics.mean(
            float(bool(row["floating_coverage_finest"])) for row in rows
        ),
        "effectivity_mean": statistics.mean(effectivities),
        "effectivity_median": statistics.median(effectivities),
        "effectivity_std": statistics.stdev(effectivities) if len(effectivities) > 1 else 0.0,
        "effectivity_min": min(effectivities),
        "effectivity_max": max(effectivities),
        "effectivity_mean_normal_95pct_ci": list(interval),
        "balance_ratio_median": statistics.median(balance_ratios),
        "balance_ratio_max": max(balance_ratios),
        "exact_local_equilibrium_rate": statistics.mean(
            float(bool(row["local_equilibrium_exact"])) for row in rows
        ),
        "equilibrated_local_integral_equilibrium_rate": statistics.mean(
            float(bool(row["equilibrated_local_integral_equilibrium_passed"]))
            for row in rows
        ),
        "equilibrated_independent_quadrature_consistency_rate": statistics.mean(
            float(bool(row["equilibrated_independent_quadrature_consistent"]))
            for row in rows
        ),
        "equilibrated_hdiv_pass_rate": statistics.mean(
            float(bool(row["equilibrated_hdiv_conformity_passed"]))
            for row in rows
        ),
        "equilibrated_neumann_moment_balance_rate": statistics.mean(
            float(bool(row["equilibrated_neumann_moment_balance_passed"]))
            for row in rows
        ),
        "equilibrated_floating_majorant_coverage_rate": statistics.mean(
            float(bool(row["equilibrated_floating_coverage_finest"]))
            for row in rows
        ),
        "equilibrated_effectivity_mean": statistics.mean(
            equilibrated_effectivities
        ),
        "equilibrated_effectivity_median": statistics.median(
            equilibrated_effectivities
        ),
        "equilibrated_effectivity_max": max(equilibrated_effectivities),
        "equilibrated_effectivity_min": min(equilibrated_effectivities),
    }


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--levels", nargs="+", type=int, default=[8, 16, 32])
    parser.add_argument("--contrasts", nargs="+", type=float, default=[1.0, 10.0, 100.0])
    parser.add_argument("--boundary-modes", nargs="+", default=["dirichlet", "mixed"])
    parser.add_argument("--depths", nargs="+", type=int, default=[0, 1, 2])
    parser.add_argument("--shear", type=float, default=0.35)
    parser.add_argument("--stretch", type=float, default=0.80)
    parser.add_argument(
        "--geometry-cases",
        nargs="+",
        help="Optional shear,stretch pairs, for example 0.35,0.80 0.85,0.30",
    )
    parser.add_argument("--perturbation", type=float, default=0.04)
    parser.add_argument(
        "--summary-out",
        type=Path,
        default=Path("experiments/results/independent_flux_audit_summary.json"),
    )
    parser.add_argument(
        "--rows-out",
        type=Path,
        default=Path("experiments/results/independent_flux_audit_rows.csv"),
    )
    parser.add_argument(
        "--depth-rows-out",
        type=Path,
        default=Path("experiments/results/independent_flux_audit_depth_rows.csv"),
    )
    parser.add_argument(
        "--failures-out",
        type=Path,
        default=Path("experiments/results/independent_flux_audit_failures.json"),
    )
    args = parser.parse_args()

    invalid_modes = set(args.boundary_modes) - {"dirichlet", "mixed"}
    if invalid_modes:
        raise ValueError(f"unknown boundary modes: {sorted(invalid_modes)}")
    if args.geometry_cases:
        geometries = []
        for item in args.geometry_cases:
            pieces = item.split(",")
            if len(pieces) != 2:
                raise ValueError(f"invalid geometry pair: {item}")
            geometries.append((float(pieces[0]), float(pieces[1])))
    else:
        geometries = [
            (args.shear, args.stretch),
            (0.60, 1.40),
            (0.85, 0.30),
        ]
    if any(stretch <= 0.0 for _, stretch in geometries):
        raise ValueError("every affine stretch must be positive")
    rows: list[dict[str, object]] = []
    depth_rows: list[dict[str, object]] = []
    for mode in args.boundary_modes:
        for shear, stretch in geometries:
            for contrast in args.contrasts:
                for n in args.levels:
                    row, refinements = run_case(
                        n,
                        shear,
                        stretch,
                        contrast,
                        mode,
                        args.perturbation,
                        args.depths,
                    )
                    rows.append(row)
                    depth_rows.extend(refinements)
                    print(
                        f"mode={mode:9s} geom=({shear:.2f},{stretch:.2f}) "
                        f"contrast={contrast:6.1f} n={n:3d} "
                        f"Hdiv={row['hdiv_conformity_passed']} "
                        f"RT0-balance={row['equilibrated_local_integral_equilibrium_passed']} "
                        f"diag={row['diagonal_covers_exact_delta']} "
                        f"eff={row['functional_effectivity_finest']:.3f} "
                        f"balance={row['balance_l2_over_forcing_l2']:.3e}"
                    )

    failures = []
    for row in rows:
        failed = []
        if not bool(row["hdiv_conformity_passed"]):
            failed.append("H(div) normal continuity")
        if not bool(row["diagonal_covers_exact_delta"]):
            failed.append("explicit diagonal upper bound")
        if not bool(row["floating_coverage_finest"]):
            failed.append("floating majorant coverage diagnostic")
        if not bool(row["equilibrated_local_integral_equilibrium_passed"]):
            failed.append("equilibrated RT0 local integral balance")
        if not bool(row["equilibrated_independent_quadrature_consistent"]):
            failed.append("equilibrated RT0 independent quadrature check")
        if not bool(row["equilibrated_hdiv_conformity_passed"]):
            failed.append("equilibrated RT0 H(div) normal continuity")
        if not bool(row["equilibrated_neumann_moment_balance_passed"]):
            failed.append("equilibrated RT0 Neumann moment balance")
        if not bool(row["equilibrated_floating_coverage_finest"]):
            failed.append("equilibrated floating majorant coverage diagnostic")
        if failed:
            failures.append({"failed_checks": failed, "case": row})
    refinement_groups: dict[tuple[object, ...], list[dict[str, object]]] = {}
    for row in depth_rows:
        key = (
            row["boundary_mode"],
            row["n"],
            row["shear"],
            row["stretch"],
            row["contrast"],
            row["perturbation"],
        )
        refinement_groups.setdefault(key, []).append(row)
    monotonic_failures = []
    for key, group in refinement_groups.items():
        ordered = sorted(group, key=lambda row: int(row["upper_sum_depth"]))
        values = [float(row["functional_majorant_float"]) for row in ordered]
        equilibrated_values = [
            float(row["equilibrated_functional_majorant_float"])
            for row in ordered
        ]
        recovered_failed = any(
            right > left * (1.0 + 1.0e-12)
            for left, right in zip(values, values[1:])
        )
        equilibrated_failed = any(
            right > left * (1.0 + 1.0e-12)
            for left, right in zip(equilibrated_values, equilibrated_values[1:])
        )
        if recovered_failed or equilibrated_failed:
            failure = {
                "failed_checks": ["upper-sum monotonic refinement"],
                "case_key": key,
                "recovered_values": values,
                "equilibrated_values": equilibrated_values,
            }
            monotonic_failures.append(failure)
            failures.append(failure)

    summary = {
        "audit_independence": (
            "This script imports no project implementation. Mesh generation, "
            "assembly, recovery, residuals, and majorants are reimplemented here."
        ),
        "strictness_scope": (
            "The majorant ingredients are analytic upper sums with explicit "
            "constants. The manufactured-error comparison and sparse solves use "
            "ordinary floating arithmetic, so coverage is a diagnostic rather "
            "than a machine-rigorous interval."
        ),
        "equilibrated_flux_scope": (
            "The RT0 branch enforces local integral equilibrium and H(div) "
            "normal continuity. It uses a global constrained projection and is "
            "therefore not represented as a cheap patch-local reconstruction."
        ),
        "config": {
            "levels": args.levels,
            "contrasts": args.contrasts,
            "boundary_modes": args.boundary_modes,
            "depths": args.depths,
            "geometries": geometries,
            "perturbation": args.perturbation,
        },
        "software": {
            "python": platform.python_version(),
            "numpy": np.__version__,
            "scipy": scipy.__version__,
            "platform": platform.platform(),
        },
        "summary": summarize(rows),
        "upper_sum_monotonic_groups": len(refinement_groups),
        "upper_sum_monotonic_failure_count": len(monotonic_failures),
        "rows": rows,
        "failure_count": len(failures),
    }
    args.summary_out.parent.mkdir(parents=True, exist_ok=True)
    args.summary_out.write_text(json.dumps(summary, indent=2, sort_keys=True), encoding="utf-8")
    args.failures_out.write_text(json.dumps(failures, indent=2, sort_keys=True), encoding="utf-8")
    write_csv(args.rows_out, rows)
    write_csv(args.depth_rows_out, depth_rows)

    if any(not bool(row["hdiv_conformity_passed"]) for row in rows):
        raise AssertionError("independent H(div) audit failed; see failures JSON")
    if any(not bool(row["diagonal_covers_exact_delta"]) for row in rows):
        raise AssertionError("diagonal residual upper bound failed; see failures JSON")
    if monotonic_failures:
        raise AssertionError("upper-sum refinement was not monotone; see failures JSON")
    required_equilibrated_checks = (
        "equilibrated_local_integral_equilibrium_passed",
        "equilibrated_independent_quadrature_consistent",
        "equilibrated_hdiv_conformity_passed",
        "equilibrated_neumann_moment_balance_passed",
        "equilibrated_floating_coverage_finest",
    )
    if any(
        not bool(row[name]) for row in rows for name in required_equilibrated_checks
    ):
        raise AssertionError("equilibrated RT0 audit failed; see failures JSON")


if __name__ == "__main__":
    main()
