"""Complete RT2 same-space certificate audit for all fixed tests/checkpoints.

The claim-facing audit contains all 90 fixed geometries for each of the three
released compact-spectral checkpoints (270 prediction--certificate pairs).  It
supports resumable split-wise execution so an interrupted full recomputation
does not discard completed work.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import statistics
import sys
import time
from pathlib import Path
from typing import Any

os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")

import numpy as np
from scipy.stats import spearmanr

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

import independent_forcing_operator_pipeline as base
import independent_forcing_rt_reference_audit as rt

SEEDS = (27182, 31415, 16180)
SPLITS = ("id", "mild_shift", "strong_ood")
RESULTS = SCRIPT_DIR / "results"
ROWS_PATH = RESULTS / "independent_forcing_multicheckpoint_rt2_rows.csv"
SUMMARY_PATH = RESULTS / "independent_forcing_multicheckpoint_rt2_summary.json"
PARTS_DIR = RESULTS / "independent_forcing_multicheckpoint_rt2_parts"


def quantiles(values: list[float]) -> dict[str, float]:
    array = np.asarray(values, dtype=float)
    return {
        "median": float(np.median(array)),
        "q95": float(np.quantile(array, 0.95)),
        "max": float(np.max(array)),
    }


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def run_seed_split(seed: int, split: str, iterations: int) -> list[dict[str, Any]]:
    cases, _ = rt.cases()
    selected = [case for case in cases if case.split == split]
    first = base.solve_fast(16, selected[0])
    predictor = rt.load_predictor(RESULTS, seed, first["boundary"])
    rows: list[dict[str, Any]] = []
    for index, case in enumerate(selected, 1):
        solution = base.solve_fast(16, case)
        prediction = np.asarray(
            base.predict(predictor, np.stack([base.features(solution, case)]), "fno")[0],
            dtype=float,
        )
        prediction[solution["boundary"]] = 0.0
        difference = prediction - solution["u"]
        error = math.sqrt(max(float(difference @ (solution["A"] @ difference)), 0.0))
        result = rt.optimize_rt(solution, case, prediction, order=1, iterations=iterations)
        majorant = float(result["majorant"])
        rows.append(
            {
                "seed": seed,
                "split": case.split,
                "geometry_id": case.geometry_id,
                "contrast": case.contrast,
                "minimum_jacobian_ratio": solution["min_jacobian_ratio"],
                "same_space_error": error,
                "majorant": majorant,
                "effectivity": majorant / max(error, 1.0e-30),
                "covered": bool(majorant + 1.0e-10 >= error),
                "max_local_basis_condition": result["max_local_basis_condition"],
                "relative_linear_residual": result["relative_linear_residual"],
                "certification_seconds": result["certification_seconds"],
                "reweight_iterations": result["iterations"],
            }
        )
        if index % 10 == 0:
            print(f"seed={seed} split={split}: {index}/30", flush=True)
    return rows


def validate_part(rows: list[dict[str, Any]], seed: int, split: str) -> None:
    expected = {(seed, split, geometry_id) for geometry_id in range(30)}
    actual = {
        (int(row["seed"]), str(row["split"]), int(row["geometry_id"]))
        for row in rows
    }
    if actual != expected:
        raise RuntimeError(f"invalid or incomplete RT2 part for seed={seed}, split={split}")


def summarize(rows: list[dict[str, Any]]) -> dict[str, Any]:
    grouped: dict[str, Any] = {}
    for seed_key in (*SEEDS, "all"):
        seed_rows = rows if seed_key == "all" else [row for row in rows if int(row["seed"]) == seed_key]
        split_groups: dict[str, Any] = {}
        for split in (*SPLITS, "overall"):
            block = seed_rows if split == "overall" else [row for row in seed_rows if row["split"] == split]
            split_groups[split] = {
                "cases": len(block),
                "coverage_rate": statistics.fmean(float(row["covered"]) for row in block),
                "effectivity": quantiles([float(row["effectivity"]) for row in block]),
                "certification_seconds": quantiles([float(row["certification_seconds"]) for row in block]),
                "max_local_basis_condition": max(float(row["max_local_basis_condition"]) for row in block),
                "relative_linear_residual": quantiles(
                    [float(row["relative_linear_residual"]) for row in block]
                ),
            }
        grouped[str(seed_key)] = split_groups
    effectivity = np.asarray([float(row["effectivity"]) for row in rows])
    contrasts = np.asarray([float(row["contrast"]) for row in rows])
    jacobians = np.asarray([float(row["minimum_jacobian_ratio"]) for row in rows])
    rho_contrast, p_contrast = spearmanr(effectivity, contrasts)
    rho_jacobian, p_jacobian = spearmanr(effectivity, jacobians)
    return {
        "benchmark": "independent_forcing_complete_multicheckpoint_same_space_rt2",
        "checkpoint_seeds": list(SEEDS),
        "checkpoint_sha256": {
            str(seed): sha256(RESULTS / f"independent_forcing_compact_fno_seed{seed}.pt")
            for seed in SEEDS
        },
        "cases": len(rows),
        "selection": "all 90 fixed test geometries for each of the three frozen checkpoints; no case subsampling",
        "certificate_target": "same-space Galerkin energy error of each realized conforming P1 trial field",
        "arithmetic_scope": "ordinary binary64 evaluation of an exact-arithmetic functional majorant",
        "fine_grid_semantics": "reference-grid sensitivity is assessed separately and is not a validity test for a different reconstructed field",
        "linear_algebra_safeguard": "direct sparse solve with residual check and one correction step when required",
        "all_covered": all(bool(row["covered"]) for row in rows),
        "grouped": grouped,
        "geometry_sensitivity": {
            "spearman_effectivity_vs_contrast": {
                "rho": float(rho_contrast),
                "p_value": float(p_contrast),
            },
            "spearman_effectivity_vs_minimum_jacobian_ratio": {
                "rho": float(rho_jacobian),
                "p_value": float(p_jacobian),
            },
        },
    }


def write_rows(rows: list[dict[str, Any]]) -> None:
    fields = [
        "seed",
        "split",
        "geometry_id",
        "contrast",
        "minimum_jacobian_ratio",
        "same_space_error",
        "majorant",
        "effectivity",
        "covered",
        "max_local_basis_condition",
        "relative_linear_residual",
        "certification_seconds",
        "reweight_iterations",
    ]
    with ROWS_PATH.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def load_rows() -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    with ROWS_PATH.open(newline="", encoding="utf-8") as handle:
        for raw in csv.DictReader(handle):
            row: dict[str, Any] = {}
            for key, value in raw.items():
                if key == "split":
                    row[key] = value
                elif key == "covered":
                    row[key] = value.lower() == "true"
                elif key in {"seed", "geometry_id", "reweight_iterations"}:
                    row[key] = int(value)
                else:
                    row[key] = float(value)
            rows.append(row)
    return rows


def run(iterations: int, resume: bool) -> dict[str, Any]:
    PARTS_DIR.mkdir(parents=True, exist_ok=True)
    rows: list[dict[str, Any]] = []
    for seed in SEEDS:
        for split in SPLITS:
            part_path = PARTS_DIR / f"seed{seed}_{split}.json"
            if resume and part_path.is_file():
                part = json.loads(part_path.read_text(encoding="utf-8"))
                validate_part(part, seed, split)
                print(f"reusing {part_path.relative_to(SCRIPT_DIR.parent)}", flush=True)
            else:
                part = run_seed_split(seed, split, iterations)
                validate_part(part, seed, split)
                part_path.write_text(json.dumps(part, indent=2) + "\n", encoding="utf-8")
            rows.extend(part)
    rows.sort(
        key=lambda row: (
            int(row["seed"]),
            SPLITS.index(str(row["split"])),
            int(row["geometry_id"]),
        )
    )
    summary = summarize(rows)
    write_rows(rows)
    SUMMARY_PATH.write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return summary


def verify() -> dict[str, Any]:
    rows = load_rows()
    expected = {
        (seed, split, geometry_id)
        for seed in SEEDS
        for split in SPLITS
        for geometry_id in range(30)
    }
    actual = {
        (int(row["seed"]), str(row["split"]), int(row["geometry_id"]))
        for row in rows
    }
    if actual != expected or len(rows) != 270:
        raise RuntimeError("multicheckpoint RT2 row set is incomplete or duplicated")
    rebuilt = summarize(rows)
    released = json.loads(SUMMARY_PATH.read_text(encoding="utf-8"))
    if rebuilt != released:
        raise RuntimeError("multicheckpoint RT2 summary does not match raw rows")
    if not rebuilt["all_covered"]:
        raise RuntimeError("same-space RT2 audit contains a coverage failure")
    maximum_residual = rebuilt["grouped"]["all"]["overall"]["relative_linear_residual"]["max"]
    if maximum_residual > 1.0e-9:
        raise RuntimeError("RT solve residual exceeds tolerance")
    return rebuilt


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--iterations", type=int, default=3)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--verify-existing", action="store_true")
    args = parser.parse_args()
    started = time.perf_counter()
    summary = verify() if args.verify_existing else run(args.iterations, args.resume)
    if not args.verify_existing:
        verify()
    print(
        json.dumps(
            {
                "status": "PASS",
                "cases": summary["cases"],
                "all_covered": summary["all_covered"],
                "elapsed_seconds": time.perf_counter() - started,
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
