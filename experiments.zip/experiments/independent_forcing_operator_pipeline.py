"""Independent forcing-to-solution geometry-dependent operator benchmark.

This benchmark removes the solution-coefficient leakage of the earlier modal
manufactured audit.  The model receives geometry, coefficient, and forcing
information only.  Labels are P1 finite-element solutions of

    -div_x(a grad_x u) = f,  u|_{boundary}=0,

on affine or smoothly warped images of the unit square.  Eight forcing-mode
coefficients are sampled independently of geometry and coefficient contrast.
The exact solution coefficients are never inputs because no closed-form
solution is prescribed.

The script trains a compact FNO-style spectral operator and compares it with
training-mean, parameter-conditioned coordinate MLP, and POD-ridge baselines.
It reports same-space errors against level-16 FE labels and reference errors
against independently assembled level-32 FE solutions.
"""
from __future__ import annotations

import argparse, csv, json, math, random, statistics, time
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any

import numpy as np
import torch
from scipy.sparse import coo_matrix, csr_matrix
from scipy.sparse.linalg import spsolve
from scipy.interpolate import RectBivariateSpline

MODES=((1,1),(2,1),(1,2),(2,2),(3,1),(1,3),(3,2),(2,3))

@dataclass(frozen=True)
class Case:
    split:str; geometry_id:int; shear:float; stretch:float; warp_x:float; warp_y:float; contrast:float
    force1:float; force2:float; force3:float; force4:float; force5:float; force6:float; force7:float; force8:float
    @property
    def force_coeffs(self): return np.array([self.force1,self.force2,self.force3,self.force4,self.force5,self.force6,self.force7,self.force8],float)


def lhs(n,d,seed):
    g=np.random.default_rng(seed); out=np.empty((n,d))
    for j in range(d):
        p=g.permutation(n); out[:,j]=(p+g.random(n))/n
    return out


def inside(c,b):
    for k,v in asdict(c).items():
        if k in ('split','geometry_id'): continue
        if k in b and not (b[k][0] <= v <= b[k][1]): return False
    return True


def sample_cases(split,n,bounds,seed,train_bounds=None,require_out=False):
    names=['shear','stretch','warp_x','warp_y','contrast']+[f'force{i}' for i in range(1,9)]
    out=[]; r=0
    while len(out)<n:
        u=lhs(max(2*(n-len(out)),16),len(names),seed+7919*r); r+=1
        for row in u:
            vals={}
            for j,name in enumerate(names):
                lo,hi=map(float,bounds[name])
                if name=='contrast': vals[name]=10**(math.log10(lo)+row[j]*(math.log10(hi)-math.log10(lo)))
                else: vals[name]=lo+row[j]*(hi-lo)
            c=Case(split,len(out),**vals)
            if require_out and train_bounds is not None and inside(c,train_bounds): continue
            out.append(c)
            if len(out)==n: break
    return out


def map_points(ref,c):
    x=ref[:,0]+c.shear*ref[:,1]+c.warp_x*ref[:,0]*(1-ref[:,0])*np.sin(math.pi*ref[:,1])
    y=c.stretch*ref[:,1]+c.warp_y*ref[:,1]*(1-ref[:,1])*np.sin(math.pi*ref[:,0])
    return np.column_stack([x,y])


def map_jacobian(points,c):
    xi=points[...,0]; eta=points[...,1]
    j11=1+c.warp_x*(1-2*xi)*np.sin(math.pi*eta)
    j12=c.shear+c.warp_x*xi*(1-xi)*math.pi*np.cos(math.pi*eta)
    j21=c.warp_y*eta*(1-eta)*math.pi*np.cos(math.pi*xi)
    j22=c.stretch+c.warp_y*(1-2*eta)*np.sin(math.pi*xi)
    return np.stack([np.stack([j11,j12],-1),np.stack([j21,j22],-1)],-2)


def build_mesh(n,c):
    grid=np.linspace(0,1,n+1); ref=np.array([(x,y) for y in grid for x in grid],float); phys=map_points(ref,c)
    elems=[]
    for j in range(n):
        for i in range(n):
            ll=j*(n+1)+i; lr=ll+1; ul=ll+n+1; ur=ul+1
            elems.extend([(ll,lr,ur),(ll,ur,ul)])
    elems=np.array(elems,np.int64)
    b=(np.isclose(ref[:,0],0)|np.isclose(ref[:,0],1)|np.isclose(ref[:,1],0)|np.isclose(ref[:,1],1))
    return ref,phys,elems,b


def tri_geom(phys,elems):
    xy=phys[elems]; x=xy[:,:,0]; y=xy[:,:,1]
    da=(x[:,1]-x[:,0])*(y[:,2]-y[:,0])-(x[:,2]-x[:,0])*(y[:,1]-y[:,0])
    grads=np.stack([np.stack([y[:,1]-y[:,2],x[:,2]-x[:,1]],1),np.stack([y[:,2]-y[:,0],x[:,0]-x[:,2]],1),np.stack([y[:,0]-y[:,1],x[:,1]-x[:,0]],1)],1)
    grads/=da[:,None,None]
    return grads,0.5*np.abs(da),da


def coeff(points,c):
    xi=points[...,0]; eta=points[...,1]
    shape=0.15+0.55*xi+0.20*eta+0.10*np.sin(math.pi*xi)*np.sin(math.pi*eta)
    return 1+(c.contrast-1)*shape


def forcing(points,c):
    xi=points[...,0]; eta=points[...,1]; v=np.zeros_like(xi,float)
    for a,(kx,ky) in zip(c.force_coeffs,MODES): v += a*np.sin(kx*math.pi*xi)*np.sin(ky*math.pi*eta)
    return v

TRI_RULE=[(0.225,(1/3,1/3,1/3)),(0.132394152788506,(0.059715871789770,0.470142064105115,0.470142064105115)),(0.132394152788506,(0.470142064105115,0.059715871789770,0.470142064105115)),(0.132394152788506,(0.470142064105115,0.470142064105115,0.059715871789770)),(0.125939180544827,(0.797426985353087,0.101286507323456,0.101286507323456)),(0.125939180544827,(0.101286507323456,0.797426985353087,0.101286507323456)),(0.125939180544827,(0.101286507323456,0.101286507323456,0.797426985353087))]


def solve(n,c):
    ref,phys,elems,bound=build_mesh(n,c); grads,areas,da=tri_geom(phys,elems)
    if np.min(da)<=0: raise ValueError('inverted element')
    rows=[]; cols=[]; vals=[]; load=np.zeros(len(ref))
    for e,tri in enumerate(elems):
        rtri=ref[tri]
        for w,bar in TRI_RULE:
            bar=np.asarray(bar); p=bar@rtri; scale=w*areas[e]
            a=float(coeff(p,c)); f=float(forcing(p,c))
            loc=scale*a*(grads[e]@grads[e].T)
            for i in range(3):
                load[tri[i]] += scale*f*bar[i]
                for j in range(3): rows.append(int(tri[i])); cols.append(int(tri[j])); vals.append(float(loc[i,j]))
    A=coo_matrix((vals,(rows,cols)),shape=(len(ref),len(ref))).tocsr(); free=np.flatnonzero(~bound); u=np.zeros(len(ref)); u[free]=spsolve(A[free][:,free],load[free])
    return {'ref':ref,'phys':phys,'elems':elems,'boundary':bound,'A':A,'load':load,'u':u,'min_jacobian_ratio':float(np.min(da)/np.max(da))}



def solve_fast(n,c):
    """Vectorized equivalent of :func:`solve` for audit-scale reruns.

    The quadrature rule, mesh, coefficient, forcing, boundary elimination, and
    sparse solve are identical to ``solve``; only Python element loops are
    replaced by batched NumPy assembly.
    """
    ref,phys,elems,bound=build_mesh(n,c); grads,areas,da=tri_geom(phys,elems)
    if np.min(da)<=0: raise ValueError('inverted element')
    bars=np.asarray([bar for _,bar in TRI_RULE],dtype=float)
    weights=np.asarray([w for w,_ in TRI_RULE],dtype=float)
    rtri=ref[elems]
    points=np.einsum('qk,ekd->eqd',bars,rtri)
    aval=coeff(points,c)
    fval=forcing(points,c)
    int_a=areas*np.einsum('q,eq->e',weights,aval)
    gram=np.einsum('eik,ejk->eij',grads,grads)
    local_stiff=int_a[:,None,None]*gram
    local_load=areas[:,None]*np.einsum('q,eq,qi->ei',weights,fval,bars)
    rows=np.repeat(elems,3,axis=1).reshape(-1)
    cols=np.tile(elems,(1,3)).reshape(-1)
    vals=local_stiff.reshape(-1)
    A=coo_matrix((vals,(rows,cols)),shape=(len(ref),len(ref))).tocsr()
    load=np.zeros(len(ref),dtype=float)
    np.add.at(load,elems.reshape(-1),local_load.reshape(-1))
    free=np.flatnonzero(~bound); u=np.zeros(len(ref)); u[free]=spsolve(A[free][:,free],load[free])
    return {'ref':ref,'phys':phys,'elems':elems,'boundary':bound,'A':A,'load':load,'u':u,'min_jacobian_ratio':float(np.min(da)/np.max(da))}

def features(sol,c):
    ref=sol['ref']; phys=sol['phys']; disp=phys-ref; a=coeff(ref,c)[:,None]; f=forcing(ref,c)[:,None]
    J=map_jacobian(ref,c); det=np.linalg.det(J)[:,None]
    glob=np.array([c.shear,c.stretch,c.warp_x,c.warp_y,math.log10(c.contrast),*c.force_coeffs],float)
    return np.column_stack([ref,phys,disp,a,f,det,np.repeat(glob[None],len(ref),0)])


def dataset(n,cases):
    sols=[solve(n,c) for c in cases]
    return {'features':np.stack([features(s,c) for s,c in zip(sols,cases)]),'targets':np.stack([s['u'] for s in sols]),'sols':sols,'cases':cases}


def energy_rel(A,p,t):
    d=p-t; den=float(t@(A@t)); return math.sqrt(max(float(d@(A@d)),0)/max(den,1e-30))


def interp_grid(values,n_from,n_to):
    g0=np.linspace(0,1,n_from+1); g1=np.linspace(0,1,n_to+1); z=values.reshape(n_from+1,n_from+1)
    return RectBivariateSpline(g0,g0,z,kx=3,ky=3)(g1,g1).reshape(-1)


class SpectralConv2d(torch.nn.Module):
    def __init__(self,cin,cout,modes):
        super().__init__(); self.modes=modes; scale=1/(cin*cout)
        self.w1=torch.nn.Parameter(scale*torch.randn(cin,cout,modes,modes,dtype=torch.cfloat)); self.w2=torch.nn.Parameter(scale*torch.randn(cin,cout,modes,modes,dtype=torch.cfloat))
    def compl(self,x,w): return torch.einsum('bixy,ioxy->boxy',x,w)
    def forward(self,x):
        b,_,h,w=x.shape; xf=torch.fft.rfft2(x); out=torch.zeros(b,self.w1.shape[1],h,w//2+1,dtype=torch.cfloat,device=x.device); m1=min(self.modes,h); m2=min(self.modes,w//2+1)
        out[:,:,:m1,:m2]=self.compl(xf[:,:,:m1,:m2],self.w1[:,:,:m1,:m2]); out[:,:,-m1:,:m2]=self.compl(xf[:,:,-m1:,:m2],self.w2[:,:,:m1,:m2]); return torch.fft.irfft2(out,s=(h,w))

class CompactFNO(torch.nn.Module):
    def __init__(self,cin,width=20,modes=6,layers=3):
        super().__init__(); self.lift=torch.nn.Conv2d(cin,width,1); self.spec=torch.nn.ModuleList([SpectralConv2d(width,width,modes) for _ in range(layers)]); self.local=torch.nn.ModuleList([torch.nn.Conv2d(width,width,1) for _ in range(layers)]); self.proj=torch.nn.Sequential(torch.nn.Conv2d(width,64,1),torch.nn.GELU(),torch.nn.Conv2d(64,1,1))
    def forward(self,x):
        x=self.lift(x)
        for s,l in zip(self.spec,self.local): x=torch.nn.functional.gelu(s(x)+l(x))
        return self.proj(x)

class PointwiseMLP(torch.nn.Module):
    def __init__(self,cin,width=128): super().__init__(); self.net=torch.nn.Sequential(torch.nn.Linear(cin,width),torch.nn.GELU(),torch.nn.Linear(width,width),torch.nn.GELU(),torch.nn.Linear(width,width),torch.nn.GELU(),torch.nn.Linear(width,1))
    def forward(self,x): return self.net(x).squeeze(-1)


def train_model(kind,data,seed,epochs=100,batch=8):
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed); torch.set_num_threads(4)
    X=torch.tensor(data['features'],dtype=torch.float32); Y=torch.tensor(data['targets'],dtype=torch.float32); nside=int(round(math.sqrt(Y.shape[1]))); mask=torch.tensor(~data['sols'][0]['boundary'],dtype=torch.float32)
    # normalize channels and targets globally using training data only
    xm=X.mean((0,1),keepdim=True); xs=X.std((0,1),keepdim=True).clamp_min(1e-6); yn=Y.std().clamp_min(1e-6)
    if kind=='fno': model=CompactFNO(X.shape[-1]);
    else: model=PointwiseMLP(X.shape[-1])
    opt=torch.optim.AdamW(model.parameters(),lr=2e-3,weight_decay=1e-6); sched=torch.optim.lr_scheduler.CosineAnnealingLR(opt,epochs,eta_min=1e-4); gen=np.random.default_rng(seed); hist=[]; t0=time.perf_counter()
    for ep in range(1,epochs+1):
        perm=gen.permutation(len(X)); total=0
        for off in range(0,len(X),batch):
            idx=perm[off:off+batch]; xx=(X[idx]-xm)/xs; yy=Y[idx]/yn; opt.zero_grad(set_to_none=True)
            if kind=='fno': pred=model(xx.permute(0,2,1).reshape(len(idx),X.shape[-1],nside,nside)).squeeze(1).reshape(len(idx),-1)
            else: pred=model(xx)
            pred=pred*mask; loss=((pred-yy)**2).mean()+3*((pred[:,1:]-pred[:,:-1])-(yy[:,1:]-yy[:,:-1])).pow(2).mean(); loss.backward(); torch.nn.utils.clip_grad_norm_(model.parameters(),5); opt.step(); total+=float(loss.detach())
        sched.step()
        if ep in (1,epochs) or ep%20==0: hist.append({'epoch':ep,'loss':total/math.ceil(len(X)/batch)})
    return {'model':model,'xm':xm,'xs':xs,'yn':yn,'mask':mask,'history':hist,'seconds':time.perf_counter()-t0}

@torch.no_grad()
def predict(bundle,features,kind):
    X=torch.tensor(features,dtype=torch.float32); xx=(X-bundle['xm'])/bundle['xs']; nside=int(round(math.sqrt(X.shape[1])))
    if kind=='fno': p=bundle['model'](xx.permute(0,2,1).reshape(len(X),X.shape[-1],nside,nside)).squeeze(1).reshape(len(X),-1)
    else: p=bundle['model'](xx)
    return (p*bundle['yn']*bundle['mask']).cpu().numpy()


def pod_ridge_fit(data,rank=24,lam=1e-5):
    Y=data['targets']; mean=Y.mean(0); U,S,Vt=np.linalg.svd(Y-mean,full_matrices=False); basis=Vt[:min(rank,len(Vt))]
    P=np.array([[c.shear,c.stretch,c.warp_x,c.warp_y,math.log10(c.contrast),*c.force_coeffs] for c in data['cases']]); pm=P.mean(0); ps=P.std(0); ps[ps<1e-12]=1; Z=(P-pm)/ps; Z=np.column_stack([np.ones(len(Z)),Z]); C=(Y-mean)@basis.T; W=np.linalg.solve(Z.T@Z+lam*np.eye(Z.shape[1]),Z.T@C)
    return mean,basis,pm,ps,W

def pod_predict(fit,cases):
    mean,basis,pm,ps,W=fit; P=np.array([[c.shear,c.stretch,c.warp_x,c.warp_y,math.log10(c.contrast),*c.force_coeffs] for c in cases]); Z=np.column_stack([np.ones(len(P)),(P-pm)/ps]); return mean+(Z@W)@basis


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        raise ValueError("cannot write an empty CSV")
    fields = list(rows[0].keys())
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def summarize(rows):
    out={}
    for model in sorted({r['model'] for r in rows}):
        mr=[r for r in rows if r['model']==model]; out[model]={}
        for split in ['id','mild_shift','strong_ood','overall']:
            rr=mr if split=='overall' else [r for r in mr if r['split']==split]; vals=[r['reference_energy_error'] for r in rr]; same=[r['same_space_energy_error'] for r in rr]
            out[model][split]={'predictions':len(rr),'reference_median':float(np.median(vals)),'reference_q95':float(np.quantile(vals,.95)),'reference_max':float(max(vals)),'same_space_median':float(np.median(same))}
    return out


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--output-dir',type=Path,default=Path(__file__).parent/'results'); ap.add_argument('--epochs',type=int,default=120); args=ap.parse_args(); out=args.output_dir; out.mkdir(parents=True,exist_ok=True)
    train_bounds={'shear':[-.22,.22],'stretch':[.82,1.18],'warp_x':[-.08,.08],'warp_y':[-.08,.08],'contrast':[1,30],**{f'force{i}':[-1,1] for i in range(1,9)}}
    idb=train_bounds
    mild={'shear':[-.32,.32],'stretch':[.72,1.28],'warp_x':[-.13,.13],'warp_y':[-.13,.13],'contrast':[.7,45],**{f'force{i}':[-1.25,1.25] for i in range(1,9)}}
    strong={'shear':[-.42,.42],'stretch':[.62,1.38],'warp_x':[-.18,.18],'warp_y':[-.18,.18],'contrast':[40,80],**{f'force{i}':[-1.5,1.5] for i in range(1,9)}}
    train=sample_cases('train',96,train_bounds,9101); tests=sample_cases('id',30,idb,9201)+sample_cases('mild_shift',30,mild,9301,train_bounds,True)+sample_cases('strong_ood',30,strong,9401,train_bounds,True)
    print('assembling level16 train/test'); tr=dataset(16,train); te=dataset(16,tests); print('assembling level32 refs'); refs=[solve(32,c) for c in tests]
    rows=[]; training=[]
    # deterministic baselines
    mean=np.mean(tr['targets'],0); preds={'training_mean':np.repeat(mean[None],len(tests),0),'pod_ridge':pod_predict(pod_ridge_fit(tr),tests)}
    seeds=[27182,31415,16180]
    for seed in seeds:
        for kind,name in [('mlp','conditioned_mlp'),('fno','compact_fno')]:
            print('training',name,seed,flush=True); b=train_model(kind,tr,seed,args.epochs if kind=='fno' else max(args.epochs,120)); pr=predict(b,te['features'],kind); preds[f'{name}_seed{seed}']=pr; training.append({'model':name,'seed':seed,'seconds':b['seconds'],'final_loss':b['history'][-1]['loss']})
            state={'model_state':b['model'].state_dict(),'xm':b['xm'],'xs':b['xs'],'yn':b['yn'],'kind':kind,'feature_channels':tr['features'].shape[-1]}; torch.save(state,out/f'independent_forcing_{name}_seed{seed}.pt')
    for key,pred in preds.items():
        model=key.split('_seed')[0]; seed=int(key.split('_seed')[1]) if '_seed' in key else -1
        for i,(c,s16,s32) in enumerate(zip(tests,te['sols'],refs)):
            p16=pred[i]; p32=interp_grid(p16,16,32); rows.append({'model':model,'seed':seed,'split':c.split,'geometry_id':c.geometry_id,'same_space_energy_error':energy_rel(s16['A'],p16,s16['u']),'reference_energy_error':energy_rel(s32['A'],p32,s32['u']),'min_jacobian_ratio':min(s16['min_jacobian_ratio'],s32['min_jacobian_ratio'])})
    with (out/'independent_forcing_operator_rows.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    summary={'benchmark':{'train_cases':len(train),'test_cases':len(tests),'forcing_modes':len(MODES),'solution_coefficients_exposed_to_model':False,'labels':'independently assembled P1 finite-element solutions','level16_nodes':289,'level32_nodes':1089,'all_shift_cases_strictly_outside_training_hyperrectangle':all(not inside(c,train_bounds) for c in tests if c.split!='id'),'minimum_element_jacobian_ratio':min(r['min_jacobian_ratio'] for r in rows)},'summary':summarize(rows),'training':training,'scope':'Ordinary-floating prediction benchmark; level-32 FE solutions are numerical references, not machine-enclosed continuous truth.'}
    (out/'independent_forcing_operator_summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    # Same-checkpoint exact finite-dimensional correction audit.
    correction_rows=[]
    for seed in seeds:
        prediction=preds[f'compact_fno_seed{seed}']
        for split_index, split in enumerate(('id','mild_shift','strong_ood')):
            for local_index in (0,1,2):
                index=30*split_index+local_index
                sol=te['sols'][index]
                values=prediction[index].copy(); values[sol['boundary']]=0.0
                free=np.flatnonzero(~sol['boundary'])
                residual=sol['load']-sol['A']@values
                started=time.perf_counter(); correction=np.zeros_like(values)
                correction[free]=spsolve(sol['A'][free][:,free],residual[free])
                correction_seconds=time.perf_counter()-started
                started=time.perf_counter(); direct=np.zeros_like(values)
                direct[free]=spsolve(sol['A'][free][:,free],sol['load'][free])
                direct_seconds=time.perf_counter()-started
                correction_energy=math.sqrt(max(float(correction@(sol['A']@correction)),0.0))
                direct_error=direct-values
                direct_energy=math.sqrt(max(float(direct_error@(sol['A']@direct_error)),0.0))
                correction_rows.append({'seed':seed,'split':split,'geometry_id':local_index,'correction_energy':correction_energy,'direct_error_energy':direct_energy,'relative_identity_defect':abs(correction_energy-direct_energy)/max(direct_energy,1e-30),'correction_seconds':correction_seconds,'direct_fe_seconds':direct_seconds,'cost_ratio':correction_seconds/max(direct_seconds,1e-30)})
    write_csv(out/'independent_forcing_correction_rows.csv',correction_rows)
    correction_summary={'cases':len(correction_rows),'maximum_relative_identity_defect':max(row['relative_identity_defect'] for row in correction_rows),'median_cost_ratio':float(np.median([row['cost_ratio'] for row in correction_rows])),'q95_cost_ratio':float(np.quantile([row['cost_ratio'] for row in correction_rows],0.95)),'interpretation':'The Galerkin correction exactly recovers the same-space discrete energy error, but costs essentially one additional FE solve; it is a semantic audit, not a cheap certificate.'}
    (out/'independent_forcing_correction_summary.json').write_text(json.dumps(correction_summary,indent=2),encoding='utf-8')
    print(json.dumps(summary,indent=2))
    print(json.dumps(correction_summary,indent=2))

if __name__=='__main__': main()
