"""Paired model comparison for the independent forcing benchmark."""
from __future__ import annotations
import argparse,json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import wilcoxon
ROOT=Path(__file__).resolve().parent; R=ROOT/'results'
INPUT=R/'independent_forcing_operator_rows.csv'; OUT=R/'independent_forcing_paired_statistics.json'
SPLITS=('id','mild_shift','strong_ood')

def percentile_ci(values,stat,seed=20260803,reps=20000):
 rng=np.random.default_rng(seed);a=np.asarray(values,float);n=len(a)
 draws=np.empty(reps)
 for i in range(reps): draws[i]=stat(a[rng.integers(0,n,n)])
 return [float(np.quantile(draws,.025)),float(np.quantile(draws,.975))]

def build():
 df=pd.read_csv(INPUT)
 f=df[df.model=='compact_fno'];m=df[df.model=='conditioned_mlp']
 x=f.merge(m,on=['seed','split','geometry_id'],suffixes=('_fno','_mlp'))
 out={}
 for j,split in enumerate(SPLITS):
  b=x[x.split==split].copy(); diff=b.reference_energy_error_fno-b.reference_energy_error_mlp
  ratio=b.reference_energy_error_fno/b.reference_energy_error_mlp
  out[split]={
   'paired_predictions':len(b),
   'fno_win_rate':float(np.mean(diff<0)),
   'median_error_ratio_fno_over_mlp':float(np.median(ratio)),
   'median_error_ratio_bootstrap_95':percentile_ci(ratio,np.median,seed=20260803+j),
   'median_paired_difference':float(np.median(diff)),
   'one_sided_wilcoxon_p_fno_lower':float(wilcoxon(diff,alternative='less').pvalue),
  }
 summary={'benchmark':'independent_forcing_paired_model_comparison','comparison':'compact spectral operator versus conditioned MLP on identical seed/split/geometry predictions','multiplicity_note':'inferential values are descriptive secondary analyses; the paper emphasizes effect sizes and win rates','grouped':out}
 OUT.write_text(json.dumps(summary,indent=2)+'\n');return summary

def main():
 p=argparse.ArgumentParser();p.add_argument('--verify-existing',action='store_true');a=p.parse_args();s=build();print(json.dumps({'status':'PASS','splits':len(s['grouped'])},indent=2))
if __name__=='__main__':main()
