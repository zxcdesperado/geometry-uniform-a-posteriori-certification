"""Reference-grid convergence and RT flux-majorant audit for the leakage-free benchmark.

This script closes two manuscript-facing gaps in the independent forcing-to-solution
benchmark:

1. it checks the level-32 numerical reference against independently assembled
   level-64 finite-element solutions on the complete 90-case test set;
2. it applies lowest- and next-order Raviart--Thomas H(div) flux minimization to
   every frozen compact-spectral-operator output (three seeds and 90 test cases,
   hence 270 predictions per method).

The RT implementation is self-contained.  Global edge moments enforce normal-trace
continuity.  The reported integrals use high-order Gauss--Duffy quadrature in
ordinary floating arithmetic; they are theorem-backed functional-majorant
values, but are not machine-enclosed interval endpoints.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import statistics
import sys
import time
from concurrent.futures import ProcessPoolExecutor
from dataclasses import asdict
from pathlib import Path
from typing import Any

import numpy as np
import torch
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import spsolve

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

import independent_forcing_operator_pipeline as base

SEEDS = (27182, 31415, 16180)
SPLITS = ("id", "mild_shift", "strong_ood")
J01 = 2.4048255576957727686


def cases() -> tuple[list[base.Case], dict[str, list[float]]]:
    train_bounds = {
        "shear": [-0.22, 0.22],
        "stretch": [0.82, 1.18],
        "warp_x": [-0.08, 0.08],
        "warp_y": [-0.08, 0.08],
        "contrast": [1.0, 30.0],
        **{f"force{i}": [-1.0, 1.0] for i in range(1, 9)},
    }
    mild = {
        "shear": [-0.32, 0.32],
        "stretch": [0.72, 1.28],
        "warp_x": [-0.13, 0.13],
        "warp_y": [-0.13, 0.13],
        "contrast": [0.7, 45.0],
        **{f"force{i}": [-1.25, 1.25] for i in range(1, 9)},
    }
    strong = {
        "shear": [-0.42, 0.42],
        "stretch": [0.62, 1.38],
        "warp_x": [-0.18, 0.18],
        "warp_y": [-0.18, 0.18],
        "contrast": [40.0, 80.0],
        **{f"force{i}": [-1.5, 1.5] for i in range(1, 9)},
    }
    test = (
        base.sample_cases("id", 30, train_bounds, 9201)
        + base.sample_cases("mild_shift", 30, mild, 9301, train_bounds, True)
        + base.sample_cases("strong_ood", 30, strong, 9401, train_bounds, True)
    )
    return test, train_bounds


def load_predictor(results_dir: Path, seed: int, boundary: np.ndarray) -> dict[str, Any]:
    checkpoint = results_dir / f"independent_forcing_compact_fno_seed{seed}.pt"
    state = torch.load(checkpoint, map_location="cpu", weights_only=True)
    model = base.CompactFNO(int(state["feature_channels"]))
    model.load_state_dict(state["model_state"])
    model.eval()
    return {
        "model": model,
        "xm": state["xm"],
        "xs": state["xs"],
        "yn": state["yn"],
        "mask": torch.tensor(~boundary, dtype=torch.float32),
    }


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = list(rows[0].keys())
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def quantiles(values: list[float]) -> dict[str, float]:
    array = np.asarray(values, dtype=float)
    return {
        "median": float(np.median(array)),
        "q95": float(np.quantile(array, 0.95)),
        "max": float(np.max(array)),
    }



def reference_case(case: base.Case) -> dict[str, Any]:
    levels: dict[int, Any] = {}
    for level in (16, 32, 64):
        started = time.perf_counter()
        levels[level] = base.solve_fast(level, case)
        levels[level]["assembly_solve_seconds"] = time.perf_counter() - started
    u16_32 = base.interp_grid(levels[16]["u"], 16, 32)
    u16_64 = base.interp_grid(levels[16]["u"], 16, 64)
    u32_64 = base.interp_grid(levels[32]["u"], 32, 64)
    e16_32 = base.energy_rel(levels[32]["A"], u16_32, levels[32]["u"])
    e16_64 = base.energy_rel(levels[64]["A"], u16_64, levels[64]["u"])
    e32_64 = base.energy_rel(levels[64]["A"], u32_64, levels[64]["u"])
    return {
        "split": case.split,
        "geometry_id": case.geometry_id,
        "contrast": case.contrast,
        "minimum_jacobian_ratio_level64": levels[64]["min_jacobian_ratio"],
        "level16_to_level32_relative_energy": e16_32,
        "level16_to_level64_relative_energy": e16_64,
        "level32_to_level64_relative_energy": e32_64,
        "level32_to_level64_over_level16_to_level64": e32_64 / max(e16_64, 1e-30),
        "level32_seconds": levels[32]["assembly_solve_seconds"],
        "level64_seconds": levels[64]["assembly_solve_seconds"],
    }

def reference_convergence(
    test_cases: list[base.Case],
    results_dir: Path,
    cases_per_split: int = 30,
    workers: int = 1,
) -> tuple[list[dict[str, Any]], dict[str, Any], dict[tuple[str, int], dict[int, Any]]]:
    selected = [case for case in test_cases if case.geometry_id < cases_per_split]
    cache: dict[tuple[str, int], dict[int, Any]] = {}
    if workers > 1:
        with ProcessPoolExecutor(max_workers=workers) as pool:
            rows = list(pool.map(reference_case, selected))
    else:
        rows = [reference_case(case) for case in selected]
    rows.sort(key=lambda row: (SPLITS.index(str(row["split"])), int(row["geometry_id"])))
    for row in rows:
        print(
            f"reference {row['split']}:{row['geometry_id']} "
            f"e32/64={row['level32_to_level64_relative_energy']:.4e}",
            flush=True,
        )
    grouped: dict[str, Any] = {}
    for split in (*SPLITS, "overall"):
        group = rows if split == "overall" else [row for row in rows if row["split"] == split]
        grouped[split] = {
            "cases": len(group),
            "level32_to_level64": quantiles(
                [float(row["level32_to_level64_relative_energy"]) for row in group]
            ),
            "level16_to_level64": quantiles(
                [float(row["level16_to_level64_relative_energy"]) for row in group]
            ),
            "reference_error_fraction": quantiles(
                [float(row["level32_to_level64_over_level16_to_level64"]) for row in group]
            ),
        }
    summary = {
        "benchmark": "independent_forcing_reference_grid_convergence",
        "selection": f"first {cases_per_split} deterministic cases from each split; {len(selected)} cases total",
        "levels": [16, 32, 64],
        "error_norm": "level-64 stiffness energy norm after bicubic reference-grid interpolation",
        "scope": "ordinary-floating nested FE comparison; not a machine-enclosed continuous-error bound",
        "grouped": grouped,
    }
    write_csv(results_dir / "independent_forcing_reference_convergence_rows.csv", rows)
    (results_dir / "independent_forcing_reference_convergence_summary.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True), encoding="utf-8"
    )
    return rows, summary, cache


def gauss_duffy(order: int = 8) -> tuple[np.ndarray, np.ndarray]:
    nodes, weights = np.polynomial.legendre.leggauss(order)
    nodes = 0.5 * (nodes + 1.0)
    weights = 0.5 * weights
    bary: list[list[float]] = []
    out_weights: list[float] = []
    for i, u in enumerate(nodes):
        for j, v in enumerate(nodes):
            bary.append([1.0 - u, u * (1.0 - v), u * v])
            out_weights.append(float(weights[i] * weights[j] * u))
    return np.asarray(bary, dtype=float), np.asarray(out_weights, dtype=float)


def edge_gauss(order: int = 6) -> tuple[np.ndarray, np.ndarray]:
    nodes, weights = np.polynomial.legendre.leggauss(order)
    return 0.5 * (nodes + 1.0), 0.5 * weights


def polynomial_values(order: int, coefficients: np.ndarray, points: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    x = points[:, 0]
    y = points[:, 1]
    if order == 0:
        qx = coefficients[0][None, :] + x[:, None] * coefficients[2][None, :]
        qy = coefficients[1][None, :] + y[:, None] * coefficients[2][None, :]
        div = np.repeat((2.0 * coefficients[2])[None, :], len(points), axis=0)
    elif order == 1:
        qx = (
            coefficients[0][None, :]
            + x[:, None] * coefficients[1][None, :]
            + y[:, None] * coefficients[2][None, :]
            + (x * x)[:, None] * coefficients[6][None, :]
            + (x * y)[:, None] * coefficients[7][None, :]
        )
        qy = (
            coefficients[3][None, :]
            + x[:, None] * coefficients[4][None, :]
            + y[:, None] * coefficients[5][None, :]
            + (x * y)[:, None] * coefficients[6][None, :]
            + (y * y)[:, None] * coefficients[7][None, :]
        )
        div = (
            coefficients[1][None, :]
            + coefficients[5][None, :]
            + 3.0 * x[:, None] * coefficients[6][None, :]
            + 3.0 * y[:, None] * coefficients[7][None, :]
        )
    else:
        raise ValueError(order)
    return np.stack([qx, qy], axis=1), div


def coefficient_basis_values(order: int, points: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    ncoeff = 3 if order == 0 else 8
    return polynomial_values(order, np.eye(ncoeff), points)


def build_edges(elements: np.ndarray, physical_nodes: np.ndarray) -> tuple[list[tuple[int, int]], np.ndarray, np.ndarray]:
    edge_set: set[tuple[int, int]] = set()
    for tri in elements:
        for a, b in ((int(tri[0]), int(tri[1])), (int(tri[1]), int(tri[2])), (int(tri[2]), int(tri[0]))):
            edge_set.add((min(a, b), max(a, b)))
    edges = sorted(edge_set)
    edge_id = {edge: i for i, edge in enumerate(edges)}
    local_edges = np.empty((len(elements), 3), dtype=np.int64)
    for k, tri in enumerate(elements):
        for j, (a, b) in enumerate(((int(tri[0]), int(tri[1])), (int(tri[1]), int(tri[2])), (int(tri[2]), int(tri[0])))):
            local_edges[k, j] = edge_id[(min(a, b), max(a, b))]
    normals = np.empty((len(edges), 2), dtype=float)
    for i, (a, b) in enumerate(edges):
        tangent = physical_nodes[b] - physical_nodes[a]
        length = float(np.linalg.norm(tangent))
        normals[i] = np.array([tangent[1], -tangent[0]]) / length
    return edges, local_edges, normals


def local_basis_coefficients(
    order: int,
    triangle: np.ndarray,
    element_edge_ids: np.ndarray,
    edges: list[tuple[int, int]],
    edge_normals: np.ndarray,
    physical_nodes: np.ndarray,
) -> np.ndarray:
    ncoeff = 3 if order == 0 else 8
    ldof = 3 if order == 0 else 8
    moment = np.zeros((ldof, ncoeff), dtype=float)
    t, w = edge_gauss()
    for local_index, edge_index in enumerate(element_edge_ids):
        a, b = edges[int(edge_index)]
        p0 = physical_nodes[a]
        p1 = physical_nodes[b]
        points = (1.0 - t)[:, None] * p0 + t[:, None] * p1
        length = float(np.linalg.norm(p1 - p0))
        values, _ = coefficient_basis_values(order, points)
        normal_values = values[:, 0, :] * edge_normals[edge_index, 0] + values[:, 1, :] * edge_normals[edge_index, 1]
        if order == 0:
            moment[local_index] = np.sum((w * length)[:, None] * normal_values, axis=0)
        else:
            moment[2 * local_index] = np.sum((w * length)[:, None] * normal_values, axis=0)
            moment[2 * local_index + 1] = np.sum(
                (w * length * (2.0 * t - 1.0))[:, None] * normal_values,
                axis=0,
            )
    if order == 1:
        bary, weights = gauss_duffy(7)
        points = bary @ triangle
        determinant = abs(float(np.linalg.det(np.column_stack([triangle[1] - triangle[0], triangle[2] - triangle[0]]))))
        qweights = weights * determinant
        values, _ = coefficient_basis_values(order, points)
        area = 0.5 * determinant
        moment[6] = np.sum(qweights[:, None] * values[:, 0, :], axis=0) / area
        moment[7] = np.sum(qweights[:, None] * values[:, 1, :], axis=0) / area
    condition = float(np.linalg.cond(moment))
    if not math.isfinite(condition) or condition > 1.0e10:
        raise RuntimeError(f"ill-conditioned local RT moment matrix: {condition:.3e}")
    return np.linalg.inv(moment)


def local_global_dofs(order: int, element_index: int, element_edge_ids: np.ndarray, num_edges: int) -> np.ndarray:
    if order == 0:
        return np.asarray(element_edge_ids, dtype=np.int64)
    ids: list[int] = []
    for edge in element_edge_ids:
        ids.extend([2 * int(edge), 2 * int(edge) + 1])
    ids.extend([2 * num_edges + 2 * element_index, 2 * num_edges + 2 * element_index + 1])
    return np.asarray(ids, dtype=np.int64)


def assemble_rt_system(
    solution: dict[str, Any],
    case: base.Case,
    prediction: np.ndarray,
    order: int,
    quadrature_order: int = 8,
) -> dict[str, Any]:
    ref = solution["ref"]
    phys = solution["phys"]
    elements = solution["elems"]
    gradients, _, determinants = base.tri_geom(phys, elements)
    prediction_gradients = np.einsum("eia,ei->ea", gradients, prediction[elements])
    edges, local_edges, edge_normals = build_edges(elements, phys)
    num_edges = len(edges)
    ndof = num_edges if order == 0 else 2 * num_edges + 2 * len(elements)
    row_m: list[int] = []
    col_m: list[int] = []
    val_m: list[float] = []
    row_r: list[int] = []
    col_r: list[int] = []
    val_r: list[float] = []
    rhs_m = np.zeros(ndof, dtype=float)
    rhs_r = np.zeros(ndof, dtype=float)
    element_data: list[dict[str, Any]] = []
    bary, base_weights = gauss_duffy(quadrature_order)
    max_local_condition = 0.0
    for element_index, tri_nodes in enumerate(elements):
        triangle_phys = phys[tri_nodes]
        triangle_ref = ref[tri_nodes]
        coefficients = local_basis_coefficients(
            order,
            triangle_phys,
            local_edges[element_index],
            edges,
            edge_normals,
            phys,
        )
        # Save condition of the basis coefficient matrix as a diagnostic.
        max_local_condition = max(max_local_condition, float(np.linalg.cond(coefficients)))
        points_phys = bary @ triangle_phys
        points_ref = bary @ triangle_ref
        determinant = abs(float(determinants[element_index]))
        weights = base_weights * determinant
        basis_values, basis_divergence = polynomial_values(order, coefficients, points_phys)
        diffusivity = np.asarray(base.coeff(points_ref, case), dtype=float)
        source = np.asarray(base.forcing(points_ref, case), dtype=float)
        gradient = prediction_gradients[element_index]
        local_m = np.einsum(
            "q,qai,qaj->ij",
            weights / diffusivity,
            basis_values,
            basis_values,
        )
        local_r = np.einsum("q,qi,qj->ij", weights, basis_divergence, basis_divergence)
        local_bm = np.einsum("q,qai,a->i", weights, basis_values, gradient)
        local_br = -np.einsum("q,q,qi->i", weights, source, basis_divergence)
        gids = local_global_dofs(order, element_index, local_edges[element_index], num_edges)
        for i, gi in enumerate(gids):
            rhs_m[gi] += local_bm[i]
            rhs_r[gi] += local_br[i]
            for j, gj in enumerate(gids):
                row_m.append(int(gi)); col_m.append(int(gj)); val_m.append(float(local_m[i, j]))
                row_r.append(int(gi)); col_r.append(int(gj)); val_r.append(float(local_r[i, j]))
        element_data.append(
            {
                "gids": gids,
                "coefficients": coefficients,
                "points_phys": points_phys,
                "points_ref": points_ref,
                "weights": weights,
                "diffusivity": diffusivity,
                "source": source,
                "prediction_gradient": gradient,
            }
        )
    mismatch_matrix = coo_matrix((val_m, (row_m, col_m)), shape=(ndof, ndof)).tocsr()
    residual_matrix = coo_matrix((val_r, (row_r, col_r)), shape=(ndof, ndof)).tocsr()
    area = float(sum(0.5 * abs(value) for value in determinants))
    lambda_lower = min(1.0, float(case.contrast))
    friedrichs = math.sqrt(area / math.pi) / J01
    residual_scale = friedrichs / math.sqrt(lambda_lower)
    return {
        "mismatch_matrix": mismatch_matrix,
        "residual_matrix": residual_matrix,
        "mismatch_rhs": rhs_m,
        "residual_rhs": rhs_r,
        "element_data": element_data,
        "ndof": ndof,
        "num_edges": num_edges,
        "friedrichs_upper": friedrichs,
        "lambda_lower": lambda_lower,
        "residual_scale": residual_scale,
        "max_local_basis_condition": max_local_condition,
    }


def evaluate_flux(system: dict[str, Any], order: int, dofs: np.ndarray) -> tuple[float, float]:
    mismatch_sq = 0.0
    residual_sq = 0.0
    for element in system["element_data"]:
        local = dofs[element["gids"]]
        values, divergence = polynomial_values(order, element["coefficients"], element["points_phys"])
        flux = np.einsum("qai,i->qa", values, local)
        div_flux = np.einsum("qi,i->q", divergence, local)
        target = element["diffusivity"][:, None] * element["prediction_gradient"][None, :]
        mismatch_sq += float(
            np.sum(
                element["weights"]
                * np.sum((flux - target) ** 2, axis=1)
                / element["diffusivity"]
            )
        )
        residual_sq += float(
            np.sum(element["weights"] * (div_flux + element["source"]) ** 2)
        )
    return math.sqrt(max(mismatch_sq, 0.0)), math.sqrt(max(residual_sq, 0.0))


def optimize_rt(
    solution: dict[str, Any],
    case: base.Case,
    prediction: np.ndarray,
    order: int,
    iterations: int = 7,
    quadrature_order: int = 8,
) -> dict[str, Any]:
    started = time.perf_counter()
    system = assemble_rt_system(solution, case, prediction, order, quadrature_order)
    assembly_seconds = time.perf_counter() - started
    weight = 0.5
    dofs = np.zeros(system["ndof"], dtype=float)
    history: list[dict[str, float]] = []
    solve_seconds = 0.0
    for iteration in range(iterations):
        mismatch_factor = 1.0 / max(weight, 1.0e-10)
        residual_factor = system["residual_scale"] ** 2 / max(1.0 - weight, 1.0e-10)
        matrix = mismatch_factor * system["mismatch_matrix"] + residual_factor * system["residual_matrix"]
        rhs = mismatch_factor * system["mismatch_rhs"] + residual_factor * system["residual_rhs"]
        solve_started = time.perf_counter()
        dofs = np.asarray(spsolve(matrix, rhs), dtype=float)
        algebraic_residual = rhs - matrix @ dofs
        rhs_norm = max(float(np.linalg.norm(rhs)), 1.0e-30)
        relative_linear_residual = float(np.linalg.norm(algebraic_residual)) / rhs_norm
        if relative_linear_residual > 1.0e-11:
            correction = np.asarray(spsolve(matrix, algebraic_residual), dtype=float)
            dofs = dofs + correction
            algebraic_residual = rhs - matrix @ dofs
            relative_linear_residual = float(np.linalg.norm(algebraic_residual)) / rhs_norm
        solve_seconds += time.perf_counter() - solve_started
        mismatch, residual = evaluate_flux(system, order, dofs)
        majorant = mismatch + system["residual_scale"] * residual
        next_weight = mismatch / max(majorant, 1.0e-30)
        next_weight = min(max(next_weight, 1.0e-6), 1.0 - 1.0e-6)
        history.append(
            {
                "iteration": float(iteration),
                "mismatch_norm": mismatch,
                "residual_norm": residual,
                "majorant": majorant,
                "weight": weight,
                "relative_linear_residual": relative_linear_residual,
            }
        )
        if abs(next_weight - weight) < 1.0e-5:
            weight = next_weight
            break
        weight = next_weight
    total_seconds = time.perf_counter() - started
    mismatch, residual = evaluate_flux(system, order, dofs)
    majorant = mismatch + system["residual_scale"] * residual
    return {
        "majorant": majorant,
        "flux_mismatch": mismatch,
        "equilibrium_residual": residual,
        "friedrichs_upper": system["friedrichs_upper"],
        "lambda_lower": system["lambda_lower"],
        "residual_scale": system["residual_scale"],
        "ndof": system["ndof"],
        "num_edges": system["num_edges"],
        "max_local_basis_condition": system["max_local_basis_condition"],
        "relative_linear_residual": float(history[-1]["relative_linear_residual"]),
        "assembly_seconds": assembly_seconds,
        "linear_solve_seconds": solve_seconds,
        "certification_seconds": total_seconds,
        "iterations": len(history),
        "history": history,
    }


def cold_fe_seconds(case: base.Case, repeats: int = 3) -> float:
    timings: list[float] = []
    for _ in range(repeats):
        started = time.perf_counter()
        base.solve(16, case)
        timings.append(time.perf_counter() - started)
    return statistics.median(timings)


def summarize_rt_group(rows: list[dict[str, Any]]) -> dict[str, Any]:
    return {
        "cases": len(rows),
        "same_space_coverage_rate": statistics.fmean(float(row["same_space_coverage"]) for row in rows),
        "same_space_effectivity": quantiles([float(row["same_space_effectivity"]) for row in rows]),
        "certification_seconds": quantiles([float(row["certification_seconds"]) for row in rows]),
        "certification_over_cold_fe": quantiles([float(row["certification_over_cold_fe"]) for row in rows]),
        "max_local_basis_condition": max(float(row["max_local_basis_condition"]) for row in rows),
        "max_relative_linear_residual": max(float(row.get("relative_linear_residual", 0.0)) for row in rows),
    }



def rt_case_rows(case: base.Case, results_dir: Path) -> list[dict[str, Any]]:
    s16 = base.solve_fast(16, case)
    fe_seconds = cold_fe_seconds(case)
    feature_batch = np.stack([base.features(s16, case)])
    rows: list[dict[str, Any]] = []
    for seed in SEEDS:
        bundle = load_predictor(results_dir, seed, s16["boundary"])
        prediction = base.predict(bundle, feature_batch, "fno")[0]
        prediction = np.asarray(prediction, dtype=float)
        prediction[s16["boundary"]] = 0.0
        same_space_error = math.sqrt(
            max(float((prediction - s16["u"]) @ (s16["A"] @ (prediction - s16["u"]))), 0.0)
        )
        for order, method in ((0, "RT1_lowest_order"), (1, "RT2_next_order")):
            print(f"RT {method} seed={seed} {case.split}:{case.geometry_id}", flush=True)
            result = optimize_rt(s16, case, prediction, order)
            majorant = float(result["majorant"])
            row = {
                "seed": seed,
                "split": case.split,
                "geometry_id": case.geometry_id,
                "method": method,
                "contrast": case.contrast,
                "same_space_error": same_space_error,
                "majorant": majorant,
                "same_space_effectivity": majorant / max(same_space_error, 1.0e-30),
                "same_space_coverage": bool(majorant + 1.0e-10 >= same_space_error),
                "flux_mismatch": result["flux_mismatch"],
                "equilibrium_residual": result["equilibrium_residual"],
                "friedrichs_upper": result["friedrichs_upper"],
                "lambda_lower": result["lambda_lower"],
                "rt_dofs": result["ndof"],
                "max_local_basis_condition": result["max_local_basis_condition"],
                "assembly_seconds": result["assembly_seconds"],
                "linear_solve_seconds": result["linear_solve_seconds"],
                "relative_linear_residual": result.get("relative_linear_residual", 0.0),
                "certification_seconds": result["certification_seconds"],
                "cold_fe_seconds": fe_seconds,
                "certification_over_cold_fe": result["certification_seconds"] / fe_seconds,
                "reweight_iterations": result["iterations"],
            }
            rows.append(row)
            print(
                f"  M={majorant:.4e} eff_same={row['same_space_effectivity']:.3f} "
                f"cost/FE={row['certification_over_cold_fe']:.2f}",
                flush=True,
            )
    return rows

def rt_audit(
    test_cases: list[base.Case],
    cache: dict[tuple[str, int], dict[int, Any]],
    results_dir: Path,
    cases_per_split: int = 30,
    workers: int = 1,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    del cache  # retained in the signature for backward compatibility
    selected = [case for case in test_cases if case.geometry_id < cases_per_split]
    if workers > 1:
        payloads = [(case, results_dir) for case in selected]
        with ProcessPoolExecutor(max_workers=workers) as pool:
            blocks = list(pool.map(_rt_case_payload, payloads))
        rows = [row for block in blocks for row in block]
    else:
        rows = [row for case in selected for row in rt_case_rows(case, results_dir)]
    rows.sort(
        key=lambda row: (
            str(row["method"]),
            int(row["seed"]),
            SPLITS.index(str(row["split"])),
            int(row["geometry_id"]),
        )
    )
    grouped: dict[str, Any] = {}
    for method in ("RT1_lowest_order", "RT2_next_order"):
        grouped[method] = {"overall": summarize_rt_group([row for row in rows if row["method"] == method])}
        for split in SPLITS:
            grouped[method][split] = summarize_rt_group(
                [row for row in rows if row["method"] == method and row["split"] == split]
            )
    summary = {
        "benchmark": "independent_forcing_same_checkpoint_rt_majorant",
        "cases_per_method": len(selected) * len(SEEDS),
        "selection": f"three frozen checkpoints; first {cases_per_split} deterministic cases per split",
        "methods": {
            "RT1_lowest_order": "standard lowest-order Raviart--Thomas space (RT0 in polynomial-order notation)",
            "RT2_next_order": "standard next-order Raviart--Thomas space (RT1 in polynomial-order notation)",
        },
        "majorant": "||a^{-1/2}(y-a grad v)|| + C_F/sqrt(lambda) ||div y+f||",
        "friedrichs_constant": "Faber--Krahn area upper bound sqrt(|Omega|/pi)/j_{0,1}",
        "integration": "8x8 Gauss--Duffy quadrature in ordinary floating arithmetic",
        "strictness": "theorem-backed functional form, ordinary-floating evaluation; not a machine-enclosed endpoint",
        "certificate_target": "energy error of the released conforming P1 trial against the Galerkin solution in the same finite-element space",
        "fine_grid_semantics": "reference-grid differences are reported separately as sensitivity diagnostics and are not certificate-validity tests for a different reconstructed trial function",
        "grouped": grouped,
        "coverage_failures_same_space": [row for row in rows if not row["same_space_coverage"]],
    }
    write_csv(results_dir / "independent_forcing_rt_majorant_rows.csv", rows)
    (results_dir / "independent_forcing_rt_majorant_summary.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True), encoding="utf-8"
    )
    return rows, summary


def _rt_case_payload(payload: tuple[base.Case, Path]) -> list[dict[str, Any]]:
    case, results_dir = payload
    return rt_case_rows(case, results_dir)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--results-dir",
        type=Path,
        default=SCRIPT_DIR / "results",
    )
    parser.add_argument("--skip-reference", action="store_true")
    parser.add_argument("--skip-rt", action="store_true")
    parser.add_argument("--worker-reference-split", choices=SPLITS)
    parser.add_argument("--worker-reference-id", type=int)
    parser.add_argument("--worker-rt-split", choices=SPLITS)
    parser.add_argument("--worker-rt-id", type=int)
    parser.add_argument("--worker-out", type=Path)
    parser.add_argument("--reference-cases-per-split", type=int, default=30)
    parser.add_argument("--rt-cases-per-split", type=int, default=3)
    parser.add_argument("--workers", type=int, default=1)
    args = parser.parse_args()
    test_cases, _ = cases()
    if args.worker_reference_split is not None:
        selected = [c for c in test_cases if c.split == args.worker_reference_split]
        if args.worker_reference_id is not None:
            selected = [c for c in selected if c.geometry_id == args.worker_reference_id]
        worker_rows = [reference_case(c) for c in selected]
        if args.worker_out is None:
            raise SystemExit("--worker-out is required")
        args.worker_out.write_text(json.dumps(worker_rows, indent=2), encoding="utf-8")
        return
    if args.worker_rt_split is not None:
        if args.worker_rt_id is None or args.worker_out is None:
            raise SystemExit("--worker-rt-id and --worker-out are required")
        case = next(c for c in test_cases if c.split == args.worker_rt_split and c.geometry_id == args.worker_rt_id)
        worker_rows = rt_case_rows(case, args.results_dir)
        args.worker_out.write_text(json.dumps(worker_rows, indent=2), encoding="utf-8")
        return
    cache: dict[tuple[str, int], dict[int, Any]] = {}
    if not args.skip_reference:
        _, ref_summary, cache = reference_convergence(
            test_cases, args.results_dir, args.reference_cases_per_split, args.workers
        )
        print(json.dumps(ref_summary, indent=2), flush=True)
    if not args.skip_rt:
        _, rt_summary = rt_audit(
            test_cases, cache, args.results_dir, args.rt_cases_per_split, args.workers
        )
        print(json.dumps(rt_summary, indent=2), flush=True)


if __name__ == "__main__":
    main()
