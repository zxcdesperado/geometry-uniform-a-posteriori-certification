"""Machine-enclosed functional majorants for native global RT2 witnesses.

Every floating input is interpreted as its exact IEEE-754 dyadic value and
embedded in an outward interval backend. The release audit exercises both
``mpmath.iv`` and python-flint/Arb through the same algorithm. The global RT2 coefficient
vector is not required to be the exact minimizer: any coefficient vector in the
assembled conforming RT space is a valid functional-majorant witness.  The
native reference basis and contravariant Piola map are evaluated directly.

Integrals are enclosed by subdividing each affine triangle, evaluating the
integrand on an interval box containing each subtriangle, and multiplying its
upper/lower range by the exact subtriangle area enclosure.  This is deliberately
more conservative than Gaussian quadrature but removes unbounded quadrature and
roundoff from the reported endpoint.
"""

from __future__ import annotations

import math
from typing import Any

import numpy as np
from mpmath import iv

from independent_flux_audit import subdivisions
from native_rt_witness import audit_native_rt_witness, orientation_table


def _point(value: float | int) -> Any:
    if isinstance(value, (int, np.integer)):
        return iv.mpf(int(value))
    numerator, denominator = float(value).as_integer_ratio()
    return iv.mpf(numerator) / iv.mpf(denominator)


def _box(lower: float, upper: float) -> Any:
    lo = math.nextafter(float(lower), -math.inf)
    hi = math.nextafter(float(upper), math.inf)
    return iv.mpf([lo, hi])


def _lower(value: Any) -> float:
    return math.nextafter(float(value.a), -math.inf)


def _upper(value: Any) -> float:
    return math.nextafter(float(value.b), math.inf)


def _interval_record(value: Any) -> dict[str, float]:
    return {"lower": _lower(value), "upper": _upper(value)}


def _upper_point(value: Any) -> Any:
    """Return an interval point at a rigorously outward upper endpoint."""
    return _point(_upper(value))


def _square(value: Any) -> Any:
    """Range-enclose ``x**2`` without ball-arithmetic dependency loss."""
    lower = _lower(value)
    upper = _upper(value)
    if lower <= 0.0 <= upper:
        squared_lower = 0.0
    else:
        squared_lower = math.nextafter(min(lower * lower, upper * upper), -math.inf)
    squared_upper = math.nextafter(max(lower * lower, upper * upper), math.inf)
    if squared_lower == 0.0:
        return iv.mpf([0.0, squared_upper])
    return _box(squared_lower, squared_upper)


def _absolute_upper(value: Any) -> Any:
    """Return an interval-typed outward upper bound for ``abs(value)``."""
    upper = math.nextafter(max(abs(_lower(value)), abs(_upper(value))), math.inf)
    return _point(upper)


def _euclidean_upper(values: list[Any] | tuple[Any, ...]) -> Any:
    """Return an interval-typed outward upper bound for a Euclidean norm."""
    squared = iv.mpf(0)
    for value in values:
        magnitude = _absolute_upper(value)
        squared += _square(magnitude)
    return _upper_point(iv.sqrt(squared))


def _rt2_reference_basis(r: Any, s: Any, local: int) -> tuple[tuple[Any, Any], Any]:
    """Exact polynomial formulas used by scikit-fem ``ElementTriRT2``."""
    if local == 0:
        value = (
            -2 * r * (4 * r + 4 * s - 3),
            -(8 * r * s - 6 * r + 8 * s**2 - 12 * s + 4),
        )
        divergence = 6 * (3 - 4 * r - 4 * s)
    elif local == 1:
        value = (-4 * r * (1 - 2 * r), 8 * r * s - 6 * r - 2 * s + 2)
        divergence = -6 + 24 * r
    elif local == 2:
        value = (-4 * r * (1 - 2 * r), -2 * s * (1 - 4 * r))
        divergence = -6 + 24 * r
    elif local == 3:
        value = (-2 * r * (1 - 4 * s), -4 * s * (1 - 2 * s))
        divergence = -6 + 24 * s
    elif local == 4:
        value = (
            -8 * r**2 - 8 * r * s + 12 * r + 6 * s - 4,
            2 * s * (-4 * r - 4 * s + 3),
        )
        divergence = 18 - 24 * r - 24 * s
    elif local == 5:
        value = (8 * r * s - 2 * r - 6 * s + 2, 4 * s * (2 * s - 1))
        divergence = -6 + 24 * s
    elif local == 6:
        value = (8 * r * (-2 * r - s + 2), 8 * s * (-2 * r - s + 1))
        divergence = 24 * (1 - 2 * r - s)
    elif local == 7:
        value = (8 * r * (-r - 2 * s + 1), 8 * s * (-r - 2 * s + 2))
        divergence = 24 * (1 - r - 2 * s)
    else:
        raise IndexError(local)
    return value, divergence


# Coefficients in [1, r, s, r^2, r*s, s^2] for the two reference components,
# followed by divergence coefficients in [1, r, s].  They are the expanded
# integer polynomials of scikit-fem ElementTriRT2.lbasis.
_RT2_POLYNOMIALS = (
    ((0, 6, 0, -8, -8, 0), (-4, 6, 12, 0, -8, -8), (18, -24, -24)),
    ((0, -4, 0, 8, 0, 0), (2, -6, -2, 0, 8, 0), (-6, 24, 0)),
    ((0, -4, 0, 8, 0, 0), (0, 0, -2, 0, 8, 0), (-6, 24, 0)),
    ((0, -2, 0, 0, 8, 0), (0, 0, -4, 0, 0, 8), (-6, 0, 24)),
    ((-4, 12, 6, -8, -8, 0), (0, 0, 6, 0, -8, -8), (18, -24, -24)),
    ((2, -2, -6, 0, 8, 0), (0, 0, -4, 0, 0, 8), (-6, 0, 24)),
    ((0, 16, 0, -16, -8, 0), (0, 0, 8, 0, -16, -8), (24, -48, -24)),
    ((0, 8, 0, -8, -16, 0), (0, 0, 16, 0, -8, -16), (24, -24, -48)),
)

_RT1_POLYNOMIALS = (
    ((0, 1, 0, 0, 0, 0), (-1, 0, 1, 0, 0, 0), (2, 0, 0)),
    ((0, 1, 0, 0, 0, 0), (0, 0, 1, 0, 0, 0), (2, 0, 0)),
    ((-1, 1, 0, 0, 0, 0), (0, 0, 1, 0, 0, 0), (2, 0, 0)),
)


def _evaluate_quadratic(coefficients: list[Any], r: Any, s: Any) -> Any:
    return (
        coefficients[0]
        + coefficients[1] * r
        + coefficients[2] * s
        + coefficients[3] * r**2
        + coefficients[4] * r * s
        + coefficients[5] * s**2
    )


def _combined_native_polynomials(
    coefficients: np.ndarray,
    polynomial_table: tuple[Any, ...],
    j00: Any,
    j01: Any,
    j10: Any,
    j11: Any,
    abs_determinant: Any,
) -> tuple[list[Any], list[Any], list[Any]]:
    reference0 = [iv.mpf(0) for _ in range(6)]
    reference1 = [iv.mpf(0) for _ in range(6)]
    divergence = [iv.mpf(0) for _ in range(3)]
    for local in range(len(polynomial_table)):
        coefficient = _point(float(coefficients[local]))
        polynomial0, polynomial1, div_polynomial = polynomial_table[local]
        for degree in range(6):
            reference0[degree] += coefficient * polynomial0[degree]
            reference1[degree] += coefficient * polynomial1[degree]
        for degree in range(3):
            divergence[degree] += coefficient * div_polynomial[degree]
    physical0 = [
        (j00 * reference0[degree] + j01 * reference1[degree]) / abs_determinant
        for degree in range(6)
    ]
    physical1 = [
        (j10 * reference0[degree] + j11 * reference1[degree]) / abs_determinant
        for degree in range(6)
    ]
    physical_divergence = [value / abs_determinant for value in divergence]
    return physical0, physical1, physical_divergence


def _forcing_interval(mesh: Any, contrast: Any, xi: Any, eta: Any) -> Any:
    shear = _point(mesh.shear)
    stretch = _point(mesh.stretch)
    one = iv.mpf(1)
    inverse00 = one
    inverse01 = -shear / stretch
    inverse10 = iv.mpf(0)
    inverse11 = one / stretch
    pulled00 = stretch * (inverse00**2 + inverse01**2)
    pulled01 = stretch * (inverse00 * inverse10 + inverse01 * inverse11)
    pulled11 = stretch * (inverse10**2 + inverse11**2)
    sine_coefficient = iv.pi**2 * (pulled00 + pulled11) / stretch
    cosine_coefficient = -2 * iv.pi**2 * pulled01 / stretch
    sin_x = iv.sin(iv.pi * xi)
    sin_y = iv.sin(iv.pi * eta)
    cos_x = iv.cos(iv.pi * xi)
    cos_y = iv.cos(iv.pi * eta)
    minus_laplacian = sine_coefficient * sin_x * sin_y + cosine_coefficient * cos_x * cos_y

    reference_gradient0 = iv.pi * cos_x * sin_y
    reference_gradient1 = iv.pi * sin_x * cos_y
    # inverse-transpose applied to the reference gradient
    physical_gradient0 = inverse00 * reference_gradient0 + inverse10 * reference_gradient1
    physical_gradient1 = inverse01 * reference_gradient0 + inverse11 * reference_gradient1
    coefficient_gradient0 = (contrast - 1) * inverse00
    coefficient_gradient1 = (contrast - 1) * inverse01
    material = 1 + (contrast - 1) * xi
    return material * minus_laplacian - (
        physical_gradient0 * coefficient_gradient0
        + physical_gradient1 * coefficient_gradient1
    )


def _forcing_reference_gradient_interval(
    mesh: Any, contrast: Any, xi: Any, eta: Any
) -> tuple[Any, Any]:
    """Interval enclosure of the forcing gradient in global reference coordinates."""
    shear = _point(mesh.shear)
    stretch = _point(mesh.stretch)
    one = iv.mpf(1)
    inverse00 = one
    inverse01 = -shear / stretch
    inverse10 = iv.mpf(0)
    inverse11 = one / stretch
    pulled00 = stretch * (inverse00**2 + inverse01**2)
    pulled01 = stretch * (inverse00 * inverse10 + inverse01 * inverse11)
    pulled11 = stretch * (inverse10**2 + inverse11**2)
    sine_coefficient = iv.pi**2 * (pulled00 + pulled11) / stretch
    cosine_coefficient = -2 * iv.pi**2 * pulled01 / stretch
    coefficient_gradient0 = (contrast - 1) * inverse00
    coefficient_gradient1 = (contrast - 1) * inverse01
    contraction0 = inverse00 * coefficient_gradient0 + inverse01 * coefficient_gradient1
    contraction1 = inverse10 * coefficient_gradient0 + inverse11 * coefficient_gradient1

    sin_x = iv.sin(iv.pi * xi)
    sin_y = iv.sin(iv.pi * eta)
    cos_x = iv.cos(iv.pi * xi)
    cos_y = iv.cos(iv.pi * eta)
    laplace = sine_coefficient * sin_x * sin_y + cosine_coefficient * cos_x * cos_y
    laplace_x = iv.pi * (
        sine_coefficient * cos_x * sin_y - cosine_coefficient * sin_x * cos_y
    )
    laplace_y = iv.pi * (
        sine_coefficient * sin_x * cos_y - cosine_coefficient * cos_x * sin_y
    )
    gradient_term_x = iv.pi**2 * (
        -contraction0 * sin_x * sin_y + contraction1 * cos_x * cos_y
    )
    gradient_term_y = iv.pi**2 * (
        contraction0 * cos_x * cos_y - contraction1 * sin_x * sin_y
    )
    material = 1 + (contrast - 1) * xi
    derivative_x = (contrast - 1) * laplace + material * laplace_x - gradient_term_x
    derivative_y = material * laplace_y - gradient_term_y
    return derivative_x, derivative_y


def _forcing_reference_hessian_upper(mesh: Any, contrast: Any) -> Any:
    """Outward upper bound for the forcing Hessian Frobenius norm."""
    shear = _point(mesh.shear)
    stretch = _point(mesh.stretch)
    one = iv.mpf(1)
    inverse00 = one
    inverse01 = -shear / stretch
    inverse10 = iv.mpf(0)
    inverse11 = one / stretch
    pulled00 = stretch * (inverse00**2 + inverse01**2)
    pulled01 = stretch * (inverse00 * inverse10 + inverse01 * inverse11)
    pulled11 = stretch * (inverse10**2 + inverse11**2)
    sine_coefficient = iv.pi**2 * (pulled00 + pulled11) / stretch
    cosine_coefficient = -2 * iv.pi**2 * pulled01 / stretch
    base = _absolute_upper(sine_coefficient) + _absolute_upper(cosine_coefficient)
    coefficient_gradient0 = (contrast - 1) * inverse00
    coefficient_gradient1 = (contrast - 1) * inverse01
    contraction0 = inverse00 * coefficient_gradient0 + inverse01 * coefficient_gradient1
    contraction1 = inverse10 * coefficient_gradient0 + inverse11 * coefficient_gradient1
    contraction_sum = _absolute_upper(contraction0) + _absolute_upper(contraction1)
    slope = _absolute_upper(contrast - 1)
    contrast_upper = _point(max(abs(_lower(contrast)), abs(_upper(contrast))))
    common = iv.pi**3 * contraction_sum
    hessian_xx = 2 * slope * iv.pi * base + contrast_upper * iv.pi**2 * base + common
    hessian_yy = contrast_upper * iv.pi**2 * base + common
    hessian_xy = slope * iv.pi * base + contrast_upper * iv.pi**2 * base + common
    bound = iv.sqrt(
        _square(hessian_xx) + _square(hessian_yy) + 2 * _square(hessian_xy)
    )
    return _upper_point(bound)


def _quadratic_value_gradient_hessian_upper(
    coefficients: list[Any], r: Any, s: Any
) -> tuple[Any, Any, Any, tuple[Any, Any, Any]]:
    value = _evaluate_quadratic(coefficients, r, s)
    derivative_r = coefficients[1] + 2 * coefficients[3] * r + coefficients[4] * s
    derivative_s = coefficients[2] + coefficients[4] * r + 2 * coefficients[5] * s
    return value, derivative_r, derivative_s, (
        2 * coefficients[3],
        coefficients[4],
        2 * coefficients[5],
    )


def _friedrichs_interval(mesh: Any) -> Any:
    shear = _point(mesh.shear)
    stretch = _point(mesh.stretch)
    trace = 1 + shear**2 + stretch**2
    discriminant = trace**2 - 4 * stretch**2
    largest_eigenvalue = (trace + iv.sqrt(discriminant)) / 2
    sigma_max = iv.sqrt(largest_eigenvalue)
    return sigma_max / (iv.pi * iv.sqrt(2))


def enclose_native_rt_majorant(
    mesh: Any,
    prediction: np.ndarray,
    contrast: float,
    optimized: dict[str, Any],
    *,
    subdivision_depth: int = 1,
    interval_dps: int = 40,
    enclosure_strategy: str = "taylor",
) -> dict[str, Any]:
    """Return a machine enclosure for the RT2 majorant and true energy error."""
    iv.dps = int(interval_dps)
    basis = optimized["basis"]
    element_name = type(basis.elem).__name__
    if element_name == "ElementTriRT2":
        polynomial_table = _RT2_POLYNOMIALS
    elif element_name == "ElementTriRT1":
        polynomial_table = _RT1_POLYNOMIALS
    else:
        raise TypeError("machine enclosure is implemented for ElementTriRT1/RT2 only")
    if basis.mesh.t.shape[1] != len(mesh.elements):
        raise ValueError("RT and audit meshes have different element counts")
    for native_triangle, audit_triangle in zip(basis.mesh.t.T, mesh.elements):
        if set(map(int, native_triangle)) != set(map(int, audit_triangle)):
            raise ValueError("RT and audit meshes have different element connectivity")
    solution = np.asarray(optimized["solution"], dtype=float)
    orientations = orientation_table(basis)
    local_coefficients = solution[basis.element_dofs] * orientations
    pieces = subdivisions(subdivision_depth)
    micro_area_fraction = _point(1) / _point(4**subdivision_depth)

    if enclosure_strategy not in {"box", "taylor"}:
        raise ValueError("enclosure_strategy must be 'box' or 'taylor'")
    mismatch_squared = iv.mpf(0)
    residual_squared = iv.mpf(0)
    energy_error_squared = iv.mpf(0)
    contrast_interval = _point(contrast)
    for element in range(basis.mesh.t.shape[1]):
        triangle = np.asarray(basis.mesh.t[:, element], dtype=int)
        physical_vertices = mesh.physical_nodes[triangle]
        reference_vertices = mesh.reference_nodes[triangle]
        j00 = _point(physical_vertices[1, 0]) - _point(physical_vertices[0, 0])
        j01 = _point(physical_vertices[2, 0]) - _point(physical_vertices[0, 0])
        j10 = _point(physical_vertices[1, 1]) - _point(physical_vertices[0, 1])
        j11 = _point(physical_vertices[2, 1]) - _point(physical_vertices[0, 1])
        signed_determinant = j00 * j11 - j01 * j10
        if _lower(signed_determinant) > 0.0:
            abs_determinant = signed_determinant
        elif _upper(signed_determinant) < 0.0:
            abs_determinant = -signed_determinant
        else:
            raise ValueError("element determinant enclosure crosses zero")
        micro_area = abs_determinant / 2 * micro_area_fraction

        u0, u1, u2 = (_point(float(prediction[node])) for node in triangle)
        derivative_r = u1 - u0
        derivative_s = u2 - u0
        prediction_gradient0 = (
            j11 * derivative_r - j10 * derivative_s
        ) / signed_determinant
        prediction_gradient1 = (
            -j01 * derivative_r + j00 * derivative_s
        ) / signed_determinant
        flux_polynomial0, flux_polynomial1, divergence_polynomial = (
            _combined_native_polynomials(
                local_coefficients[:, element],
                polynomial_table,
                j00,
                j01,
                j10,
                j11,
                abs_determinant,
            )
        )
        xi0, xi1, xi2 = (_point(value) for value in reference_vertices[:, 0])
        eta0, eta1, eta2 = (_point(value) for value in reference_vertices[:, 1])
        xi_r = xi1 - xi0
        xi_s = xi2 - xi0
        eta_r = eta1 - eta0
        eta_s = eta2 - eta0

        material_coefficients = (
            1 + (contrast_interval - 1) * xi0,
            (contrast_interval - 1) * xi_r,
            (contrast_interval - 1) * xi_s,
        )
        mismatch_polynomials: list[list[Any]] = []
        for flux_polynomial, prediction_gradient in (
            (flux_polynomial0, prediction_gradient0),
            (flux_polynomial1, prediction_gradient1),
        ):
            mismatch_polynomials.append(
                [
                    flux_polynomial[0] - material_coefficients[0] * prediction_gradient,
                    flux_polynomial[1] - material_coefficients[1] * prediction_gradient,
                    flux_polynomial[2] - material_coefficients[2] * prediction_gradient,
                    flux_polynomial[3],
                    flux_polynomial[4],
                    flux_polynomial[5],
                ]
            )
        forcing_hessian_global = _forcing_reference_hessian_upper(
            mesh, contrast_interval
        )
        local_map_frobenius_squared = (
            xi_r**2 + xi_s**2 + eta_r**2 + eta_s**2
        )
        forcing_hessian_local_upper = _upper_point(
            forcing_hessian_global * local_map_frobenius_squared
        )

        for piece in pieces:
            local_vertices = np.column_stack([piece[:, 1], piece[:, 2]])
            r = _box(float(np.min(local_vertices[:, 0])), float(np.max(local_vertices[:, 0])))
            s = _box(float(np.min(local_vertices[:, 1])), float(np.max(local_vertices[:, 1])))

            flux0 = _evaluate_quadratic(flux_polynomial0, r, s)
            flux1 = _evaluate_quadratic(flux_polynomial1, r, s)
            flux_divergence = (
                divergence_polynomial[0]
                + divergence_polynomial[1] * r
                + divergence_polynomial[2] * s
            )

            xi = xi0 + xi_r * r + xi_s * s
            eta = eta0 + eta_r * r + eta_s * s
            material = 1 + (contrast_interval - 1) * xi
            if _lower(material) <= 0.0:
                raise ValueError("coefficient interval is not positive")

            if enclosure_strategy == "box":
                mismatch0 = flux0 - material * prediction_gradient0
                mismatch1 = flux1 - material * prediction_gradient1
                mismatch_integrand = (_square(mismatch0) + _square(mismatch1)) / material
                forcing = _forcing_interval(mesh, contrast_interval, xi, eta)
                residual_integrand = _square(forcing + flux_divergence)
                mismatch_squared += micro_area * mismatch_integrand
                residual_squared += micro_area * residual_integrand
            else:
                # The Taylor enclosure stays in interval arithmetic from the
                # dyadic subtriangle vertices onward.  In particular, neither
                # the centroid nor the radius is first computed by NumPy.
                interval_vertices = [
                    (_point(float(vertex[0])), _point(float(vertex[1])))
                    for vertex in local_vertices
                ]
                center_r = sum((vertex[0] for vertex in interval_vertices), iv.mpf(0)) / 3
                center_s = sum((vertex[1] for vertex in interval_vertices), iv.mpf(0)) / 3
                radius_squared_upper = iv.mpf(0)
                for vertex_r, vertex_s in interval_vertices:
                    candidate = _square(vertex_r - center_r) + _square(vertex_s - center_s)
                    if _upper(candidate) > _upper(radius_squared_upper):
                        radius_squared_upper = _upper_point(candidate)
                radius_interval = _upper_point(iv.sqrt(radius_squared_upper))
                mismatch_centers: list[Any] = []
                mismatch_derivatives: list[Any] = []
                mismatch_hessians: list[Any] = []
                for mismatch_polynomial in mismatch_polynomials:
                    value, derivative_r_value, derivative_s_value, hessian = (
                        _quadratic_value_gradient_hessian_upper(
                            mismatch_polynomial, center_r, center_s
                        )
                    )
                    mismatch_centers.append(value)
                    mismatch_derivatives.extend([derivative_r_value, derivative_s_value])
                    mismatch_hessians.extend(
                        [hessian[0], hessian[1], hessian[1], hessian[2]]
                    )
                mismatch_upper = (
                    _euclidean_upper(mismatch_centers)
                    + _euclidean_upper(mismatch_derivatives) * radius_interval
                    + (_point(1) / 2)
                    * _euclidean_upper(mismatch_hessians)
                    * _square(radius_interval)
                )
                material_lower = math.nextafter(_lower(material), -math.inf)
                if material_lower <= 0.0:
                    raise ValueError("coefficient Taylor enclosure is not positive")
                mismatch_integrand_upper = _upper_point(
                    _square(mismatch_upper) / _point(material_lower)
                )

                center_xi = xi0 + xi_r * center_r + xi_s * center_s
                center_eta = eta0 + eta_r * center_r + eta_s * center_s
                forcing_center = _forcing_interval(
                    mesh, contrast_interval, center_xi, center_eta
                )
                divergence_center = (
                    divergence_polynomial[0]
                    + divergence_polynomial[1] * center_r
                    + divergence_polynomial[2] * center_s
                )
                forcing_gradient_xi, forcing_gradient_eta = (
                    _forcing_reference_gradient_interval(
                        mesh, contrast_interval, center_xi, center_eta
                    )
                )
                residual_gradient_r = (
                    forcing_gradient_xi * xi_r
                    + forcing_gradient_eta * eta_r
                    + divergence_polynomial[1]
                )
                residual_gradient_s = (
                    forcing_gradient_xi * xi_s
                    + forcing_gradient_eta * eta_s
                    + divergence_polynomial[2]
                )
                residual_upper = (
                    _absolute_upper(forcing_center + divergence_center)
                    + _euclidean_upper([residual_gradient_r, residual_gradient_s])
                    * radius_interval
                    + (_point(1) / 2)
                    * forcing_hessian_local_upper
                    * _square(radius_interval)
                )
                residual_integrand_upper = _upper_point(_square(residual_upper))
                mismatch_squared += micro_area * mismatch_integrand_upper
                residual_squared += micro_area * residual_integrand_upper

            sin_x = iv.sin(iv.pi * xi)
            sin_y = iv.sin(iv.pi * eta)
            cos_x = iv.cos(iv.pi * xi)
            cos_y = iv.cos(iv.pi * eta)
            reference_gradient0 = iv.pi * cos_x * sin_y
            reference_gradient1 = iv.pi * sin_x * cos_y
            global_shear = _point(mesh.shear)
            global_stretch = _point(mesh.stretch)
            exact_gradient0 = reference_gradient0
            exact_gradient1 = (
                -global_shear / global_stretch * reference_gradient0
                + reference_gradient1 / global_stretch
            )
            error_integrand = material * (
                _square(exact_gradient0 - prediction_gradient0)
                + _square(exact_gradient1 - prediction_gradient1)
            )

            energy_error_squared += micro_area * error_integrand

    mismatch_norm = iv.sqrt(mismatch_squared)
    residual_norm = iv.sqrt(residual_squared)
    friedrichs = _friedrichs_interval(mesh)
    majorant = mismatch_norm + friedrichs * residual_norm
    energy_error = iv.sqrt(energy_error_squared)
    effectivity = majorant / energy_error
    audit = audit_native_rt_witness(optimized)
    majorant_upper = _upper(majorant)
    error_upper = _upper(energy_error)
    result = {
        "method": f"native_global_{element_name}_machine_enclosed",
        "subdivision_depth": int(subdivision_depth),
        "interval_dps": int(interval_dps),
        "enclosure_strategy": enclosure_strategy,
        "interval_backend": getattr(
            iv,
            "backend_label",
            "mpmath.iv with outward interval operations",
        ),
        "input_semantics": (
            "Every stored IEEE-754 coefficient and nodal prediction is embedded "
            "as its exact dyadic ratio before interval evaluation."
        ),
        "rt_solution_semantics": (
            "The floating RT solve is not certified as the exact minimizer and "
            "need not be: its exact stored coefficient vector defines a valid "
            "native global H(div) witness."
        ),
        "flux_mismatch_norm": _interval_record(mismatch_norm),
        "equilibrium_residual_norm": _interval_record(residual_norm),
        "friedrichs_constant": _interval_record(friedrichs),
        "functional_majorant": _interval_record(majorant),
        "energy_error": _interval_record(energy_error),
        "effectivity": _interval_record(effectivity),
        "majorant_upper_covers_error_upper": bool(majorant_upper >= error_upper),
        "native_hdiv_audit": audit.as_dict(),
        "claim_scope": (
            "Machine-enclosed affine-geometry scalar Dirichlet result. The box "
            "subdivision encloses integration and rounding; it is not a claim "
            "about mixed elasticity or curved non-affine cells."
        ),
    }
    if not audit.exact_discrete_hdiv_membership:
        raise AssertionError("native RT2 witness failed the discrete H(div) audit")
    if not result["majorant_upper_covers_error_upper"]:
        raise AssertionError(
            "machine majorant endpoint failed to cover the error enclosure: "
            f"majorant={result['functional_majorant']}, "
            f"error={result['energy_error']}, "
            f"backend={result['interval_backend']}"
        )
    return result


def enclose_native_rt2_majorant(
    mesh: Any,
    prediction: np.ndarray,
    contrast: float,
    optimized: dict[str, Any],
    *,
    subdivision_depth: int = 1,
    interval_dps: int = 40,
) -> dict[str, Any]:
    """Backward-compatible RT2-only entry point used by the frozen audit."""
    if type(optimized["basis"].elem).__name__ != "ElementTriRT2":
        raise TypeError("enclose_native_rt2_majorant requires ElementTriRT2")
    return enclose_native_rt_majorant(
        mesh,
        prediction,
        contrast,
        optimized,
        subdivision_depth=subdivision_depth,
        interval_dps=interval_dps,
        enclosure_strategy="taylor",
    )
