"""Certificate accept/fallback sweep over all test geometries and checkpoints."""
from __future__ import annotations
import argparse, csv, json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
RESULTS=ROOT/'results'
IN=RESULTS/'independent_forcing_multicheckpoint_rt2_rows.csv'
ROWS=RESULTS/'independent_forcing_multicheckpoint_certificate_gate_rows.csv'
SUMMARY=RESULTS/'forcing_certificate_gate_summary.json'
TOLS=(0.015,0.020,0.025,0.030,0.040)
SPLITS=('id','mild_shift','strong_ood')

def build():
    raw=list(csv.DictReader(IN.open(newline='',encoding='utf-8')))
    out=[]
    for tol in TOLS:
        for split in SPLITS:
            b=[r for r in raw if r['split']==split]
            accepted=[r for r in b if float(r['majorant'])<=tol]
            verified=all(float(r['same_space_error'])<=tol+1e-10 for r in accepted)
            out.append({'tolerance':tol,'split':split,'predictions':len(b),'accepted':len(accepted),'fallback':len(b)-len(accepted),'accepted_rate':len(accepted)/len(b),'accepted_all_verified_below_tolerance':verified})
    with ROWS.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(out[0]));w.writeheader();w.writerows(out)
    summary={'benchmark':'independent_forcing_multicheckpoint_certificate_gate','source':'independent_forcing_multicheckpoint_rt2_rows.csv','prediction_certificate_pairs':len(raw),'checkpoint_seeds':sorted({int(r['seed']) for r in raw}),'tolerances':list(TOLS),'rows':out,'semantics':'accept exactly when the RT2 same-space majorant does not exceed the prescribed absolute energy-error tolerance; otherwise route to Galerkin/high-fidelity fallback','all_accepted_verified':all(r['accepted_all_verified_below_tolerance'] for r in out)}
    SUMMARY.write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    return summary

def verify():
    released=json.loads(SUMMARY.read_text())
    before=SUMMARY.read_bytes(); built=build(); after=SUMMARY.read_bytes()
    if before!=after or released!=built: raise RuntimeError('gate summary is not reproducible')
    if not built['all_accepted_verified'] or built['prediction_certificate_pairs']!=270: raise RuntimeError('gate verification failed')
    return built

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--verify-existing',action='store_true');a=ap.parse_args()
    s=verify() if a.verify_existing else build()
    print(json.dumps({'status':'PASS','pairs':s['prediction_certificate_pairs'],'all_accepted_verified':s['all_accepted_verified']},indent=2))
