"""Native global Raviart--Thomas witnesses without elementwise refitting.

The older higher-order audit assembled a conforming global RT function and then
least-squares fitted an element polynomial for Taylor evaluation.  The fit was
small but it was a different field and therefore had a nonzero sampled normal
jump.  This module keeps the assembled global coefficient vector and evaluates
the element basis through the contravariant Piola map.  Consequently the
mathematical witness is the global finite-element function itself.

Floating evaluation of that function is still ordinary floating arithmetic.
Membership in the discrete H(div) space follows from shared global facet DOFs,
the oriented reference basis, and the Piola transformation; it does not depend
on a sampled jump being exactly zero in floating arithmetic.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np


@dataclass(frozen=True)
class NativeRTAudit:
    element_name: str
    global_dofs: int
    elements: int
    interior_facets: int
    shared_facet_dof_checks: int
    shared_facet_dof_failures: int
    max_native_value_reproduction_defect: float
    max_native_divergence_reproduction_defect: float
    max_sampled_interior_normal_jump: float
    exact_discrete_hdiv_membership: bool
    arithmetic_scope: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "element_name": self.element_name,
            "global_dofs": self.global_dofs,
            "elements": self.elements,
            "interior_facets": self.interior_facets,
            "shared_facet_dof_checks": self.shared_facet_dof_checks,
            "shared_facet_dof_failures": self.shared_facet_dof_failures,
            "max_native_value_reproduction_defect": self.max_native_value_reproduction_defect,
            "max_native_divergence_reproduction_defect": self.max_native_divergence_reproduction_defect,
            "max_sampled_interior_normal_jump": self.max_sampled_interior_normal_jump,
            "exact_discrete_hdiv_membership": self.exact_discrete_hdiv_membership,
            "arithmetic_scope": self.arithmetic_scope,
        }


def orientation_table(basis: Any) -> np.ndarray:
    """Return local-basis orientation signs with shape (local_dofs, elements)."""
    return np.stack(
        [
            np.asarray(basis.elem.orient(basis.mapping, local), dtype=float)
            for local in range(basis.element_dofs.shape[0])
        ],
        axis=0,
    )


def oriented_local_coefficients(basis: Any, solution: np.ndarray) -> np.ndarray:
    """Return coefficients multiplying the unoriented reference basis."""
    coefficients = np.asarray(solution, dtype=float)[basis.element_dofs]
    return coefficients * orientation_table(basis)


def _element_jacobian(basis: Any, element: int) -> tuple[np.ndarray, float, np.ndarray]:
    triangle = basis.mesh.t[:, element]
    vertices = basis.mesh.p[:, triangle]
    jacobian = np.column_stack(
        [vertices[:, 1] - vertices[:, 0], vertices[:, 2] - vertices[:, 0]]
    )
    determinant = float(np.linalg.det(jacobian))
    if determinant == 0.0:
        raise ValueError("degenerate RT element")
    return jacobian, abs(determinant), vertices[:, 0]


def evaluate_element_native(
    basis: Any,
    solution: np.ndarray,
    element: int,
    local_points: np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    """Evaluate the assembled RT field and its divergence on one element.

    ``local_points`` has shape (2, npoints) in the reference triangle.  No
    polynomial recovery or least-squares fit is performed.
    """
    points = np.asarray(local_points, dtype=float)
    if points.ndim != 2 or points.shape[0] != 2:
        raise ValueError("local_points must have shape (2, npoints)")
    coefficients = oriented_local_coefficients(basis, solution)[:, element]
    reference_value = np.zeros((2, points.shape[1]), dtype=float)
    reference_divergence = np.zeros(points.shape[1], dtype=float)
    for local, coefficient in enumerate(coefficients):
        value, divergence = basis.elem.lbasis(points, local)
        reference_value += coefficient * np.asarray(value, dtype=float)
        reference_divergence += coefficient * np.asarray(divergence, dtype=float)
    jacobian, abs_determinant, _ = _element_jacobian(basis, element)
    physical_value = jacobian @ reference_value / abs_determinant
    physical_divergence = reference_divergence / abs_determinant
    return physical_value, physical_divergence


def _local_coordinates(basis: Any, element: int, physical: np.ndarray) -> np.ndarray:
    jacobian, _, origin = _element_jacobian(basis, element)
    return np.linalg.solve(jacobian, np.asarray(physical, dtype=float) - origin[:, None])


def audit_native_rt_witness(
    optimized: dict[str, Any],
    *,
    edge_samples: int = 9,
) -> NativeRTAudit:
    """Audit native reproduction, global facet sharing, and sampled traces."""
    basis = optimized["basis"]
    solution = np.asarray(optimized["solution"], dtype=float)
    field = basis.interpolate(solution)

    maximum_value_defect = 0.0
    maximum_divergence_defect = 0.0
    for element in range(basis.nelems):
        value, divergence = evaluate_element_native(
            basis, solution, element, np.asarray(basis.X, dtype=float)
        )
        maximum_value_defect = max(
            maximum_value_defect,
            float(np.max(np.abs(value - field.value[:, element, :]))),
        )
        maximum_divergence_defect = max(
            maximum_divergence_defect,
            float(np.max(np.abs(divergence - field.div[element, :]))),
        )

    shared_checks = 0
    shared_failures = 0
    interior_facets = 0
    maximum_jump = 0.0
    parameters = np.linspace(0.0, 1.0, edge_samples)
    facet_dofs = int(basis.elem.facet_dofs)
    for facet in range(basis.mesh.facets.shape[1]):
        adjacent = basis.mesh.f2t[:, facet]
        if np.any(adjacent < 0):
            continue
        first_element, second_element = (int(adjacent[0]), int(adjacent[1]))
        interior_facets += 1
        first_local = int(np.flatnonzero(basis.mesh.t2f[:, first_element] == facet)[0])
        second_local = int(np.flatnonzero(basis.mesh.t2f[:, second_element] == facet)[0])
        first_dofs = basis.element_dofs[
            first_local * facet_dofs : (first_local + 1) * facet_dofs,
            first_element,
        ]
        second_dofs = basis.element_dofs[
            second_local * facet_dofs : (second_local + 1) * facet_dofs,
            second_element,
        ]
        shared_checks += facet_dofs
        if set(map(int, first_dofs)) != set(map(int, second_dofs)):
            shared_failures += facet_dofs

        nodes = basis.mesh.facets[:, facet]
        endpoints = basis.mesh.p[:, nodes]
        physical = (
            (1.0 - parameters[None, :]) * endpoints[:, :1]
            + parameters[None, :] * endpoints[:, 1:2]
        )
        first_local_points = _local_coordinates(basis, first_element, physical)
        second_local_points = _local_coordinates(basis, second_element, physical)
        first_value, _ = evaluate_element_native(
            basis, solution, first_element, first_local_points
        )
        second_value, _ = evaluate_element_native(
            basis, solution, second_element, second_local_points
        )
        tangent = endpoints[:, 1] - endpoints[:, 0]
        normal = np.array([tangent[1], -tangent[0]], dtype=float)
        normal /= np.linalg.norm(normal)
        jump = normal @ (first_value - second_value)
        maximum_jump = max(maximum_jump, float(np.max(np.abs(jump))))

    exact_membership = bool(
        shared_failures == 0
        and basis.elem.facet_dofs > 0
        and np.all(np.isfinite(solution))
    )
    return NativeRTAudit(
        element_name=type(basis.elem).__name__,
        global_dofs=int(basis.N),
        elements=int(basis.nelems),
        interior_facets=interior_facets,
        shared_facet_dof_checks=shared_checks,
        shared_facet_dof_failures=shared_failures,
        max_native_value_reproduction_defect=maximum_value_defect,
        max_native_divergence_reproduction_defect=maximum_divergence_defect,
        max_sampled_interior_normal_jump=maximum_jump,
        exact_discrete_hdiv_membership=exact_membership,
        arithmetic_scope=(
            "Exact finite-element-space membership follows from one global DOF "
            "vector, shared oriented facet DOFs, and the contravariant Piola map; "
            "the reported reproduction and jump values are floating audits only."
        ),
    )


def native_quadrature_result(optimized: dict[str, Any]) -> dict[str, Any]:
    """Expose the no-refit high-order quadrature diagnostic."""
    audit = audit_native_rt_witness(optimized)
    norms = [float(value) for value in optimized["quadrature_component_norms"]]
    return {
        "functional_majorant": float(optimized["quadrature_majorant"]),
        "flux_mismatch_quadrature": norms[0],
        "equilibrium_residual_quadrature": norms[1],
        "neumann_residual_quadrature": norms[2],
        "native_hdiv_audit": audit.as_dict(),
        "strictness": (
            "The witness is the native global discrete H(div) function. The "
            "quadrature and floating operations in this result are not yet "
            "machine enclosed."
        ),
    }
