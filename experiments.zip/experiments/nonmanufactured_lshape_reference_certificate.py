"""Non-manufactured L-shaped benchmark with a certified reference FE error.

The load is the physical constant ``f=1``; no exact solution is used.  A
refined conforming P1 solution is certified against the unknown continuous
solution by a native global RT0 functional majorant.  A coarse P1 field is
prolonged exactly through the nested red-refinement hierarchy and receives both
an absolute continuous-error majorant and a two-sided error bracket based on
the certified reference error.

The RT0 witness is assembled directly from shared global edge-flux degrees of
freedom.  All integrals in the P1 and RT0 spaces are exact for the polynomial
integrands used here.  Sparse solves are ordinary binary64 calculations, so the
reported certificate has exact-arithmetic mathematical semantics but is not
labelled machine-enclosed.
"""
from __future__ import annotations

import argparse
import json
import math
import time
from pathlib import Path
from typing import Any

import numpy as np
from scipy.sparse import coo_matrix, csr_matrix
from scipy.sparse.linalg import spsolve


TRIANGLE_QUADRATURE_BARYCENTRIC = np.array(
    [
        [2.0 / 3.0, 1.0 / 6.0, 1.0 / 6.0],
        [1.0 / 6.0, 2.0 / 3.0, 1.0 / 6.0],
        [1.0 / 6.0, 1.0 / 6.0, 2.0 / 3.0],
    ],
    dtype=float,
)
REFERENCE_P1_GRADIENTS = np.array(
    [[-1.0, -1.0], [1.0, 0.0], [0.0, 1.0]], dtype=float
)


def initial_lshape_mesh() -> tuple[np.ndarray, np.ndarray]:
    """Return six counter-clockwise triangles covering the standard L-shape."""
    points = np.array(
        [
            [-1.0, -1.0],
            [0.0, -1.0],
            [1.0, -1.0],
            [-1.0, 0.0],
            [0.0, 0.0],
            [1.0, 0.0],
            [-1.0, 1.0],
            [0.0, 1.0],
        ],
        dtype=float,
    )
    triangles = np.array(
        [
            [0, 1, 4],
            [0, 4, 3],
            [1, 2, 5],
            [1, 5, 4],
            [3, 4, 7],
            [3, 7, 6],
        ],
        dtype=int,
    )
    return points, triangles


def red_refine(
    points: np.ndarray, triangles: np.ndarray
) -> tuple[np.ndarray, np.ndarray]:
    """Uniformly split every triangle into four nested children."""
    new_points = points.tolist()
    midpoint_index: dict[tuple[int, int], int] = {}

    def midpoint(first: int, second: int) -> int:
        key = tuple(sorted((int(first), int(second))))
        if key not in midpoint_index:
            midpoint_index[key] = len(new_points)
            new_points.append(((points[key[0]] + points[key[1]]) / 2.0).tolist())
        return midpoint_index[key]

    children: list[list[int]] = []
    for first, second, third in triangles:
        middle_01 = midpoint(first, second)
        middle_12 = midpoint(second, third)
        middle_20 = midpoint(third, first)
        children.extend(
            [
                [int(first), middle_01, middle_20],
                [middle_01, int(second), middle_12],
                [middle_20, middle_12, int(third)],
                [middle_01, middle_12, middle_20],
            ]
        )
    return np.asarray(new_points, dtype=float), np.asarray(children, dtype=int)


def mesh_hierarchy(refinements: int) -> list[tuple[np.ndarray, np.ndarray]]:
    points, triangles = initial_lshape_mesh()
    hierarchy = [(points, triangles)]
    for _ in range(refinements):
        points, triangles = red_refine(points, triangles)
        hierarchy.append((points, triangles))
    return hierarchy


def topology(
    points: np.ndarray, triangles: np.ndarray
) -> tuple[np.ndarray, np.ndarray, np.ndarray, int]:
    """Return global edge indices, orientation signs, boundary nodes and count."""
    edge_to_index: dict[tuple[int, int], int] = {}
    incidence: dict[int, int] = {}
    triangle_edges: list[list[int]] = []
    triangle_signs: list[list[float]] = []
    for triangle in triangles:
        local_edges: list[int] = []
        local_signs: list[float] = []
        for local_first, local_second in ((1, 2), (2, 0), (0, 1)):
            first = int(triangle[local_first])
            second = int(triangle[local_second])
            key = tuple(sorted((first, second)))
            if key not in edge_to_index:
                edge_to_index[key] = len(edge_to_index)
            edge = edge_to_index[key]
            incidence[edge] = incidence.get(edge, 0) + 1
            local_edges.append(edge)

            global_tangent = points[key[1]] - points[key[0]]
            global_normal = np.array(
                [global_tangent[1], -global_tangent[0]], dtype=float
            )
            global_normal /= np.linalg.norm(global_normal)
            local_tangent = points[second] - points[first]
            local_outward = np.array(
                [local_tangent[1], -local_tangent[0]], dtype=float
            )
            local_outward /= np.linalg.norm(local_outward)
            local_signs.append(
                1.0 if float(np.dot(local_outward, global_normal)) >= 0.0 else -1.0
            )
        triangle_edges.append(local_edges)
        triangle_signs.append(local_signs)

    index_to_edge = {index: edge for edge, index in edge_to_index.items()}
    boundary_nodes: set[int] = set()
    for edge, count in incidence.items():
        if count == 1:
            boundary_nodes.update(index_to_edge[edge])
    return (
        np.asarray(triangle_edges, dtype=int),
        np.asarray(triangle_signs, dtype=float),
        np.asarray(sorted(boundary_nodes), dtype=int),
        len(edge_to_index),
    )


def assemble_p1(
    points: np.ndarray, triangles: np.ndarray
) -> tuple[csr_matrix, np.ndarray, np.ndarray, np.ndarray]:
    """Assemble and solve the homogeneous-Dirichlet P1 problem ``-Delta u=1``."""
    rows: list[int] = []
    columns: list[int] = []
    entries: list[float] = []
    load = np.zeros(len(points), dtype=float)
    for triangle in triangles:
        vertices = points[triangle]
        jacobian = np.column_stack(
            [vertices[1] - vertices[0], vertices[2] - vertices[0]]
        )
        area = abs(float(np.linalg.det(jacobian))) / 2.0
        gradients = REFERENCE_P1_GRADIENTS @ np.linalg.inv(jacobian)
        local_matrix = area * (gradients @ gradients.T)
        for local_first in range(3):
            global_first = int(triangle[local_first])
            load[global_first] += area / 3.0
            for local_second in range(3):
                rows.append(global_first)
                columns.append(int(triangle[local_second]))
                entries.append(float(local_matrix[local_first, local_second]))
    matrix = coo_matrix(
        (entries, (rows, columns)), shape=(len(points), len(points))
    ).tocsr()
    _, _, boundary, _ = topology(points, triangles)
    free = np.setdiff1d(np.arange(len(points)), boundary)
    values = np.zeros(len(points), dtype=float)
    values[free] = spsolve(matrix[free][:, free], load[free])
    return matrix, load, values, boundary


def prolong_nested(
    coarse_points: np.ndarray,
    coarse_triangles: np.ndarray,
    coarse_values: np.ndarray,
    refined_points: np.ndarray,
) -> np.ndarray:
    """Prolong P1 nodal values by exact midpoint averaging for one refinement."""
    values = np.empty(len(refined_points), dtype=float)
    values[: len(coarse_points)] = coarse_values
    midpoint_to_edge: dict[tuple[float, float], tuple[int, int]] = {}
    for triangle in coarse_triangles:
        for first, second in (
            (triangle[0], triangle[1]),
            (triangle[1], triangle[2]),
            (triangle[2], triangle[0]),
        ):
            edge = tuple(sorted((int(first), int(second))))
            midpoint = tuple(np.round((coarse_points[edge[0]] + coarse_points[edge[1]]) / 2.0, 14))
            midpoint_to_edge[midpoint] = edge
    for index in range(len(coarse_points), len(refined_points)):
        edge = midpoint_to_edge[tuple(np.round(refined_points[index], 14))]
        values[index] = (coarse_values[edge[0]] + coarse_values[edge[1]]) / 2.0
    return values


def functional_majorant_rt0(
    points: np.ndarray,
    triangles: np.ndarray,
    values: np.ndarray,
    *,
    reweight_iterations: int,
) -> dict[str, Any]:
    """Minimize the functional majorant in one native global RT0 space."""
    triangle_edges, triangle_signs, _boundary, edge_count = topology(points, triangles)
    rows: list[int] = []
    columns: list[int] = []
    mass_entries: list[float] = []
    residual_entries: list[float] = []
    mismatch_rhs = np.zeros(edge_count, dtype=float)
    residual_rhs = np.zeros(edge_count, dtype=float)
    local_records: list[tuple[float, np.ndarray, np.ndarray, np.ndarray, np.ndarray]] = []

    for element, triangle in enumerate(triangles):
        vertices = points[triangle]
        jacobian = np.column_stack(
            [vertices[1] - vertices[0], vertices[2] - vertices[0]]
        )
        area = abs(float(np.linalg.det(jacobian))) / 2.0
        gradients = REFERENCE_P1_GRADIENTS @ np.linalg.inv(jacobian)
        field_gradient = values[triangle] @ gradients
        quadrature_points = TRIANGLE_QUADRATURE_BARYCENTRIC @ vertices
        basis_values = np.zeros((3, 3, 2), dtype=float)
        basis_divergences = triangle_signs[element] / area
        for local in range(3):
            basis_values[local] = (
                triangle_signs[element, local]
                * (quadrature_points - vertices[local])
                / (2.0 * area)
            )
        local_mass = np.zeros((3, 3), dtype=float)
        for local_first in range(3):
            for local_second in range(3):
                local_mass[local_first, local_second] = (
                    area
                    / 3.0
                    * float(
                        np.sum(
                            np.sum(
                                basis_values[local_first]
                                * basis_values[local_second],
                                axis=1,
                            )
                        )
                    )
                )
        local_residual = area * np.outer(basis_divergences, basis_divergences)
        local_mismatch_rhs = np.array(
            [
                area
                / 3.0
                * float(np.sum(basis_values[local] @ field_gradient))
                for local in range(3)
            ]
        )
        local_residual_rhs = -area * basis_divergences
        for local_first in range(3):
            global_first = int(triangle_edges[element, local_first])
            mismatch_rhs[global_first] += local_mismatch_rhs[local_first]
            residual_rhs[global_first] += local_residual_rhs[local_first]
            for local_second in range(3):
                rows.append(global_first)
                columns.append(int(triangle_edges[element, local_second]))
                mass_entries.append(float(local_mass[local_first, local_second]))
                residual_entries.append(float(local_residual[local_first, local_second]))
        local_records.append(
            (area, basis_values, basis_divergences, field_gradient, triangle_edges[element])
        )

    mass = coo_matrix(
        (mass_entries, (rows, columns)), shape=(edge_count, edge_count)
    ).tocsr()
    residual = coo_matrix(
        (residual_entries, (rows, columns)), shape=(edge_count, edge_count)
    ).tocsr()
    # Omega is contained in [-1,1]^2.  Domain monotonicity gives
    # C_F(Omega) <= C_F((-1,1)^2) = sqrt(2)/pi.
    friedrichs = math.sqrt(2.0) / math.pi
    weights = np.array([0.5, 0.5], dtype=float)
    solution = np.zeros(edge_count, dtype=float)
    history: list[dict[str, float | int]] = []
    started = time.perf_counter()
    for iteration in range(reweight_iterations):
        system = mass / max(weights[0], 1.0e-14)
        system = system + friedrichs**2 * residual / max(weights[1], 1.0e-14)
        right = mismatch_rhs / max(weights[0], 1.0e-14)
        right = right + friedrichs**2 * residual_rhs / max(weights[1], 1.0e-14)
        solution = np.asarray(spsolve(system, right), dtype=float)
        mismatch_squared = 0.0
        residual_squared = 0.0
        for area, basis_values, divergences, field_gradient, element_edges in local_records:
            coefficients = solution[element_edges]
            flux_values = np.einsum("i,iqd->qd", coefficients, basis_values)
            flux_divergence = float(coefficients @ divergences)
            mismatch_squared += (
                area
                / 3.0
                * float(np.sum(np.sum((flux_values - field_gradient) ** 2, axis=1)))
            )
            residual_squared += area * (1.0 + flux_divergence) ** 2
        mismatch_norm = math.sqrt(max(mismatch_squared, 0.0))
        equilibrium_norm = math.sqrt(max(residual_squared, 0.0))
        components = np.array([mismatch_norm, friedrichs * equilibrium_norm])
        majorant = float(np.sum(components))
        weights = np.maximum(components / max(majorant, 1.0e-300), 1.0e-14)
        weights /= np.sum(weights)
        history.append(
            {
                "iteration": iteration,
                "mismatch_norm": mismatch_norm,
                "equilibrium_norm": equilibrium_norm,
                "majorant": majorant,
            }
        )
    return {
        "functional_majorant": history[-1]["majorant"],
        "flux_mismatch_norm": history[-1]["mismatch_norm"],
        "equilibrium_residual_norm": history[-1]["equilibrium_norm"],
        "friedrichs_constant": friedrichs,
        "rt_dofs": edge_count,
        "rt_space": "native global RT0 with shared oriented edge-flux DOFs",
        "optimization_seconds": time.perf_counter() - started,
        "history": history,
        "native_global_hdiv": True,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--coarse-refinements", type=int, default=4)
    parser.add_argument("--reference-refinements", type=int, default=6)
    parser.add_argument("--reweight-iterations", type=int, default=8)
    parser.add_argument(
        "--summary-out",
        type=Path,
        default=Path("experiments/results/nonmanufactured_lshape_reference_certificate.json"),
    )
    args = parser.parse_args()
    if args.reference_refinements <= args.coarse_refinements:
        raise ValueError("reference-refinements must exceed coarse-refinements")

    meshes = mesh_hierarchy(args.reference_refinements)
    coarse_points, coarse_triangles = meshes[args.coarse_refinements]
    reference_points, reference_triangles = meshes[args.reference_refinements]
    _coarse_matrix, _coarse_load, coarse_values, _coarse_boundary = assemble_p1(
        coarse_points, coarse_triangles
    )
    reference_matrix, reference_load, reference_values, reference_boundary = assemble_p1(
        reference_points, reference_triangles
    )
    prolonged = coarse_values
    for refinement in range(args.coarse_refinements, args.reference_refinements):
        previous_points, previous_triangles = meshes[refinement]
        next_points, _next_triangles = meshes[refinement + 1]
        prolonged = prolong_nested(
            previous_points, previous_triangles, prolonged, next_points
        )
    prolonged[reference_boundary] = 0.0

    reference_certificate = functional_majorant_rt0(
        reference_points,
        reference_triangles,
        reference_values,
        reweight_iterations=args.reweight_iterations,
    )
    prediction_certificate = functional_majorant_rt0(
        reference_points,
        reference_triangles,
        prolonged,
        reweight_iterations=args.reweight_iterations,
    )
    difference = prolonged - reference_values
    reference_difference = math.sqrt(
        max(float(difference @ (reference_matrix @ difference)), 0.0)
    )
    reference_radius = float(reference_certificate["functional_majorant"])
    prediction_radius = float(prediction_certificate["functional_majorant"])
    lower_error = max(reference_difference - reference_radius, 0.0)
    upper_error = min(reference_difference + reference_radius, prediction_radius)
    compliance_center = float(
        2.0 * np.dot(reference_load, prolonged)
        - prolonged @ (reference_matrix @ prolonged)
    )
    report = {
        "benchmark": "nonmanufactured_nonconvex_lshape_with_certified_reference_error",
        "load": "constant physical load f=1; no manufactured exact solution",
        "geometry": "nonconvex L-shaped domain contained in [-1,1]^2",
        "implementation": "self-contained nested P1 and global RT0 finite elements",
        "coarse_refinements": args.coarse_refinements,
        "reference_refinements": args.reference_refinements,
        "coarse_p1_dofs": int(len(coarse_points)),
        "reference_p1_dofs": int(len(reference_points)),
        "reference_elements": int(len(reference_triangles)),
        "reference_certificate": reference_certificate,
        "prediction_certificate": prediction_certificate,
        "coarse_to_reference_energy_difference": reference_difference,
        "continuous_prediction_error_bracket": {
            "lower": lower_error,
            "upper": upper_error,
            "derivation": "reverse/forward triangle inequality with certified reference FE radius",
        },
        "continuous_compliance_interval": {
            "lower": compliance_center,
            "upper": compliance_center + prediction_radius**2,
        },
        "reference_compliance": float(np.dot(reference_load, reference_values)),
        "two_certificate_consistency": bool(
            reference_difference <= reference_radius + prediction_radius + 1.0e-10
        ),
        "claim_scope": (
            "The functional bounds are exact-arithmetic mathematical bounds with an explicit "
            "domain constant and one native conforming H(div) witness. Sparse linear solves are "
            "ordinary binary64 calculations and are not promoted to machine-enclosed arithmetic."
        ),
    }
    if lower_error > upper_error + 1.0e-10:
        raise AssertionError("certified reference error bracket is empty")
    if not report["two_certificate_consistency"]:
        raise AssertionError("reference and prediction certificates are inconsistent")
    args.summary_out.parent.mkdir(parents=True, exist_ok=True)
    args.summary_out.write_text(
        json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(
        json.dumps(
            {
                "reference_p1_dofs": report["reference_p1_dofs"],
                "reference_rt0_dofs": reference_certificate["rt_dofs"],
                "reference_error_radius": reference_radius,
                "coarse_to_reference_difference": reference_difference,
                "prediction_error_lower": lower_error,
                "prediction_error_upper": upper_error,
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
