"""Machine-enclosed native RT2 audit on official neuraloperator.GINO outputs."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import statistics
import sys
import time
from pathlib import Path
from typing import Any

import neuralop
import numpy as np
import torch
from skfem.element import ElementTriRT2

sys.dont_write_bytecode = True
SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

import machine_enclosed_native_rt2 as machine_engine
from arb_interval_backend import use_arb_backend
from higher_order_flux_majorant import optimize_flux
from independent_flux_audit import build_mesh, energy_error_diagnostic
from official_neuraloperator_gino_audit import make_model, predict, sha256
from true_gino_large_geometry_audit import latin_hypercube_cases, normalize, prepare_cases


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--config",
        type=Path,
        default=Path("experiments/configs/official_gino_machine_rt2_prespecified_2026-08-01.json"),
    )
    parser.add_argument(
        "--summary-out",
        type=Path,
        default=Path("experiments/results/official_gino_machine_rt2_summary.json"),
    )
    parser.add_argument(
        "--rows-out",
        type=Path,
        default=Path("experiments/results/official_gino_machine_rt2_rows.csv"),
    )
    parser.add_argument("--quick", action="store_true")
    args = parser.parse_args()
    protocol = json.loads(args.config.read_text(encoding="utf-8"))
    base_path = Path(protocol["base_config"])
    base = json.loads(base_path.read_text(encoding="utf-8"))["official_gino"]
    if str(neuralop.__version__) != str(base["required_version"]):
        raise RuntimeError("the frozen official neuraloperator version is unavailable")

    train_cases = latin_hypercube_cases(
        "train", base["training_geometries"], base["training_bounds"], base["geometry_seed"]
    )
    test_cases = []
    for split_index, (split, bounds) in enumerate(base["test_bounds"].items()):
        test_cases.extend(
            latin_hypercube_cases(
                split,
                base["test_geometries_per_split"],
                bounds,
                base["geometry_seed"] + 1000 * (split_index + 1),
            )
        )
    raw_train = prepare_cases(base["level"], train_cases)
    raw_test = prepare_cases(base["level"], test_cases)
    _, mean, scale = normalize(raw_train)
    test = dict(raw_test)
    test["features"] = (raw_test["features"] - mean) / scale

    requested = protocol["cases"][:1] if args.quick else protocol["cases"]
    cases_by_seed: dict[int, list[dict[str, Any]]] = {}
    for item in requested:
        cases_by_seed.setdefault(int(item["seed"]), []).append(item)
    rows: list[dict[str, Any]] = []
    started = time.perf_counter()
    for seed, items in cases_by_seed.items():
        checkpoint = Path(
            f"experiments/results/official_neuraloperator_gino_checkpoints/official_gino_seed{seed}.pt"
        )
        model = make_model(raw_train["features"].shape[-1], base)
        state = torch.load(checkpoint, map_location="cpu", weights_only=True)
        model.load_state_dict(state)
        model.eval()
        torch.set_num_threads(1)
        predictions = predict(model, test, base["batch_size"])
        for item in items:
            index = next(
                index
                for index, case in enumerate(test_cases)
                if case.split == item["split"] and case.geometry_id == item["geometry_id"]
            )
            case = test_cases[index]
            prediction = predictions[index]
            mesh = build_mesh(base["level"], case.shear, case.stretch)
            error = energy_error_diagnostic(mesh, prediction, case.contrast)
            optimized = optimize_flux(
                mesh,
                prediction,
                "dirichlet",
                case.contrast,
                ElementTriRT2(),
                base["quadrature_order"],
                base["reweight_iterations"],
            )
            enclosure_started = time.perf_counter()
            with use_arb_backend(machine_engine):
                enclosed = machine_engine.enclose_native_rt2_majorant(
                    mesh,
                    prediction,
                    case.contrast,
                    optimized,
                    subdivision_depth=(2 if args.quick else protocol["subdivision_depth"]),
                    interval_dps=protocol["interval_dps"],
                )
            elapsed = time.perf_counter() - enclosure_started
            audit = enclosed["native_hdiv_audit"]
            row = {
                "seed": seed,
                "split": case.split,
                "geometry_id": case.geometry_id,
                "shear": case.shear,
                "stretch": case.stretch,
                "contrast": case.contrast,
                "floating_energy_error": error,
                "floating_majorant": optimized["quadrature_majorant"],
                "machine_majorant_upper": enclosed["functional_majorant"]["upper"],
                "machine_error_upper": enclosed["energy_error"]["upper"],
                "machine_effectivity_upper": enclosed["effectivity"]["upper"],
                "majorant_upper_covers_error_upper": enclosed["majorant_upper_covers_error_upper"],
                "exact_discrete_hdiv_membership": audit["exact_discrete_hdiv_membership"],
                "machine_enclosure_seconds": elapsed,
                "checkpoint_sha256": sha256(checkpoint),
            }
            rows.append(row)
            print(
                f"seed={seed} {case.split}:{case.geometry_id} "
                f"machine_eff_upper={row['machine_effectivity_upper']:.3f}",
                flush=True,
            )
    report = {
        "benchmark": "official_neuraloperator_gino_machine_native_rt2_crosscheck",
        "package": "neuraloperator",
        "version": str(neuralop.__version__),
        "model_class": "neuralop.models.GINO",
        "config_sha256": hashlib.sha256(args.config.read_bytes()).hexdigest(),
        "base_config_sha256": hashlib.sha256(base_path.read_bytes()).hexdigest(),
        "cases": len(rows),
        "seeds": sorted({row["seed"] for row in rows}),
        "splits": sorted({row["split"] for row in rows}),
        "machine_coverage_rate": float(np.mean([row["majorant_upper_covers_error_upper"] for row in rows])),
        "hdiv_membership_rate": float(np.mean([row["exact_discrete_hdiv_membership"] for row in rows])),
        "machine_effectivity_upper_median": float(statistics.median(row["machine_effectivity_upper"] for row in rows)),
        "machine_effectivity_upper_max": float(max(row["machine_effectivity_upper"] for row in rows)),
        "elapsed_seconds": time.perf_counter() - started,
        "claim_scope": (
            "Machine-enclosed native RT2 post-processing of realized outputs from "
            "the official upstream GINO implementation on the frozen affine scalar family."
        ),
    }
    if report["machine_coverage_rate"] != 1.0 or report["hdiv_membership_rate"] != 1.0:
        raise AssertionError("official GINO machine audit failed")
    args.summary_out.parent.mkdir(parents=True, exist_ok=True)
    args.summary_out.write_text(json.dumps(report, indent=2), encoding="utf-8")
    write_csv(args.rows_out, rows)
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
