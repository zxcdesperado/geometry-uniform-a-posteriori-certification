"""Official upstream neuraloperator.GINO audit on the frozen elliptic data."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import random
import statistics
import sys
import time
from pathlib import Path
from typing import Any

import neuralop
import numpy as np
import torch
from neuralop.models import GINO
from skfem.element import ElementTriRT2

sys.dont_write_bytecode = True
SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from faithful_gino_operator import grid_edge_sets, relative_energy_loss
from higher_order_flux_majorant import optimize_flux
from independent_flux_audit import build_mesh, energy_error_diagnostic
from native_rt_witness import native_quadrature_result
from true_gino_large_geometry_audit import (
    discrete_energy_norm,
    latin_hypercube_cases,
    normalize,
    prepare_cases,
    summarize,
    to_tensor,
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def make_model(feature_channels: int, config: dict[str, Any]) -> GINO:
    return GINO(
        in_channels=feature_channels,
        out_channels=1,
        gno_coord_dim=2,
        gno_radius=float(config["gno_radius"]),
        gno_pos_embed_type=None,
        in_gno_transform_type="nonlinear_kernelonly",
        out_gno_transform_type="linear",
        fno_n_modes=(int(config["fno_modes"]), int(config["fno_modes"])),
        fno_hidden_channels=int(config["fno_hidden_channels"]),
        fno_n_layers=int(config["fno_layers"]),
        projection_channels=int(config["projection_channels"]),
        in_gno_channel_mlp_hidden_layers=[32, 32],
        out_gno_channel_mlp_hidden_layers=[64, 32],
        gno_use_open3d=False,
        gno_use_torch_scatter=False,
    )


def reference_geometry(data: dict[str, Any]) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    side = int(round(math.sqrt(data["reference"].shape[1])))
    points = to_tensor(data["reference"][0])
    return points[None], points.reshape(1, side, side, 2), points


def train_model(
    data: dict[str, Any], config: dict[str, Any], seed: int
) -> tuple[GINO, list[dict[str, float]], float]:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.set_num_threads(int(config["torch_threads"]))
    model = make_model(data["features"].shape[-1], config)
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=float(config["learning_rate"]),
        weight_decay=float(config["weight_decay"]),
    )
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        optimizer,
        T_max=int(config["epochs"]),
        eta_min=float(config["learning_rate"]) * 0.05,
    )
    tensors = {key: to_tensor(value) for key, value in data.items()}
    input_geometry, latent_queries, output_queries = reference_geometry(data)
    side = int(round(math.sqrt(data["reference"].shape[1])))
    horizontal, vertical, diagonal = grid_edge_sets(side)
    generator = np.random.default_rng(seed)
    history: list[dict[str, float]] = []
    started = time.perf_counter()
    for epoch in range(1, int(config["epochs"]) + 1):
        permutation = generator.permutation(len(tensors["target"]))
        epoch_loss = 0.0
        batches = 0
        model.train()
        for offset in range(0, len(permutation), int(config["batch_size"])):
            index = permutation[offset : offset + int(config["batch_size"])]
            optimizer.zero_grad(set_to_none=True)
            prediction = model(
                input_geometry,
                latent_queries,
                output_queries,
                x=tensors["features"][index],
            ).squeeze(-1)
            prediction = prediction * tensors["mask"][index]
            loss = relative_energy_loss(
                prediction,
                tensors["target"][index],
                horizontal,
                vertical,
                diagonal,
                float(config["gradient_loss_weight"]),
            )
            loss.backward()
            torch.nn.utils.clip_grad_norm_(
                model.parameters(), float(config["gradient_clip"])
            )
            optimizer.step()
            epoch_loss += float(loss.detach())
            batches += 1
        scheduler.step()
        if (
            epoch == 1
            or epoch == int(config["epochs"])
            or epoch % int(config["report_every"]) == 0
        ):
            history.append(
                {
                    "epoch": float(epoch),
                    "loss": epoch_loss / max(batches, 1),
                    "learning_rate": float(scheduler.get_last_lr()[0]),
                }
            )
    return model, history, time.perf_counter() - started


def predict(model: GINO, data: dict[str, Any], batch_size: int) -> np.ndarray:
    model.eval()
    input_geometry, latent_queries, output_queries = reference_geometry(data)
    features = to_tensor(data["features"])
    mask = to_tensor(data["mask"])
    rows = []
    with torch.no_grad():
        for offset in range(0, len(features), batch_size):
            value = model(
                input_geometry,
                latent_queries,
                output_queries,
                x=features[offset : offset + batch_size],
            ).squeeze(-1)
            value = value * mask[offset : offset + batch_size]
            rows.append(value.cpu().numpy())
    return np.concatenate(rows, axis=0).astype(float)


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = sorted({key for row in rows for key in row})
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--config",
        type=Path,
        default=Path(
            "experiments/configs/official_neuraloperator_gino_prespecified_2026-08-01.json"
        ),
    )
    parser.add_argument("--quick", action="store_true")
    parser.add_argument(
        "--reuse-summary",
        type=Path,
        help=(
            "Recompute grouped summaries from the stored rows in an existing "
            "report without retraining or reevaluating the operator."
        ),
    )
    parser.add_argument(
        "--summary-out",
        type=Path,
        default=Path(
            "experiments/results/official_neuraloperator_gino_summary.json"
        ),
    )
    parser.add_argument(
        "--rows-out",
        type=Path,
        default=Path("experiments/results/official_neuraloperator_gino_rows.csv"),
    )
    parser.add_argument(
        "--training-out",
        type=Path,
        default=Path(
            "experiments/results/official_neuraloperator_gino_training_rows.csv"
        ),
    )
    parser.add_argument(
        "--checkpoint-dir",
        type=Path,
        default=Path(
            "experiments/results/official_neuraloperator_gino_checkpoints"
        ),
    )
    args = parser.parse_args()

    document = json.loads(args.config.read_text(encoding="utf-8"))
    config = dict(document["official_gino"])
    if str(neuralop.__version__) != str(config["required_version"]):
        raise RuntimeError(
            f"neuraloperator {config['required_version']} required, got {neuralop.__version__}"
        )
    if args.reuse_summary is not None:
        report = json.loads(args.reuse_summary.read_text(encoding="utf-8"))
        rows = list(report["rows"])
        distinct = {(str(row["split"]), int(row["geometry_id"])) for row in rows}
        expected = len(config["test_bounds"]) * int(config["test_geometries_per_split"])
        if len(rows) != expected * len(config["seeds"]):
            raise AssertionError("stored official-GINO row count differs from the frozen protocol")
        if len(distinct) != expected:
            raise AssertionError("stored official-GINO split/geometry count is incomplete")
        report["overall"] = summarize(rows, 20260801)
        report["by_split"] = {
            split: summarize(
                [row for row in rows if row["split"] == split], 20260801
            )
            for split in config["test_bounds"]
        }
        if report["overall"]["unique_geometries"] != expected:
            raise AssertionError("overall official-GINO geometry clustering is incorrect")
        args.summary_out.parent.mkdir(parents=True, exist_ok=True)
        args.summary_out.write_text(
            json.dumps(report, indent=2, sort_keys=True), encoding="utf-8"
        )
        write_csv(args.rows_out, rows)
        write_csv(args.training_out, list(report["training"]))
        print(
            "OFFICIAL_GINO_SUMMARY_REBUILT "
            f"rows={len(rows)} unique_geometries={len(distinct)}"
        )
        return
    if args.quick:
        config["training_geometries"] = 8
        config["test_geometries_per_split"] = 3
        config["seeds"] = config["seeds"][:1]
        config["epochs"] = 3
        config["report_every"] = 1

    train_cases = latin_hypercube_cases(
        "train",
        int(config["training_geometries"]),
        config["training_bounds"],
        int(config["geometry_seed"]),
    )
    test_cases = []
    for split_index, (split, bounds) in enumerate(config["test_bounds"].items()):
        test_cases.extend(
            latin_hypercube_cases(
                split,
                int(config["test_geometries_per_split"]),
                bounds,
                int(config["geometry_seed"]) + 1000 * (split_index + 1),
            )
        )
    raw_train = prepare_cases(int(config["level"]), train_cases)
    raw_test = prepare_cases(int(config["level"]), test_cases)
    train, mean, scale = normalize(raw_train)
    test, _, _ = normalize(raw_train, raw_test)
    # ``normalize(train, raw_test)`` uses statistics from ``raw_train``.
    test["features"] = (raw_test["features"] - mean) / scale

    rows: list[dict[str, Any]] = []
    training_rows: list[dict[str, Any]] = []
    args.checkpoint_dir.mkdir(parents=True, exist_ok=True)
    source_file = Path(sys.modules[GINO.__module__].__file__).resolve()
    package_root = Path(neuralop.__file__).resolve().parent
    source_identifier = (Path("neuralop") / source_file.relative_to(package_root)).as_posix()
    total_started = time.perf_counter()
    for seed in config["seeds"]:
        model, history, training_seconds = train_model(train, config, int(seed))
        checkpoint = args.checkpoint_dir / f"official_gino_seed{seed}.pt"
        # Strip OrderedDict metadata containing module callables so the public
        # artifact can be loaded by PyTorch's restricted weights-only loader.
        safe_state = {
            name: tensor.detach().cpu()
            for name, tensor in model.state_dict().items()
            if isinstance(tensor, torch.Tensor)
        }
        torch.save(safe_state, checkpoint)
        training_rows.append(
            {
                "seed": int(seed),
                "epochs": int(config["epochs"]),
                "parameters": sum(parameter.numel() for parameter in model.parameters()),
                "training_seconds": training_seconds,
                "final_loss": float(history[-1]["loss"]),
                "checkpoint": checkpoint.as_posix(),
                "checkpoint_sha256": sha256(checkpoint),
            }
        )
        predictions = predict(model, test, int(config["batch_size"]))
        for case, prediction, target in zip(test_cases, predictions, raw_test["target"]):
            mesh = build_mesh(int(config["level"]), case.shear, case.stretch)
            error = energy_error_diagnostic(mesh, prediction, case.contrast)
            norm = energy_error_diagnostic(
                mesh, np.zeros_like(prediction), case.contrast
            )
            operator_error = discrete_energy_norm(
                mesh, prediction - target, case.contrast
            )
            target_norm = discrete_energy_norm(mesh, target, case.contrast)
            optimized = optimize_flux(
                mesh,
                prediction,
                "dirichlet",
                case.contrast,
                ElementTriRT2(),
                int(config["quadrature_order"]),
                int(config["reweight_iterations"]),
            )
            certificate = native_quadrature_result(optimized)
            audit = certificate["native_hdiv_audit"]
            rows.append(
                {
                    "seed": int(seed),
                    "split": case.split,
                    "geometry_id": int(case.geometry_id),
                    "shear": case.shear,
                    "stretch": case.stretch,
                    "contrast": case.contrast,
                    "continuous_relative_energy_error": error / max(norm, 1e-300),
                    "operator_relative_energy_error": operator_error / max(target_norm, 1e-300),
                    "rt2_native_floating_majorant": certificate["functional_majorant"],
                    "rt2_native_floating_effectivity": certificate["functional_majorant"] / max(error, 1e-300),
                    "exact_discrete_hdiv_membership": audit["exact_discrete_hdiv_membership"],
                    "max_sampled_interior_normal_jump": audit["max_sampled_interior_normal_jump"],
                }
            )
        print(
            f"official GINO seed={seed} training_seconds={training_seconds:.1f} "
            f"final_loss={history[-1]['loss']:.6e}",
            flush=True,
        )

    report = {
        "benchmark": "official_upstream_neuraloperator_gino_certification_audit",
        "upstream": {
            "package": "neuraloperator",
            "version": str(neuralop.__version__),
            "model_class": "neuralop.models.GINO",
            "source_file": source_identifier,
            "source_sha256": sha256(source_file),
            "documentation": "https://neuraloperator.github.io/stable/modules/generated/neuralop.models.GINO.html",
        },
        "coordinate_policy": config["coordinate_policy"],
        "certifier_change": "none; the existing native RT2 wrapper receives only realized nodal outputs",
        "config_file": str(args.config),
        "config_sha256": sha256(args.config),
        "config": config,
        "training": training_rows,
        "overall": summarize(rows, 20260801),
        "by_split": {
            split: summarize(
                [row for row in rows if row["split"] == split], 20260801
            )
            for split in config["test_bounds"]
        },
        "strictness": (
            "The official-model experiment uses ordinary floating RT2 quadrature. "
            "It validates black-box compatibility, not machine-enclosed endpoints."
        ),
        "elapsed_seconds": time.perf_counter() - total_started,
        "rows": rows,
    }
    args.summary_out.parent.mkdir(parents=True, exist_ok=True)
    args.summary_out.write_text(
        json.dumps(report, indent=2, sort_keys=True), encoding="utf-8"
    )
    write_csv(args.rows_out, rows)
    write_csv(args.training_out, training_rows)


if __name__ == "__main__":
    main()
