"""Fair end-to-end cost audit for compliance-specialized screening.

Both the direct-label and screened paths use the same vectorized FE assembly,
the same affine-in-contrast reuse, the same sparse solver, and the same worker
count.  The screened path additionally includes native-grid neural inference,
bilinear conforming reconstruction, compliance interval evaluation, exact
comparison logic in the theorem (ordinary binary64 in this timing audit), and
all survivor solves.  Training and post-screening full-pool truth audits are
excluded and reported separately.
"""

from __future__ import annotations

import argparse
import csv
import gc
import hashlib
import json
import math
import random
import statistics
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from itertools import product
from pathlib import Path
from typing import Any, Callable

import numpy as np
import torch
import torch.nn.functional as torch_functional
from scipy.sparse import csr_matrix
from scipy.sparse.linalg import spsolve

try:
    from threadpoolctl import threadpool_limits
except ImportError:  # pragma: no cover - recorded in output
    threadpool_limits = None

sys.dont_write_bytecode = True
SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from independent_flux_audit import (
    AuditMesh,
    assemble_dirichlet_problem_vectorized,
    build_mesh,
    coefficient,
    element_geometry,
    explicit_constants,
    is_dirichlet_node,
)
from poisson_grid_fno_operator_certification import GridFNOSurrogate


def lumped_mass_diagonal(mesh: AuditMesh) -> np.ndarray:
    """Return the P1 lumped-mass diagonal without optional FEM packages."""
    _, _, areas = element_geometry(mesh)
    diagonal = np.zeros(len(mesh.physical_nodes), dtype=float)
    for local in range(3):
        np.add.at(diagonal, mesh.elements[:, local], areas / 3.0)
    return diagonal


def affine_feature_grid(mesh: AuditMesh, contrast: float) -> np.ndarray:
    """Build the frozen affine-geometry feature tensor used by the checkpoint."""
    side = int(round(math.sqrt(len(mesh.reference_nodes))))
    reference = mesh.reference_nodes.reshape(side, side, 2)
    physical = mesh.physical_nodes.reshape(side, side, 2)
    displacement = physical - reference
    material = coefficient(reference, contrast)
    determinant = np.full((side, side), mesh.stretch, dtype=float)
    return np.stack(
        [
            reference[:, :, 0],
            reference[:, :, 1],
            physical[:, :, 0],
            physical[:, :, 1],
            displacement[:, :, 0],
            displacement[:, :, 1],
            material,
            determinant,
            np.full((side, side), mesh.shear, dtype=float),
            np.full((side, side), mesh.stretch, dtype=float),
            np.full((side, side), math.log10(contrast), dtype=float),
        ],
        axis=0,
    )


def feature_normalization(
    level: int, training_grid: dict[str, list[float]]
) -> tuple[np.ndarray, np.ndarray]:
    rows = []
    for shear, stretch, contrast in product(
        training_grid["shears"],
        training_grid["stretches"],
        training_grid["contrasts"],
    ):
        rows.append(
            affine_feature_grid(
                build_mesh(level, float(shear), float(stretch)), float(contrast)
            )
        )
    raw = np.stack(rows)
    mean = raw.mean(axis=(0, 2, 3), keepdims=True)
    scale = raw.std(axis=(0, 2, 3), keepdims=True)
    scale[scale == 0.0] = 1.0
    return mean, scale


def load_predictor(
    base_config: dict[str, Any],
    upgrade: dict[str, Any],
    checkpoint: Path,
) -> tuple[GridFNOSurrogate, np.ndarray, np.ndarray]:
    """Load the released safe state dictionary using only core dependencies."""
    level = int(upgrade["level"])
    mean, scale = feature_normalization(level, base_config["training_grid"])
    fno = base_config["fno"]
    model = GridFNOSurrogate(
        int(mean.shape[1]), int(fno["width"]), int(fno["modes"]), int(fno["layers"])
    )
    state = torch.load(checkpoint, map_location="cpu", weights_only=True)
    model.load_state_dict(state)
    model.eval()
    torch.set_num_threads(1)
    return model, mean, scale


@dataclass(frozen=True)
class DiscreteSystem:
    shear: float
    stretch: float
    contrast: float
    matrix: csr_matrix
    load: np.ndarray
    lumped: np.ndarray
    gamma: float


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def mesh_from_template(template: AuditMesh, shear: float, stretch: float) -> AuditMesh:
    reference = template.reference_nodes
    physical = np.column_stack(
        [reference[:, 0] + shear * reference[:, 1], stretch * reference[:, 1]]
    )
    return AuditMesh(
        reference_nodes=reference,
        physical_nodes=physical,
        elements=template.elements,
        boundary_tags=template.boundary_tags,
        shear=float(shear),
        stretch=float(stretch),
    )


def build_reused_systems(level: int, pool: dict[str, Any]) -> list[DiscreteSystem]:
    template = build_mesh(level, 0.0, 1.0)
    output: list[DiscreteSystem] = []
    for shear in pool["shears"]:
        for stretch in pool["stretches"]:
            mesh = mesh_from_template(template, float(shear), float(stretch))
            matrix_one, load_one = assemble_dirichlet_problem_vectorized(mesh, 1.0)
            matrix_two, load_two = assemble_dirichlet_problem_vectorized(mesh, 2.0)
            matrix_slope = matrix_two - matrix_one
            load_slope = load_two - load_one
            fixed = is_dirichlet_node(mesh, "dirichlet")
            free = np.flatnonzero(~fixed)
            lumped = lumped_mass_diagonal(mesh)[free]
            poincare, _ = explicit_constants(mesh, "dirichlet")
            gamma = 1.0 / (4.0 * poincare**2)
            for contrast in pool["contrasts"]:
                factor = float(contrast) - 1.0
                matrix = (matrix_one + factor * matrix_slope).tocsr()
                load = load_one + factor * load_slope
                output.append(
                    DiscreteSystem(
                        float(shear),
                        float(stretch),
                        float(contrast),
                        matrix[free][:, free].tocsr(),
                        np.asarray(load[free], dtype=float),
                        np.asarray(lumped, dtype=float),
                        float(gamma),
                    )
                )
    return output


def native_features(pool: dict[str, Any], native_level: int) -> np.ndarray:
    template = build_mesh(native_level, 0.0, 1.0)
    rows = []
    for shear, stretch, contrast in product(
        pool["shears"], pool["stretches"], pool["contrasts"]
    ):
        mesh = mesh_from_template(template, float(shear), float(stretch))
        rows.append(affine_feature_grid(mesh, float(contrast)))
    return np.stack(rows)


def batch_predictions(
    model: torch.nn.Module,
    mean: np.ndarray,
    scale: np.ndarray,
    pool: dict[str, Any],
    native_level: int,
    target_level: int,
) -> np.ndarray:
    features = native_features(pool, native_level)
    normalized = (features - mean) / scale
    with torch.no_grad():
        tensor = torch.tensor(normalized, dtype=torch.float32)
        native = model(tensor)
        if target_level != native_level:
            native = torch_functional.interpolate(
                native,
                size=(target_level + 1, target_level + 1),
                mode="bilinear",
                align_corners=True,
            )
        values = native[:, 0].cpu().numpy().reshape(len(features), -1)
    values = np.asarray(values, dtype=float)
    side = target_level + 1
    boundary = np.zeros((side, side), dtype=bool)
    boundary[0, :] = True
    boundary[-1, :] = True
    boundary[:, 0] = True
    boundary[:, -1] = True
    values[:, boundary.reshape(-1)] = 0.0
    return values[:, ~boundary.reshape(-1)]


def compliance_intervals(
    systems: list[DiscreteSystem], predictions: np.ndarray
) -> tuple[np.ndarray, np.ndarray]:
    lower = np.empty(len(systems), dtype=float)
    upper = np.empty(len(systems), dtype=float)
    for index, (system, prediction) in enumerate(zip(systems, predictions)):
        image = system.matrix @ prediction
        residual = system.load - image
        center = float(
            2.0 * np.dot(system.load, prediction)
            - np.dot(prediction, image)
        )
        tail = float(
            np.sum(residual * residual / system.lumped) / system.gamma
        )
        lower[index] = center
        upper[index] = center + max(tail, 0.0)
    return lower, upper


def solve_indices(
    systems: list[DiscreteSystem], indices: np.ndarray, workers: int
) -> np.ndarray:
    selected = [int(index) for index in indices]

    def solve(index: int) -> float:
        system = systems[index]
        value = spsolve(system.matrix, system.load)
        return float(np.dot(system.load, value))

    if workers <= 1:
        return np.asarray([solve(index) for index in selected], dtype=float)
    with ThreadPoolExecutor(max_workers=workers) as executor:
        return np.asarray(list(executor.map(solve, selected)), dtype=float)


def direct_action(
    level: int, pool: dict[str, Any], workers: int
) -> dict[str, Any]:
    systems = build_reused_systems(level, pool)
    indices = np.arange(len(systems), dtype=int)
    objectives = solve_indices(systems, indices, workers)
    return {
        "objectives": objectives,
        "selected": int(np.argmin(objectives)),
        "systems": systems,
    }


def screened_action(
    level: int,
    pool: dict[str, Any],
    workers: int,
    model: torch.nn.Module,
    mean: np.ndarray,
    scale: np.ndarray,
    native_level: int,
) -> dict[str, Any]:
    systems = build_reused_systems(level, pool)
    predictions = batch_predictions(
        model, mean, scale, pool, native_level, level
    )
    lower, upper = compliance_intervals(systems, predictions)
    incumbent = float(np.min(upper))
    survivors = np.flatnonzero(lower <= incumbent)
    objectives = solve_indices(systems, survivors, workers)
    selected = int(survivors[int(np.argmin(objectives))])
    return {
        "lower": lower,
        "upper": upper,
        "survivors": survivors,
        "objectives": objectives,
        "selected": selected,
        "systems": systems,
    }


def prepared_direct_action(
    systems: list[DiscreteSystem], workers: int
) -> dict[str, Any]:
    indices = np.arange(len(systems), dtype=int)
    objectives = solve_indices(systems, indices, workers)
    return {"objectives": objectives, "selected": int(np.argmin(objectives))}


def prepared_screened_action(
    systems: list[DiscreteSystem],
    level: int,
    pool: dict[str, Any],
    workers: int,
    model: torch.nn.Module,
    mean: np.ndarray,
    scale: np.ndarray,
    native_level: int,
) -> dict[str, Any]:
    predictions = batch_predictions(
        model, mean, scale, pool, native_level, level
    )
    lower, upper = compliance_intervals(systems, predictions)
    survivors = np.flatnonzero(lower <= float(np.min(upper)))
    objectives = solve_indices(systems, survivors, workers)
    return {
        "survivors": survivors,
        "objectives": objectives,
        "selected": int(survivors[int(np.argmin(objectives))]),
    }


def time_once(action: Callable[[], Any]) -> tuple[float, Any]:
    started = time.perf_counter()
    output = action()
    return time.perf_counter() - started, output


def paired_samples(
    direct: Callable[[], Any],
    screened: Callable[[], Any],
    samples: int,
    seed: int,
) -> tuple[list[float], list[float], Any]:
    direct()
    screened()
    generator = random.Random(seed)
    direct_times: list[float] = []
    screened_times: list[float] = []
    screened_output = None
    enabled = gc.isenabled()
    gc.disable()
    try:
        for _ in range(samples):
            if generator.randrange(2):
                first, screened_output = time_once(screened)
                second, _ = time_once(direct)
                screened_times.append(first)
                direct_times.append(second)
            else:
                first, _ = time_once(direct)
                second, screened_output = time_once(screened)
                direct_times.append(first)
                screened_times.append(second)
    finally:
        if enabled:
            gc.enable()
    return direct_times, screened_times, screened_output


def bootstrap_ratio(
    direct: list[float], screened: list[float], draws: int, seed: int
) -> dict[str, Any]:
    direct_array = np.asarray(direct, dtype=float)
    screened_array = np.asarray(screened, dtype=float)
    ratios = screened_array / direct_array
    generator = np.random.default_rng(seed)
    indices = generator.integers(0, len(ratios), size=(draws, len(ratios)))
    samples = np.median(ratios[indices], axis=1)
    return {
        "paired_samples": len(ratios),
        "screened_over_direct_median": float(np.median(ratios)),
        "lower_95": float(np.quantile(samples, 0.025)),
        "upper_95": float(np.quantile(samples, 0.975)),
        "speedup_median": float(1.0 / np.median(ratios)),
        "direct_seconds_median": float(np.median(direct_array)),
        "screened_seconds_median": float(np.median(screened_array)),
        "raw_direct_seconds": direct,
        "raw_screened_seconds": screened,
    }


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = sorted({key for row in rows for key in row})
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--config",
        type=Path,
        default=Path(
            "experiments/configs/optimized_end_to_end_cost_prespecified_2026-08-01.json"
        ),
    )
    parser.add_argument(
        "--base-config",
        type=Path,
        default=Path("experiments/configs/cost_benchmark_base_config.json"),
    )
    parser.add_argument("--quick", action="store_true")
    parser.add_argument(
        "--summary-out",
        type=Path,
        default=Path(
            "experiments/results/optimized_end_to_end_cost_summary.json"
        ),
    )
    parser.add_argument(
        "--rows-out",
        type=Path,
        default=Path(
            "experiments/results/optimized_end_to_end_cost_rows.csv"
        ),
    )
    parser.add_argument(
        "--pairs-out",
        type=Path,
        default=Path(
            "experiments/results/optimized_end_to_end_cost_paired_timings.csv"
        ),
    )
    args = parser.parse_args()

    document = json.loads(args.config.read_text(encoding="utf-8"))
    benchmark = dict(document["benchmark"])
    base_document = json.loads(args.base_config.read_text(encoding="utf-8"))
    base = dict(base_document["trained_output_rt"])
    model_config = document["model"]
    load_config = {
        "level": int(model_config["native_level"]),
        "checkpoint": model_config["checkpoint"],
    }
    model_started = time.perf_counter()
    model, mean, scale = load_predictor(
        base, load_config, Path(model_config["checkpoint"])
    )
    model_load_seconds = time.perf_counter() - model_started
    torch.set_num_threads(1)

    pools = list(benchmark["pools"])
    levels = list(benchmark["levels"])
    workers_values = list(benchmark["workers"])
    samples = int(benchmark["paired_samples"])
    selected_cases = {
        (
            int(case["level"]),
            str(case["pool"]),
            int(case["workers"]),
            str(case["scope"]),
        )
        for case in benchmark.get("selected_cases", [])
    }
    if args.quick:
        pools = [dict(pools[0])]
        pools[0]["shears"] = pools[0]["shears"][:2]
        pools[0]["stretches"] = pools[0]["stretches"][:2]
        pools[0]["contrasts"] = pools[0]["contrasts"][:2]
        levels = [levels[0]]
        workers_values = [1]
        samples = 2

    rows: list[dict[str, Any]] = []
    pair_rows: list[dict[str, Any]] = []
    run_id = 0
    limit_context = (
        threadpool_limits(limits=int(benchmark["threads_per_solve"]))
        if threadpool_limits is not None
        else None
    )
    if limit_context is not None:
        limit_context.__enter__()
    try:
        for level in levels:
            for pool in pools:
                prepared_systems = build_reused_systems(level, pool)
                direct_truth = prepared_direct_action(prepared_systems, 1)
                true_best = int(direct_truth["selected"])
                for workers in workers_values:
                    cold_direct = lambda: direct_action(level, pool, workers)
                    cold_screened = lambda: screened_action(
                        level,
                        pool,
                        workers,
                        model,
                        mean,
                        scale,
                        int(model_config["native_level"]),
                    )
                    prepared_direct = lambda: prepared_direct_action(
                        prepared_systems, workers
                    )
                    prepared_screened = lambda: prepared_screened_action(
                        prepared_systems,
                        level,
                        pool,
                        workers,
                        model,
                        mean,
                        scale,
                        int(model_config["native_level"]),
                    )
                    for scope, direct, screened in (
                        ("cold_end_to_end", cold_direct, cold_screened),
                        ("prepared_systems_resident_model", prepared_direct, prepared_screened),
                    ):
                        if selected_cases and (
                            int(level), str(pool["name"]), int(workers), scope
                        ) not in selected_cases:
                            continue
                        direct_times, screened_times, output = paired_samples(
                            direct,
                            screened,
                            samples,
                            int(benchmark["timing_seed"]) + run_id,
                        )
                        ratio = bootstrap_ratio(
                            direct_times,
                            screened_times,
                            int(benchmark["bootstrap_draws"]),
                            int(benchmark["timing_seed"]) + 1000 + run_id,
                        )
                        survivors = np.asarray(output["survivors"], dtype=int)
                        selected = int(output["selected"])
                        if true_best not in survivors or selected != true_best:
                            raise AssertionError(
                                f"screening lost the audited best in {pool['name']}"
                            )
                        row = {
                            "scope": scope,
                            "level": level,
                            "free_dofs": int(prepared_systems[0].matrix.shape[0]),
                            "pool": pool["name"],
                            "difficulty": pool["difficulty"],
                            "pool_size": len(prepared_systems),
                            "workers": workers,
                            "survivors": len(survivors),
                            "elimination_rate": 1.0 - len(survivors) / len(prepared_systems),
                            "true_best_retained": True,
                            "selected_true_best": True,
                            **{key: value for key, value in ratio.items() if not key.startswith("raw_")},
                        }
                        rows.append(row)
                        for pair_index, (direct_seconds, screened_seconds) in enumerate(
                            zip(direct_times, screened_times)
                        ):
                            pair_rows.append(
                                {
                                    "run_id": run_id,
                                    "pair_index": pair_index,
                                    "scope": scope,
                                    "level": level,
                                    "pool": pool["name"],
                                    "difficulty": pool["difficulty"],
                                    "workers": workers,
                                    "direct_seconds": direct_seconds,
                                    "screened_seconds": screened_seconds,
                                    "screened_over_direct": screened_seconds
                                    / direct_seconds,
                                }
                            )
                        print(
                            f"{scope} n={level} {pool['name']} workers={workers} "
                            f"survivors={len(survivors)} ratio="
                            f"{row['screened_over_direct_median']:.3f} "
                            f"CI=[{row['lower_95']:.3f},{row['upper_95']:.3f}]"
                        )
                        run_id += 1
    finally:
        if limit_context is not None:
            limit_context.__exit__(None, None, None)

    report = {
        "benchmark": "optimized_fair_end_to_end_compliance_screening",
        "config_file": str(args.config),
        "config_sha256": sha256(args.config),
        "base_config_file": str(args.base_config),
        "base_config_sha256": sha256(args.base_config),
        "model_checkpoint_sha256": sha256(Path(model_config["checkpoint"])),
        "model_load_seconds_separate": model_load_seconds,
        "timing_scope": {
            "cold_end_to_end": (
                "common vectorized mesh/matrix/load preparation plus all direct "
                "solves versus the same preparation plus native-grid inference, "
                "bilinear reconstruction, interval evaluation, and survivor solves"
            ),
            "prepared_systems_resident_model": (
                "preassembled systems are shared; screened path still includes "
                "complete batch inference, reconstruction, intervals, and survivor solves"
            ),
            "excluded": (
                "training and post-screening full-pool truth audit; model load is "
                "reported separately"
            ),
        },
        "fairness": {
            "same_vectorized_assembly": True,
            "same_affine_contrast_reuse": True,
            "same_sparse_solver": True,
            "same_worker_count": True,
            "same_threads_per_solve": int(benchmark["threads_per_solve"]),
            "paired_randomized_order": True,
            "threadpoolctl_available": threadpool_limits is not None,
        },
        "claim_boundary": {
            "arithmetic": (
                "This is an ordinary-binary64 timing audit of the exact-arithmetic "
                "compliance interval. Machine-verified screening is reported by "
                "machine_verified_discrete_screening.py at level 8."
            ),
            "speed": (
                "A speed claim is supported only for rows whose paired bootstrap "
                "upper endpoint is below one in this run; the intervals are "
                "descriptive and are not formal familywise multiple-comparison claims."
            ),
        },
        "aggregate": {
            "runs": len(rows),
            "speed_advantage_rows": sum(row["upper_95"] < 1.0 for row in rows),
            "speedup_at_least_1_5_rows": sum(
                row["upper_95"] < (1.0 / 1.5) for row in rows
            ),
            "true_best_retained_all": all(row["true_best_retained"] for row in rows),
            "median_speedup": statistics.median(
                row["speedup_median"] for row in rows
            ),
        },
        "rows": rows,
    }
    args.summary_out.parent.mkdir(parents=True, exist_ok=True)
    args.summary_out.write_text(
        json.dumps(report, indent=2, sort_keys=True), encoding="utf-8"
    )
    write_csv(args.rows_out, rows)
    write_csv(args.pairs_out, pair_rows)


if __name__ == "__main__":
    main()
