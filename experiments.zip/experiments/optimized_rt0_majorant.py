"""Optimize RT0 fluxes for sharp functional majorants on the existing family.

Two variants are compared with the legacy edge-distance projection:

* an energy-weighted constrained projection that preserves exact element
  integral balance and Neumann edge moments;
* an iteratively reweighted minimizer of the complete RT0 functional
  majorant.  It remains H(div)-conforming but pays, rather than suppresses,
  equilibrium and Neumann residuals.

The optimizer uses ordinary quadrature only to choose a flux.  The reported
coverage is checked afterwards by the independent upper-sum majorant, so no
truth error enters flux construction or calibration.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import statistics
import sys
import time
from pathlib import Path
from typing import Any

import numpy as np
from scipy.sparse import bmat, coo_matrix, csr_matrix, vstack
from scipy.sparse.linalg import spsolve

sys.dont_write_bytecode = True
SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from independent_flux_audit import (
    affine_matrices,
    boundary_edges,
    build_mesh,
    coefficient,
    edge_topology,
    energy_error_diagnostic,
    equilibrate_rt0_flux,
    equilibrated_functional_upper_sum,
    exact_neumann,
    explicit_constants,
    forcing,
    is_dirichlet_node,
    is_neumann_edge,
    neumann_flux_moment,
    recover_flux_independently,
    solve_problem,
    subdivisions,
    assemble_problem,
    triangle_forcing_moments,
)


def forcing_reference_gradient(
    mesh: Any, points: np.ndarray, contrast: float
) -> np.ndarray:
    """Exact gradient of the manufactured forcing in reference coordinates."""
    xi, eta = points[..., 0], points[..., 1]
    jacobian, inverse_transpose = affine_matrices(mesh)
    inverse = np.linalg.inv(jacobian)
    pulled = mesh.stretch * inverse @ inverse.T
    sine_coefficient = (
        math.pi**2 * (pulled[0, 0] + pulled[1, 1]) / mesh.stretch
    )
    cosine_coefficient = -2.0 * math.pi**2 * pulled[0, 1] / mesh.stretch
    coefficient_gradient = (contrast - 1.0) * inverse_transpose[:, 0]
    reference_contraction = inverse_transpose.T @ coefficient_gradient
    sine_x, sine_y = np.sin(math.pi * xi), np.sin(math.pi * eta)
    cosine_x, cosine_y = np.cos(math.pi * xi), np.cos(math.pi * eta)
    laplace_term = (
        sine_coefficient * sine_x * sine_y
        + cosine_coefficient * cosine_x * cosine_y
    )
    laplace_x = math.pi * (
        sine_coefficient * cosine_x * sine_y
        - cosine_coefficient * sine_x * cosine_y
    )
    laplace_y = math.pi * (
        sine_coefficient * sine_x * cosine_y
        - cosine_coefficient * cosine_x * sine_y
    )
    gradient_term_x = math.pi**2 * (
        -reference_contraction[0] * sine_x * sine_y
        + reference_contraction[1] * cosine_x * cosine_y
    )
    gradient_term_y = math.pi**2 * (
        reference_contraction[0] * cosine_x * cosine_y
        - reference_contraction[1] * sine_x * sine_y
    )
    material = 1.0 + (contrast - 1.0) * xi
    derivative_x = (
        (contrast - 1.0) * laplace_term
        + material * laplace_x
        - gradient_term_x
    )
    derivative_y = material * laplace_y - gradient_term_y
    return np.stack([derivative_x, derivative_y], axis=-1)


def forcing_reference_hessian_bound(mesh: Any, contrast: float) -> float:
    jacobian, inverse_transpose = affine_matrices(mesh)
    inverse = np.linalg.inv(jacobian)
    pulled = mesh.stretch * inverse @ inverse.T
    sine_coefficient = (
        math.pi**2 * (pulled[0, 0] + pulled[1, 1]) / mesh.stretch
    )
    cosine_coefficient = -2.0 * math.pi**2 * pulled[0, 1] / mesh.stretch
    base = abs(sine_coefficient) + abs(cosine_coefficient)
    coefficient_gradient = (contrast - 1.0) * inverse_transpose[:, 0]
    contraction = inverse_transpose.T @ coefficient_gradient
    contraction_sum = abs(contraction[0]) + abs(contraction[1])
    material_slope = abs(contrast - 1.0)
    common = math.pi**3 * contraction_sum
    hessian_xx = (
        2.0 * material_slope * math.pi * base
        + contrast * math.pi**2 * base
        + common
    )
    hessian_yy = contrast * math.pi**2 * base + common
    hessian_xy = (
        material_slope * math.pi * base
        + contrast * math.pi**2 * base
        + common
    )
    return math.sqrt(hessian_xx**2 + hessian_yy**2 + 2.0 * hessian_xy**2)


def neumann_reference_gradient(
    mesh: Any,
    points: np.ndarray,
    normal: np.ndarray,
    contrast: float,
) -> np.ndarray:
    xi, eta = points[..., 0], points[..., 1]
    _, inverse_transpose = affine_matrices(mesh)
    contraction = inverse_transpose.T @ normal
    sine_x, sine_y = np.sin(math.pi * xi), np.sin(math.pi * eta)
    cosine_x, cosine_y = np.cos(math.pi * xi), np.cos(math.pi * eta)
    base = math.pi * (
        contraction[0] * cosine_x * sine_y
        + contraction[1] * sine_x * cosine_y
    )
    derivative_x_base = math.pi**2 * (
        -contraction[0] * sine_x * sine_y
        + contraction[1] * cosine_x * cosine_y
    )
    derivative_y_base = math.pi**2 * (
        contraction[0] * cosine_x * cosine_y
        - contraction[1] * sine_x * sine_y
    )
    material = 1.0 + (contrast - 1.0) * xi
    return np.stack(
        [
            (contrast - 1.0) * base + material * derivative_x_base,
            material * derivative_y_base,
        ],
        axis=-1,
    )


def neumann_reference_hessian_bound(
    mesh: Any, normal: np.ndarray, contrast: float
) -> float:
    _, inverse_transpose = affine_matrices(mesh)
    contraction = inverse_transpose.T @ normal
    contraction_sum = abs(contraction[0]) + abs(contraction[1])
    slope = abs(contrast - 1.0)
    hessian_xx = (
        2.0 * slope * math.pi**2 * contraction_sum
        + contrast * math.pi**3 * contraction_sum
    )
    hessian_yy = contrast * math.pi**3 * contraction_sum
    hessian_xy = (
        slope * math.pi**2 * contraction_sum
        + contrast * math.pi**3 * contraction_sum
    )
    return math.sqrt(hessian_xx**2 + hessian_yy**2 + 2.0 * hessian_xy**2)


def taylor_functional_upper_sum(
    mesh: Any,
    boundary_mode: str,
    contrast: float,
    depth: int,
    flux: dict[str, Any],
) -> dict[str, float]:
    """Certified upper sum using local first derivatives and Hessian bounds."""
    areas = np.asarray(flux["areas"])
    field_gradients = np.asarray(flux["field_gradients"])
    local_outward = np.asarray(flux["local_outward_integrals"])
    reference_elements = mesh.reference_nodes[mesh.elements]
    physical_elements = mesh.physical_nodes[mesh.elements]
    pieces = subdivisions(depth)
    centers = np.mean(pieces, axis=1)
    reference_points = np.einsum("sb,tbd->tsd", centers, reference_elements)
    physical_points = np.einsum("sb,tbd->tsd", centers, physical_elements)
    maximum_reference_diameter = np.maximum.reduce(
        [
            np.linalg.norm(reference_elements[:, 0] - reference_elements[:, 1], axis=1),
            np.linalg.norm(reference_elements[:, 1] - reference_elements[:, 2], axis=1),
            np.linalg.norm(reference_elements[:, 2] - reference_elements[:, 0], axis=1),
        ]
    )
    radius = maximum_reference_diameter[:, None] / (2.0**depth)
    differences = physical_points[:, :, None, :] - physical_elements[:, None, :, :]
    flux_values = np.einsum("ti,tsid->tsd", local_outward, differences) / (
        2.0 * areas[:, None, None]
    )
    divergences = np.sum(local_outward, axis=1) / areas
    forcing_values = forcing(mesh, reference_points, contrast)
    forcing_gradient_norm = np.linalg.norm(
        forcing_reference_gradient(mesh, reference_points, contrast), axis=2
    )
    forcing_hessian = forcing_reference_hessian_bound(mesh, contrast)
    residual_upper = (
        np.abs(forcing_values + divergences[:, None])
        + forcing_gradient_norm * radius
        + 0.5 * forcing_hessian * radius**2
    )
    residual_squared_upper = float(
        np.sum(areas[:, None] * residual_upper**2 / len(pieces))
    )

    coefficient_values = coefficient(reference_points, contrast)
    mismatch_values = flux_values - coefficient_values[..., None] * field_gradients[:, None, :]
    jacobian, _ = affine_matrices(mesh)
    dilation = np.sum(local_outward, axis=1) / (2.0 * areas)
    flux_reference_gradients = dilation[:, None, None] * jacobian[None, :, :]
    coefficient_reference_gradient = np.array([contrast - 1.0, 0.0])
    mismatch_reference_gradients = (
        flux_reference_gradients
        - field_gradients[:, :, None] * coefficient_reference_gradient[None, None, :]
    )
    mismatch_lipschitz = np.linalg.norm(mismatch_reference_gradients, axis=(1, 2))
    mismatch_upper = (
        np.linalg.norm(mismatch_values, axis=2)
        + mismatch_lipschitz[:, None] * radius
    )
    mismatch_squared_upper = float(
        np.sum(areas[:, None] * mismatch_upper**2 / len(pieces))
    )

    neumann_squared_upper = 0.0
    segments = 2 ** (depth + 1)
    for first, second, element, normal in boundary_edges(mesh):
        if not is_neumann_edge(mesh, first, second, boundary_mode):
            continue
        triangle = mesh.elements[element]
        local_vertices = {
            int(np.flatnonzero(triangle == first)[0]),
            int(np.flatnonzero(triangle == second)[0]),
        }
        opposite = next(index for index in range(3) if index not in local_vertices)
        physical_length = float(
            np.linalg.norm(mesh.physical_nodes[second] - mesh.physical_nodes[first])
        )
        first_ref, second_ref = mesh.reference_nodes[[first, second]]
        reference_length = float(np.linalg.norm(second_ref - first_ref))
        normal_trace = local_outward[element, opposite] / physical_length
        hessian_bound = neumann_reference_hessian_bound(mesh, normal, contrast)
        for segment in range(segments):
            parameter = (segment + 0.5) / segments
            point = (1.0 - parameter) * first_ref + parameter * second_ref
            residual_value = float(
                exact_neumann(mesh, point, normal, contrast) - normal_trace
            )
            gradient_norm = float(
                np.linalg.norm(
                    neumann_reference_gradient(
                        mesh, point, normal, contrast
                    )
                )
            )
            radius_1d = reference_length / (2.0 * segments)
            upper = (
                abs(residual_value)
                + gradient_norm * radius_1d
                + 0.5 * hessian_bound * radius_1d**2
            )
            neumann_squared_upper += physical_length / segments * upper**2

    poincare, trace = explicit_constants(mesh, boundary_mode)
    mismatch_norm = math.sqrt(max(mismatch_squared_upper, 0.0))
    residual_norm = math.sqrt(max(residual_squared_upper, 0.0))
    boundary_norm = math.sqrt(max(neumann_squared_upper, 0.0))
    return {
        "flux_mismatch_upper": mismatch_norm,
        "equilibrium_residual_upper": residual_norm,
        "neumann_residual_upper": boundary_norm,
        "functional_majorant": (
            mismatch_norm + poincare * residual_norm + trace * boundary_norm
        ),
        "poincare_constant": poincare,
        "trace_constant": trace,
    }


def duffy_rule(order: int) -> list[tuple[float, np.ndarray]]:
    points, weights = np.polynomial.legendre.leggauss(order)
    points = 0.5 * (points + 1.0)
    weights = 0.5 * weights
    rule = []
    for r, weight_r in zip(points, weights):
        for s, weight_s in zip(points, weights):
            barycentric = np.array([(1.0 - r) * (1.0 - s), r, (1.0 - r) * s])
            rule.append((2.0 * weight_r * weight_s * (1.0 - r), barycentric))
    return rule


def add_local_matrix(
    rows: list[int],
    columns: list[int],
    data: list[float],
    indices: np.ndarray,
    local: np.ndarray,
) -> None:
    for local_i, global_i in enumerate(indices):
        for local_j, global_j in enumerate(indices):
            rows.append(int(global_i))
            columns.append(int(global_j))
            data.append(float(local[local_i, local_j]))


def quadratic_components(
    mesh: Any,
    values: np.ndarray,
    boundary_mode: str,
    contrast: float,
    order: int,
) -> dict[str, Any]:
    edges, adjacent = edge_topology(mesh)
    edge_indices = {edge: index for index, edge in enumerate(edges)}
    edge_lengths = np.array(
        [
            np.linalg.norm(mesh.physical_nodes[second] - mesh.physical_nodes[first])
            for first, second in edges
        ],
        dtype=float,
    )
    _, field_gradients, _, areas = recover_flux_independently(
        mesh, values, contrast
    )
    matrix_rows = [[] for _ in range(3)]
    matrix_columns = [[] for _ in range(3)]
    matrix_data = [[] for _ in range(3)]
    linear = [np.zeros(len(edges), dtype=float) for _ in range(3)]
    constants = np.zeros(3, dtype=float)
    incidence_rows: list[int] = []
    incidence_columns: list[int] = []
    incidence_data: list[float] = []
    rule = duffy_rule(order)
    local_edge_indices = np.zeros((len(mesh.elements), 3), dtype=int)
    local_signs = np.zeros((len(mesh.elements), 3), dtype=float)
    for element, triangle in enumerate(mesh.elements):
        for opposite in range(3):
            local = [index for index in range(3) if index != opposite]
            edge = tuple(sorted((int(triangle[local[0]]), int(triangle[local[1]]))))
            edge_index = edge_indices[edge]
            sign = next(item[2] for item in adjacent[edge_index] if item[0] == element)
            local_edge_indices[element, opposite] = edge_index
            local_signs[element, opposite] = sign
            incidence_rows.append(element)
            incidence_columns.append(edge_index)
            incidence_data.append(sign)
        indices = local_edge_indices[element]
        signs = local_signs[element]
        physical_vertices = mesh.physical_nodes[triangle]
        reference_vertices = mesh.reference_nodes[triangle]
        local_matrices = [np.zeros((3, 3), dtype=float) for _ in range(3)]
        local_linears = [np.zeros(3, dtype=float) for _ in range(3)]
        divergence_vector = signs / areas[element]
        for normalized_weight, barycentric in rule:
            physical_weight = normalized_weight * areas[element]
            physical_point = barycentric @ physical_vertices
            reference_point = barycentric @ reference_vertices
            basis = np.stack(
                [
                    signs[opposite]
                    * (physical_point - physical_vertices[opposite])
                    / (2.0 * areas[element])
                    for opposite in range(3)
                ],
                axis=1,
            )
            diffusivity = float(coefficient(reference_point, contrast))
            source = float(forcing(mesh, reference_point, contrast))
            gradient = field_gradients[element]
            local_matrices[0] += physical_weight * (basis.T @ basis) / diffusivity
            local_linears[0] += physical_weight * (basis.T @ gradient)
            constants[0] += physical_weight * diffusivity * float(np.dot(gradient, gradient))
            local_matrices[1] += physical_weight * np.outer(divergence_vector, divergence_vector)
            local_linears[1] -= physical_weight * source * divergence_vector
            constants[1] += physical_weight * source**2
        for component in range(2):
            add_local_matrix(
                matrix_rows[component], matrix_columns[component],
                matrix_data[component], indices, local_matrices[component]
            )
            linear[component][indices] += local_linears[component]

    points_1d, weights_1d = np.polynomial.legendre.leggauss(order)
    points_1d = 0.5 * (points_1d + 1.0)
    weights_1d = 0.5 * weights_1d
    for first, second, element, normal in boundary_edges(mesh):
        if not is_neumann_edge(mesh, first, second, boundary_mode):
            continue
        edge = tuple(sorted((first, second)))
        edge_index = edge_indices[edge]
        entry = next(item for item in adjacent[edge_index] if item[0] == element)
        sign = entry[2]
        length = edge_lengths[edge_index]
        trace_coefficient = sign / length
        first_ref, second_ref = mesh.reference_nodes[[first, second]]
        points = (
            (1.0 - points_1d[:, None]) * first_ref
            + points_1d[:, None] * second_ref
        )
        target = exact_neumann(mesh, points, normal, contrast)
        weight_sum = length * float(np.sum(weights_1d))
        matrix_rows[2].append(edge_index)
        matrix_columns[2].append(edge_index)
        matrix_data[2].append(weight_sum * trace_coefficient**2)
        linear[2][edge_index] += length * float(np.dot(weights_1d, target)) * trace_coefficient
        constants[2] += length * float(np.dot(weights_1d, target**2))

    matrices = [
        coo_matrix(
            (matrix_data[index], (matrix_rows[index], matrix_columns[index])),
            shape=(len(edges), len(edges)),
        ).tocsr()
        for index in range(3)
    ]
    incidence = coo_matrix(
        (incidence_data, (incidence_rows, incidence_columns)),
        shape=(len(mesh.elements), len(edges)),
    ).tocsr()
    return {
        "edges": edges,
        "adjacent": adjacent,
        "edge_lengths": edge_lengths,
        "local_edge_indices": local_edge_indices,
        "local_signs": local_signs,
        "incidence": incidence,
        "matrices": matrices,
        "linear": linear,
        "constants": constants,
        "areas": areas,
        "field_gradients": field_gradients,
        "reference_elements": mesh.reference_nodes[mesh.elements],
    }


def quadratic_value(matrix: csr_matrix, linear: np.ndarray, constant: float, flux: np.ndarray) -> float:
    return max(float(np.dot(flux, matrix @ flux) - 2.0 * np.dot(linear, flux) + constant), 0.0)


def flux_record(components: dict[str, Any], flux: np.ndarray, scope: str) -> dict[str, Any]:
    local_outward = components["local_signs"] * flux[components["local_edge_indices"]]
    return {
        "edge_integrals": flux,
        "local_outward_integrals": local_outward,
        "field_gradients": components["field_gradients"],
        "areas": components["areas"],
        "reference_elements": components["reference_elements"],
        "max_interior_normal_trace_difference": 0.0,
        "hdiv_conformity_passed": True,
        "flux_space": "optimized RT0 edge flux",
        "equilibration_scope": scope,
    }


def weighted_equilibrated_flux(
    mesh: Any,
    boundary_mode: str,
    contrast: float,
    components: dict[str, Any],
    moment_order: int = 12,
) -> dict[str, Any]:
    mismatch_matrix = components["matrices"][0]
    mismatch_linear = components["linear"][0]
    edges = components["edges"]
    adjacent = components["adjacent"]
    incidence = components["incidence"]
    constraint_blocks = [incidence]
    right_blocks = [-triangle_forcing_moments(mesh, contrast, moment_order)]
    fixed_rows: list[int] = []
    fixed_columns: list[int] = []
    fixed_data: list[float] = []
    fixed_values: list[float] = []
    for edge_index, ((first, second), edge_adjacent) in enumerate(zip(edges, adjacent)):
        if len(edge_adjacent) != 1 or not is_neumann_edge(mesh, first, second, boundary_mode):
            continue
        _, _, sign, normal = edge_adjacent[0]
        fixed_rows.append(len(fixed_values))
        fixed_columns.append(edge_index)
        fixed_data.append(1.0)
        fixed_values.append(
            sign * neumann_flux_moment(
                mesh, first, second, normal, contrast, moment_order
            )
        )
    if fixed_values:
        fixed_matrix = coo_matrix(
            (fixed_data, (fixed_rows, fixed_columns)),
            shape=(len(fixed_values), len(edges)),
        ).tocsr()
        constraint_blocks.append(fixed_matrix)
        right_blocks.append(np.asarray(fixed_values))
    constraint = vstack(constraint_blocks).tocsr()
    right = np.concatenate(right_blocks)
    zero = csr_matrix((constraint.shape[0], constraint.shape[0]))
    system = bmat(
        [[mismatch_matrix, constraint.T], [constraint, zero]],
        format="csr",
    )
    solution = spsolve(system, np.concatenate([mismatch_linear, right]))
    flux = np.asarray(solution[: len(edges)])
    record = flux_record(
        components, flux,
        "energy-weighted global constrained RT0 projection",
    )
    defects = triangle_forcing_moments(mesh, contrast, moment_order) + np.sum(
        record["local_outward_integrals"], axis=1
    )
    record["max_abs_algebraic_balance_defect"] = float(np.max(np.abs(defects)))
    record["local_integral_equilibrium_passed"] = bool(
        np.max(np.abs(defects)) <= 5.0e4 * np.finfo(float).eps
        * max(1.0, float(np.max(np.abs(right))))
    )
    return record


def majorant_optimized_flux(
    mesh: Any,
    boundary_mode: str,
    components: dict[str, Any],
    reweight_iterations: int = 8,
) -> dict[str, Any]:
    poincare, trace = explicit_constants(mesh, boundary_mode)
    scales = np.array([1.0, poincare**2, trace**2], dtype=float)
    active = scales > 0.0
    weights = np.zeros(3, dtype=float)
    weights[active] = 1.0 / int(np.sum(active))
    flux = np.zeros(len(components["edges"]), dtype=float)
    history = []
    for iteration in range(reweight_iterations):
        matrix = csr_matrix(components["matrices"][0].shape)
        right = np.zeros_like(flux)
        for component in range(3):
            if not active[component]:
                continue
            factor = scales[component] / max(weights[component], 1.0e-14)
            matrix = matrix + factor * components["matrices"][component]
            right += factor * components["linear"][component]
        flux = np.asarray(spsolve(matrix.tocsr(), right))
        squared = np.array(
            [
                scales[index]
                * quadratic_value(
                    components["matrices"][index],
                    components["linear"][index],
                    float(components["constants"][index]),
                    flux,
                )
                for index in range(3)
            ]
        )
        norms = np.sqrt(np.maximum(squared, 0.0))
        total = float(np.sum(norms[active]))
        next_weights = np.zeros(3, dtype=float)
        if total > 0.0:
            next_weights[active] = np.maximum(norms[active] / total, 1.0e-10)
            next_weights[active] /= np.sum(next_weights[active])
        else:
            next_weights[active] = 1.0 / int(np.sum(active))
        history.append(
            {"iteration": iteration, "component_norms": norms.tolist(),
             "quadratic_majorant": total}
        )
        weights = next_weights
    record = flux_record(
        components, flux,
        "IRLS minimizer of the complete quadratic RT0 functional majorant",
    )
    record["optimization_history"] = history
    record["optimization_component_weights"] = weights.tolist()
    record["max_abs_algebraic_balance_defect"] = float(
        np.max(
            np.abs(
                triangle_forcing_moments(mesh, 1.0, 1) * 0.0
                + np.asarray(components["incidence"] @ flux)
            )
        )
    )
    record["local_integral_equilibrium_passed"] = False
    return record


def run_case(
    n: int,
    shear: float,
    stretch: float,
    contrast: float,
    boundary_mode: str,
    depth: int,
    quadrature_order: int,
) -> list[dict[str, Any]]:
    mesh = build_mesh(n, shear, stretch)
    matrix, load = assemble_problem(mesh, boundary_mode, contrast)
    fixed = is_dirichlet_node(mesh, boundary_mode)
    fe = solve_problem(matrix, load, fixed)
    xi, eta = mesh.reference_nodes[:, 0], mesh.reference_nodes[:, 1]
    prediction = fe + 0.04 * np.sin(2.0 * math.pi * xi) * np.sin(math.pi * eta)
    prediction[fixed] = 0.0
    error = energy_error_diagnostic(mesh, prediction, contrast)
    components = quadratic_components(
        mesh, prediction, boundary_mode, contrast, quadrature_order
    )
    methods: list[tuple[str, Any, float]] = []
    start = time.perf_counter()
    legacy = equilibrate_rt0_flux(mesh, prediction, boundary_mode, contrast)
    methods.append(("legacy_edge_projection", legacy, time.perf_counter() - start))
    start = time.perf_counter()
    weighted = weighted_equilibrated_flux(
        mesh, boundary_mode, contrast, components
    )
    methods.append(("energy_weighted_equilibrated", weighted, time.perf_counter() - start))
    start = time.perf_counter()
    optimized = majorant_optimized_flux(mesh, boundary_mode, components)
    methods.append(("complete_majorant_irls", optimized, time.perf_counter() - start))
    rows = []
    forcing_moments = triangle_forcing_moments(mesh, contrast, 16)
    for method, flux, optimization_seconds in methods:
        lipschitz_certificate = equilibrated_functional_upper_sum(
            mesh, boundary_mode, contrast, depth, flux
        )
        certificate = taylor_functional_upper_sum(
            mesh, boundary_mode, contrast, depth, flux
        )
        local_defect = forcing_moments + np.sum(
            np.asarray(flux["local_outward_integrals"]), axis=1
        )
        rows.append(
            {
                "case_id": f"n{n}_{boundary_mode}_s{shear:g}_t{stretch:g}_c{contrast:g}",
                "method": method,
                "n": n,
                "boundary_mode": boundary_mode,
                "shear": shear,
                "stretch": stretch,
                "contrast": contrast,
                "energy_error": error,
                "majorant": certificate["functional_majorant"],
                "legacy_lipschitz_majorant": lipschitz_certificate["functional_majorant"],
                "legacy_lipschitz_effectivity": lipschitz_certificate["functional_majorant"] / max(error, 1.0e-30),
                "effectivity": certificate["functional_majorant"] / max(error, 1.0e-30),
                "coverage": bool(certificate["functional_majorant"] + 1.0e-10 >= error),
                "flux_mismatch_upper": certificate["flux_mismatch_upper"],
                "equilibrium_residual_upper": certificate["equilibrium_residual_upper"],
                "neumann_residual_upper": certificate["neumann_residual_upper"],
                "hdiv_conformity": True,
                "max_abs_integral_balance_defect": float(np.max(np.abs(local_defect))),
                "optimization_seconds": optimization_seconds,
                "strict_evaluation_depth": depth,
            }
        )
    return rows


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def method_summary(rows: list[dict[str, Any]], method: str) -> dict[str, Any]:
    group = [row for row in rows if row["method"] == method]
    values = [float(row["effectivity"]) for row in group]
    return {
        "cases": len(group),
        "coverage_rate": statistics.fmean(float(row["coverage"]) for row in group),
        "effectivity_mean": statistics.fmean(values),
        "effectivity_median": statistics.median(values),
        "effectivity_min": min(values),
        "effectivity_max": max(values),
        "optimization_seconds_median": statistics.median(
            float(row["optimization_seconds"]) for row in group
        ),
        "integral_balance_defect_max": max(
            float(row["max_abs_integral_balance_defect"]) for row in group
        ),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--quick", action="store_true")
    parser.add_argument("--levels", nargs="+", type=int)
    parser.add_argument("--depth", type=int, default=2)
    parser.add_argument("--quadrature-order", type=int, default=8)
    parser.add_argument(
        "--summary-out", type=Path,
        default=Path("experiments/results/sidebranch_optimized_rt0_summary.json"),
    )
    parser.add_argument(
        "--rows-out", type=Path,
        default=Path("experiments/results/sidebranch_optimized_rt0_rows.csv"),
    )
    args = parser.parse_args()
    levels = args.levels or ([8] if args.quick else [8, 16, 32])
    geometries = [(0.35, 0.8)] if args.quick else [(0.35, 0.8), (0.6, 1.4), (0.85, 0.3)]
    contrasts = [10.0] if args.quick else [1.0, 10.0, 100.0]
    modes = ["dirichlet", "mixed"]
    rows: list[dict[str, Any]] = []
    for mode in modes:
        for shear, stretch in geometries:
            for contrast in contrasts:
                for n in levels:
                    case_rows = run_case(
                        n, shear, stretch, contrast, mode,
                        args.depth, args.quadrature_order,
                    )
                    rows.extend(case_rows)
                    print(
                        case_rows[0]["case_id"],
                        " ".join(
                            f"{row['method']}={row['effectivity']:.3f}"
                            for row in case_rows
                        ),
                    )
    methods = ["legacy_edge_projection", "energy_weighted_equilibrated", "complete_majorant_irls"]
    summaries = {method: method_summary(rows, method) for method in methods}
    failures = [row for row in rows if not row["coverage"] or not row["hdiv_conformity"]]
    report = {
        "benchmark": "sidebranch_optimized_rt0_functional_majorant",
        "scope": {
            "pde_family": "existing affine scalar Dirichlet/mixed family only",
            "optimization_quadrature": "used only to choose the RT0 flux",
            "strict_evaluation": "independent upper-sum functional majorant; no truth calibration",
            "floating_scope": "fully specified floating majorant, not machine-rigorous arithmetic",
        },
        "config": {
            "levels": levels,
            "geometries": geometries,
            "contrasts": contrasts,
            "boundary_modes": modes,
            "strict_evaluation_depth": args.depth,
            "optimization_quadrature_order": args.quadrature_order,
        },
        "methods": summaries,
        "coverage_failures": failures,
        "rows": rows,
    }
    args.summary_out.parent.mkdir(parents=True, exist_ok=True)
    args.summary_out.write_text(json.dumps(report, indent=2, sort_keys=True), encoding="utf-8")
    write_csv(args.rows_out, rows)
    if failures:
        raise AssertionError(f"optimized RT0 coverage failed in {len(failures)} rows")


if __name__ == "__main__":
    main()
