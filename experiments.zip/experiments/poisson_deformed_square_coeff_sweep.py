"""Coefficient-and-geometry parameter sweep for the deformed-square benchmark.

This script extends `poisson_deformed_square_sweep.py` by adding a positive
smooth coefficient parameter

    a_mu(xi, eta) = exp(mu sin(pi xi) sin(pi eta)).

The pulled-back operator on the reference square is

    -div_xi(a_mu B_theta grad_xi u_hat) = f_hat,

with manufactured solution `sin(pi xi) sin(pi eta)`.  The goal is to exercise
the certifier on a genuine parametric PDE family, not only on variable
geometries.  The finite-difference strong residuals below are numerical
diagnostics for the benchmark; the paper proof remains analytic.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import statistics
import sys
from itertools import product
from pathlib import Path
from typing import Any, Callable

import numpy as np
from scipy.sparse import coo_matrix

sys.dont_write_bytecode = True
SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from poisson_deformed_square_pullback_p1 import (
    RefMesh,
    basis_gradients,
    build_edges,
    coefficient_b,
    discrete_residual_norm,
    dunavant_degree5,
    edge_gauss_2,
    exact_grad,
    exact_value,
    jacobian_min_on_grid,
    make_mesh,
    outward_normal,
    perturbation,
    solve_dirichlet,
    triangle_area,
    triangle_gradients,
)


LABELS = ("fe", "interp", "perturbed")


def scalar_coefficient(point: np.ndarray, mu: float) -> float:
    xi, eta = point
    shape = math.sin(math.pi * xi) * math.sin(math.pi * eta)
    return math.exp(mu * shape)


def coefficient_b_mu(
    point: np.ndarray, theta1: float, theta2: float, mu: float
) -> np.ndarray:
    return scalar_coefficient(point, mu) * coefficient_b(point, theta1, theta2)


def exact_flux_mu(point: np.ndarray, theta1: float, theta2: float, mu: float) -> np.ndarray:
    return coefficient_b_mu(point, theta1, theta2, mu) @ exact_grad(point)


def finite_difference_divergence_field(
    vector_field: Callable[[np.ndarray], np.ndarray],
    point: np.ndarray,
    eps: float = 1.0e-6,
) -> float:
    point = np.asarray(point, dtype=float)
    div = 0.0
    for i in range(2):
        p_plus = point.copy()
        p_minus = point.copy()
        p_plus[i] += eps
        p_minus[i] -= eps
        div += (vector_field(p_plus)[i] - vector_field(p_minus)[i]) / (2.0 * eps)
    return float(div)


def forcing_hat_mu(point: np.ndarray, theta1: float, theta2: float, mu: float) -> float:
    return -finite_difference_divergence_field(
        lambda x: exact_flux_mu(x, theta1, theta2, mu), point
    )


def div_b_mu_grad_constant(
    point: np.ndarray, grad: np.ndarray, theta1: float, theta2: float, mu: float
) -> float:
    return finite_difference_divergence_field(
        lambda x: coefficient_b_mu(x, theta1, theta2, mu) @ grad, point
    )


def assemble(mesh: RefMesh, mu: float) -> tuple[Any, np.ndarray]:
    rows: list[int] = []
    cols: list[int] = []
    data: list[float] = []
    rhs = np.zeros(len(mesh.nodes))
    quad = dunavant_degree5()
    for tri in mesh.triangles:
        coords = mesh.nodes[tri]
        area = triangle_area(coords)
        grads = basis_gradients(coords)
        local_k = np.zeros((3, 3), dtype=float)
        local_b = np.zeros(3, dtype=float)
        for weight, bary in quad:
            lam = np.array(bary)
            q = lam @ coords
            bmat = coefficient_b_mu(q, mesh.theta1, mesh.theta2, mu)
            f_q = forcing_hat_mu(q, mesh.theta1, mesh.theta2, mu)
            for a in range(3):
                local_b[a] += weight * area * f_q * lam[a]
                for b in range(3):
                    local_k[a, b] += weight * area * float(
                        grads[a] @ bmat @ grads[b]
                    )
        for a in range(3):
            rhs[tri[a]] += local_b[a]
            for b in range(3):
                rows.append(int(tri[a]))
                cols.append(int(tri[b]))
                data.append(float(local_k[a, b]))
    stiffness = coo_matrix(
        (data, (rows, cols)), shape=(len(mesh.nodes), len(mesh.nodes))
    )
    return stiffness.tocsr(), rhs


def nodal_exact(mesh: RefMesh) -> np.ndarray:
    return np.array([exact_value(x) for x in mesh.nodes], dtype=float)


def residual_estimator(
    mesh: RefMesh, values: np.ndarray, mu: float
) -> tuple[float, float, float]:
    grads = triangle_gradients(mesh, values)
    quad = dunavant_degree5()
    volume = 0.0
    for tri_idx, tri in enumerate(mesh.triangles):
        coords = mesh.nodes[tri]
        area = triangle_area(coords)
        edge_lengths = [
            np.linalg.norm(coords[1] - coords[0]),
            np.linalg.norm(coords[2] - coords[1]),
            np.linalg.norm(coords[0] - coords[2]),
        ]
        h_k = max(edge_lengths)
        int_r2 = 0.0
        grad_uh = grads[tri_idx]
        for weight, bary in quad:
            q = np.array(bary) @ coords
            residual = forcing_hat_mu(q, mesh.theta1, mesh.theta2, mu) + div_b_mu_grad_constant(
                q, grad_uh, mesh.theta1, mesh.theta2, mu
            )
            int_r2 += weight * area * residual**2
        volume += h_k**2 * int_r2

    jump = 0.0
    for edge, adj in build_edges(mesh.triangles).items():
        if len(adj) != 2:
            continue
        n0 = outward_normal(mesh, adj[0], edge)
        n1 = outward_normal(mesh, adj[1], edge)
        pa = mesh.nodes[edge[0]]
        pb = mesh.nodes[edge[1]]
        edge_length = float(np.linalg.norm(pb - pa))
        int_jump2 = 0.0
        for weight, t in edge_gauss_2():
            q = (1.0 - t) * pa + t * pb
            flux0 = coefficient_b_mu(q, mesh.theta1, mesh.theta2, mu) @ grads[adj[0]]
            flux1 = coefficient_b_mu(q, mesh.theta1, mesh.theta2, mu) @ grads[adj[1]]
            flux_jump = float(np.dot(flux0, n0) + np.dot(flux1, n1))
            int_jump2 += weight * edge_length * flux_jump**2
        jump += edge_length * int_jump2
    return math.sqrt(volume + jump), math.sqrt(volume), math.sqrt(jump)


def energy_error(mesh: RefMesh, values: np.ndarray, mu: float) -> float:
    uh_grads = triangle_gradients(mesh, values)
    quad = dunavant_degree5()
    err2 = 0.0
    for tri_idx, tri in enumerate(mesh.triangles):
        coords = mesh.nodes[tri]
        area = triangle_area(coords)
        for weight, bary in quad:
            q = np.array(bary) @ coords
            diff = exact_grad(q) - uh_grads[tri_idx]
            err2 += weight * area * float(
                diff @ coefficient_b_mu(q, mesh.theta1, mesh.theta2, mu) @ diff
            )
    return math.sqrt(err2)


def run_case(
    n: int, theta1: float, theta2: float, mu: float, perturb: float
) -> dict[str, float]:
    mesh = make_mesh(n, theta1, theta2)
    stiffness, rhs = assemble(mesh, mu)
    fe = solve_dirichlet(stiffness, rhs, mesh.boundary)
    interp = nodal_exact(mesh)
    perturbed = fe + perturbation(mesh, perturb)

    row: dict[str, float] = {
        "n": float(n),
        "dofs": float(len(mesh.nodes)),
        "theta1": theta1,
        "theta2": theta2,
        "mu": mu,
        "perturb": perturb,
        "jacobian_min_grid": jacobian_min_on_grid(theta1, theta2),
        "scalar_coeff_min": math.exp(min(0.0, mu)),
        "scalar_coeff_max": math.exp(max(0.0, mu)),
    }
    for label, values in (("fe", fe), ("interp", interp), ("perturbed", perturbed)):
        eta_res, eta_volume, eta_jump = residual_estimator(mesh, values, mu)
        delta = discrete_residual_norm(stiffness, rhs, values, mesh.boundary)
        eta_total = math.sqrt(eta_res**2 + delta**2)
        err = energy_error(mesh, values, mu)
        row[f"{label}_energy_error"] = err
        row[f"{label}_eta_res"] = eta_res
        row[f"{label}_eta_volume"] = eta_volume
        row[f"{label}_eta_jump"] = eta_jump
        row[f"{label}_delta_h"] = delta
        row[f"{label}_eta_total"] = eta_total
        row[f"{label}_effectivity_res"] = eta_res / err if err > 0.0 else float("inf")
        row[f"{label}_effectivity_total"] = eta_total / err if err > 0.0 else float("inf")
    return row


def finite_max(values: list[float]) -> float:
    if any(math.isinf(v) for v in values):
        return float("inf")
    return max(values)


def summarize(rows: list[dict[str, float]]) -> dict[str, Any]:
    summary: dict[str, Any] = {
        "num_cases": len(rows),
        "jacobian_min_observed": min(row["jacobian_min_grid"] for row in rows),
        "scalar_coeff_min_observed": min(row["scalar_coeff_min"] for row in rows),
        "scalar_coeff_max_observed": max(row["scalar_coeff_max"] for row in rows),
        "mu_min": min(row["mu"] for row in rows),
        "mu_max": max(row["mu"] for row in rows),
    }
    for label in LABELS:
        effectivities = [row[f"{label}_effectivity_total"] for row in rows]
        errors = [row[f"{label}_energy_error"] for row in rows]
        etas = [row[f"{label}_eta_total"] for row in rows]
        deltas = [row[f"{label}_delta_h"] for row in rows]
        raw_covers = [eta >= err for eta, err in zip(etas, errors)]
        safety_factors = [
            err / eta if eta > 0.0 else float("inf")
            for eta, err in zip(etas, errors)
        ]
        summary[label] = {
            "raw_coverage_rate": sum(raw_covers) / len(raw_covers),
            "max_raw_underestimate": max(
                max(0.0, err - eta) for eta, err in zip(etas, errors)
            ),
            "empirical_safety_factor_needed": finite_max(safety_factors),
            "effectivity_min": min(effectivities),
            "effectivity_mean": statistics.fmean(effectivities),
            "effectivity_median": statistics.median(effectivities),
            "effectivity_max": max(effectivities),
            "energy_error_mean": statistics.fmean(errors),
            "eta_total_mean": statistics.fmean(etas),
            "delta_h_mean": statistics.fmean(deltas),
            "delta_h_max": max(deltas),
        }
    return summary


def write_csv(path: Path, rows: list[dict[str, float]]) -> None:
    if not rows:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = sorted(rows[0].keys())
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--levels", nargs="+", type=int, default=[16])
    parser.add_argument(
        "--theta1-values", nargs="+", type=float, default=[-0.08, 0.0, 0.08]
    )
    parser.add_argument(
        "--theta2-values", nargs="+", type=float, default=[-0.06, 0.0, 0.06]
    )
    parser.add_argument("--mu-values", nargs="+", type=float, default=[0.0, 0.5, 1.0])
    parser.add_argument("--perturbs", nargs="+", type=float, default=[0.03])
    parser.add_argument("--min-jacobian", type=float, default=0.2)
    parser.add_argument(
        "--out",
        type=Path,
        default=Path(
            "certified_geometry_neural_operators/experiments/results/"
            "poisson_deformed_square_coeff_sweep_summary.json"
        ),
    )
    parser.add_argument(
        "--csv-out",
        type=Path,
        default=Path(
            "certified_geometry_neural_operators/experiments/results/"
            "poisson_deformed_square_coeff_sweep_rows.csv"
        ),
    )
    args = parser.parse_args()

    rows: list[dict[str, float]] = []
    skipped: list[dict[str, float]] = []
    case_id = 0
    for n, theta1, theta2, mu, perturb in product(
        args.levels,
        args.theta1_values,
        args.theta2_values,
        args.mu_values,
        args.perturbs,
    ):
        jac_min = jacobian_min_on_grid(theta1, theta2)
        if jac_min <= args.min_jacobian:
            skipped.append(
                {
                    "n": float(n),
                    "theta1": theta1,
                    "theta2": theta2,
                    "mu": mu,
                    "perturb": perturb,
                    "jacobian_min_grid": jac_min,
                }
            )
            continue
        row = run_case(n=n, theta1=theta1, theta2=theta2, mu=mu, perturb=perturb)
        row["case_id"] = float(case_id)
        rows.append(row)
        case_id += 1

    if not rows:
        raise SystemExit(
            "No admissible cases; lower --min-jacobian or change parameter pool."
        )

    result: dict[str, Any] = {
        "config": {
            "levels": args.levels,
            "theta1_values": args.theta1_values,
            "theta2_values": args.theta2_values,
            "mu_values": args.mu_values,
            "perturbs": args.perturbs,
            "min_jacobian": args.min_jacobian,
        },
        "summary": summarize(rows),
        "rows": rows,
        "skipped": skipped,
    }

    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, indent=2, sort_keys=True), encoding="utf-8")
    write_csv(args.csv_out, rows)

    print(f"admissible_cases {len(rows)}")
    print(f"skipped_cases {len(skipped)}")
    print(f"jacobian_min_observed {result['summary']['jacobian_min_observed']:.8e}")
    print(
        "scalar_coeff_range",
        f"[{result['summary']['scalar_coeff_min_observed']:.3e},",
        f"{result['summary']['scalar_coeff_max_observed']:.3e}]",
    )
    for label in LABELS:
        stats = result["summary"][label]
        print(
            label,
            f"coverage={stats['raw_coverage_rate']:.3f}",
            f"effectivity=[{stats['effectivity_min']:.3f},"
            f"{stats['effectivity_mean']:.3f},{stats['effectivity_max']:.3f}]",
            f"delta_h_max={stats['delta_h_max']:.3e}",
            f"safety_needed={stats['empirical_safety_factor_needed']:.3f}",
        )
    print(f"wrote {args.out}")
    print(f"wrote {args.csv_out}")


if __name__ == "__main__":
    main()
