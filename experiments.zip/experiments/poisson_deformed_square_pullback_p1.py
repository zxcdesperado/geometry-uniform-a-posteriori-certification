"""Reference-domain P1 benchmark on a nonlinear deformed square.

This script is the next step after `poisson_affine_geometry_p1.py`.  It works
directly on the reference square and solves the pulled-back problem

    -div_xi(B_theta grad_xi u_hat) = f_hat,  u_hat = 0 on boundary,

where `B_theta = J F^{-1} F^{-T}` comes from the nonlinear diffeomorphism

    T_theta(xi, eta)
      = (xi + theta_1 sin(pi xi) sin(pi eta),
         eta + theta_2 sin(pi xi) sin(pi eta)).

The exact reference solution is `sin(pi xi) sin(pi eta)`.  The forcing and
strong residual use finite-difference derivatives of the smooth coefficient
matrix; this is numerical support for the paper, not a mechanical proof.
"""

from __future__ import annotations

import argparse
import json
import math
from dataclasses import dataclass
from pathlib import Path

import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import spsolve


@dataclass(frozen=True)
class RefMesh:
    nodes: np.ndarray
    triangles: np.ndarray
    boundary: np.ndarray
    theta1: float
    theta2: float


def dunavant_degree5() -> list[tuple[float, tuple[float, float, float]]]:
    a1 = 0.059715871789770
    b1 = 0.470142064105115
    a2 = 0.797426985353087
    b2 = 0.101286507323456
    w0 = 0.225000000000000
    w1 = 0.132394152788506
    w2 = 0.125939180544827
    return [
        (w0, (1.0 / 3.0, 1.0 / 3.0, 1.0 / 3.0)),
        (w1, (a1, b1, b1)),
        (w1, (b1, a1, b1)),
        (w1, (b1, b1, a1)),
        (w2, (a2, b2, b2)),
        (w2, (b2, a2, b2)),
        (w2, (b2, b2, a2)),
    ]


def edge_gauss_2() -> list[tuple[float, float]]:
    r = 1.0 / math.sqrt(3.0)
    return [(0.5, 0.5 * (1.0 - r)), (0.5, 0.5 * (1.0 + r))]


def make_mesh(n: int, theta1: float, theta2: float) -> RefMesh:
    xs = np.linspace(0.0, 1.0, n + 1)
    nodes = np.array([(x, y) for y in xs for x in xs], dtype=float)
    triangles: list[tuple[int, int, int]] = []
    for j in range(n):
        for i in range(n):
            v00 = j * (n + 1) + i
            v10 = v00 + 1
            v01 = (j + 1) * (n + 1) + i
            v11 = v01 + 1
            triangles.append((v00, v10, v11))
            triangles.append((v00, v11, v01))
    boundary = (
        (np.isclose(nodes[:, 0], 0.0))
        | (np.isclose(nodes[:, 0], 1.0))
        | (np.isclose(nodes[:, 1], 0.0))
        | (np.isclose(nodes[:, 1], 1.0))
    )
    return RefMesh(nodes, np.array(triangles, dtype=int), boundary, theta1, theta2)


def triangle_area(coords: np.ndarray) -> float:
    mat = np.column_stack([coords[1] - coords[0], coords[2] - coords[0]])
    return 0.5 * abs(float(np.linalg.det(mat)))


def basis_gradients(coords: np.ndarray) -> np.ndarray:
    x = coords[:, 0]
    y = coords[:, 1]
    area2 = (x[1] - x[0]) * (y[2] - y[0]) - (x[2] - x[0]) * (y[1] - y[0])
    grads = np.array(
        [
            [y[1] - y[2], x[2] - x[1]],
            [y[2] - y[0], x[0] - x[2]],
            [y[0] - y[1], x[1] - x[0]],
        ],
        dtype=float,
    )
    return grads / area2


def jacobian_matrix(point: np.ndarray, theta1: float, theta2: float) -> np.ndarray:
    xi, eta = point
    sx = math.sin(math.pi * xi)
    sy = math.sin(math.pi * eta)
    cx = math.cos(math.pi * xi)
    cy = math.cos(math.pi * eta)
    common_x = math.pi * cx * sy
    common_y = math.pi * sx * cy
    return np.array(
        [
            [1.0 + theta1 * common_x, theta1 * common_y],
            [theta2 * common_x, 1.0 + theta2 * common_y],
        ],
        dtype=float,
    )


def coefficient_b(point: np.ndarray, theta1: float, theta2: float) -> np.ndarray:
    f = jacobian_matrix(point, theta1, theta2)
    det = float(np.linalg.det(f))
    if det <= 0.0:
        raise ValueError(f"nonpositive Jacobian {det} at {point}")
    finv = np.linalg.inv(f)
    return det * (finv @ finv.T)


def exact_value(point: np.ndarray) -> float:
    xi, eta = point
    return math.sin(math.pi * xi) * math.sin(math.pi * eta)


def exact_grad(point: np.ndarray) -> np.ndarray:
    xi, eta = point
    return np.array(
        [
            math.pi * math.cos(math.pi * xi) * math.sin(math.pi * eta),
            math.pi * math.sin(math.pi * xi) * math.cos(math.pi * eta),
        ],
        dtype=float,
    )


def exact_flux(point: np.ndarray, theta1: float, theta2: float) -> np.ndarray:
    return coefficient_b(point, theta1, theta2) @ exact_grad(point)


def finite_difference_divergence(
    vector_field, point: np.ndarray, theta1: float, theta2: float, eps: float = 1.0e-6
) -> float:
    point = np.asarray(point, dtype=float)
    div = 0.0
    for i in range(2):
        p_plus = point.copy()
        p_minus = point.copy()
        p_plus[i] += eps
        p_minus[i] -= eps
        div += (vector_field(p_plus, theta1, theta2)[i] - vector_field(p_minus, theta1, theta2)[i]) / (
            2.0 * eps
        )
    return float(div)


def forcing_hat(point: np.ndarray, theta1: float, theta2: float) -> float:
    return -finite_difference_divergence(exact_flux, point, theta1, theta2)


def flux_for_constant_grad(grad: np.ndarray):
    def field(point: np.ndarray, theta1: float, theta2: float) -> np.ndarray:
        return coefficient_b(point, theta1, theta2) @ grad

    return field


def div_b_grad_constant(point: np.ndarray, grad: np.ndarray, theta1: float, theta2: float) -> float:
    return finite_difference_divergence(flux_for_constant_grad(grad), point, theta1, theta2)


def assemble(mesh: RefMesh) -> tuple[coo_matrix, np.ndarray]:
    rows: list[int] = []
    cols: list[int] = []
    data: list[float] = []
    rhs = np.zeros(len(mesh.nodes))
    quad = dunavant_degree5()
    for tri in mesh.triangles:
        coords = mesh.nodes[tri]
        area = triangle_area(coords)
        grads = basis_gradients(coords)
        local_k = np.zeros((3, 3), dtype=float)
        local_b = np.zeros(3, dtype=float)
        for weight, bary in quad:
            lam = np.array(bary)
            q = lam @ coords
            bmat = coefficient_b(q, mesh.theta1, mesh.theta2)
            f_q = forcing_hat(q, mesh.theta1, mesh.theta2)
            for a in range(3):
                local_b[a] += weight * area * f_q * lam[a]
                for b in range(3):
                    local_k[a, b] += weight * area * float(grads[a] @ bmat @ grads[b])
        for a in range(3):
            rhs[tri[a]] += local_b[a]
            for b in range(3):
                rows.append(int(tri[a]))
                cols.append(int(tri[b]))
                data.append(float(local_k[a, b]))
    stiffness = coo_matrix((data, (rows, cols)), shape=(len(mesh.nodes), len(mesh.nodes)))
    return stiffness.tocsr(), rhs


def solve_dirichlet(stiffness, rhs: np.ndarray, boundary: np.ndarray) -> np.ndarray:
    free = np.flatnonzero(~boundary)
    u = np.zeros_like(rhs)
    u[free] = spsolve(stiffness[free][:, free], rhs[free])
    return u


def nodal_exact(mesh: RefMesh) -> np.ndarray:
    return np.array([exact_value(x) for x in mesh.nodes], dtype=float)


def perturbation(mesh: RefMesh, amplitude: float) -> np.ndarray:
    xi = mesh.nodes[:, 0]
    eta = mesh.nodes[:, 1]
    values = amplitude * np.sin(2.0 * math.pi * xi) * np.sin(math.pi * eta)
    values[mesh.boundary] = 0.0
    return values


def triangle_gradients(mesh: RefMesh, values: np.ndarray) -> np.ndarray:
    grads = []
    for tri in mesh.triangles:
        local_grads = basis_gradients(mesh.nodes[tri])
        grads.append(values[tri] @ local_grads)
    return np.array(grads)


def build_edges(triangles: np.ndarray) -> dict[tuple[int, int], list[int]]:
    edges: dict[tuple[int, int], list[int]] = {}
    for t_idx, tri in enumerate(triangles):
        for a, b in ((tri[0], tri[1]), (tri[1], tri[2]), (tri[2], tri[0])):
            key = tuple(sorted((int(a), int(b))))
            edges.setdefault(key, []).append(t_idx)
    return edges


def outward_normal(mesh: RefMesh, tri_idx: int, edge: tuple[int, int]) -> np.ndarray:
    a, b = edge
    pa = mesh.nodes[a]
    pb = mesh.nodes[b]
    tangent = pb - pa
    normal = np.array([tangent[1], -tangent[0]], dtype=float)
    normal /= np.linalg.norm(normal)
    tri = mesh.triangles[tri_idx]
    third = [v for v in tri if int(v) not in edge][0]
    midpoint = 0.5 * (pa + pb)
    if float(np.dot(normal, mesh.nodes[third] - midpoint)) > 0.0:
        normal *= -1.0
    return normal


def residual_estimator(mesh: RefMesh, values: np.ndarray) -> tuple[float, float, float]:
    grads = triangle_gradients(mesh, values)
    quad = dunavant_degree5()
    volume = 0.0
    for tri_idx, tri in enumerate(mesh.triangles):
        coords = mesh.nodes[tri]
        area = triangle_area(coords)
        edge_lengths = [
            np.linalg.norm(coords[1] - coords[0]),
            np.linalg.norm(coords[2] - coords[1]),
            np.linalg.norm(coords[0] - coords[2]),
        ]
        h_k = max(edge_lengths)
        int_r2 = 0.0
        grad_uh = grads[tri_idx]
        for weight, bary in quad:
            q = np.array(bary) @ coords
            residual = forcing_hat(q, mesh.theta1, mesh.theta2) + div_b_grad_constant(
                q, grad_uh, mesh.theta1, mesh.theta2
            )
            int_r2 += weight * area * residual**2
        volume += h_k**2 * int_r2

    jump = 0.0
    for edge, adj in build_edges(mesh.triangles).items():
        if len(adj) != 2:
            continue
        n0 = outward_normal(mesh, adj[0], edge)
        n1 = outward_normal(mesh, adj[1], edge)
        pa = mesh.nodes[edge[0]]
        pb = mesh.nodes[edge[1]]
        edge_length = float(np.linalg.norm(pb - pa))
        int_jump2 = 0.0
        for weight, t in edge_gauss_2():
            q = (1.0 - t) * pa + t * pb
            flux0 = coefficient_b(q, mesh.theta1, mesh.theta2) @ grads[adj[0]]
            flux1 = coefficient_b(q, mesh.theta1, mesh.theta2) @ grads[adj[1]]
            flux_jump = float(np.dot(flux0, n0) + np.dot(flux1, n1))
            int_jump2 += weight * edge_length * flux_jump**2
        jump += edge_length * int_jump2
    return math.sqrt(volume + jump), math.sqrt(volume), math.sqrt(jump)


def energy_error(mesh: RefMesh, values: np.ndarray) -> float:
    uh_grads = triangle_gradients(mesh, values)
    quad = dunavant_degree5()
    err2 = 0.0
    for tri_idx, tri in enumerate(mesh.triangles):
        coords = mesh.nodes[tri]
        area = triangle_area(coords)
        for weight, bary in quad:
            q = np.array(bary) @ coords
            diff = exact_grad(q) - uh_grads[tri_idx]
            err2 += weight * area * float(diff @ coefficient_b(q, mesh.theta1, mesh.theta2) @ diff)
    return math.sqrt(err2)


def discrete_residual_norm(stiffness, rhs: np.ndarray, values: np.ndarray, boundary: np.ndarray) -> float:
    free = np.flatnonzero(~boundary)
    residual = rhs - stiffness @ values
    r_free = residual[free]
    if len(free) == 0:
        return 0.0
    y = spsolve(stiffness[free][:, free], r_free)
    value = float(np.dot(r_free, y))
    return math.sqrt(max(value, 0.0))


def jacobian_min_on_grid(theta1: float, theta2: float, samples: int = 41) -> float:
    grid = np.linspace(0.0, 1.0, samples)
    vals = []
    for xi in grid:
        for eta in grid:
            vals.append(float(np.linalg.det(jacobian_matrix(np.array([xi, eta]), theta1, theta2))))
    return min(vals)


def run_case(n: int, theta1: float, theta2: float, perturb: float) -> dict[str, float]:
    mesh = make_mesh(n, theta1, theta2)
    stiffness, rhs = assemble(mesh)
    fe = solve_dirichlet(stiffness, rhs, mesh.boundary)
    interp = nodal_exact(mesh)
    perturbed = fe + perturbation(mesh, perturb)

    row: dict[str, float] = {
        "n": float(n),
        "dofs": float(len(mesh.nodes)),
        "jacobian_min_grid": jacobian_min_on_grid(theta1, theta2),
    }
    for label, values in (("fe", fe), ("interp", interp), ("perturbed", perturbed)):
        eta_res, eta_volume, eta_jump = residual_estimator(mesh, values)
        delta = discrete_residual_norm(stiffness, rhs, values, mesh.boundary)
        eta_total = math.sqrt(eta_res**2 + delta**2)
        err = energy_error(mesh, values)
        row[f"{label}_energy_error"] = err
        row[f"{label}_eta_res"] = eta_res
        row[f"{label}_eta_volume"] = eta_volume
        row[f"{label}_eta_jump"] = eta_jump
        row[f"{label}_delta_h"] = delta
        row[f"{label}_eta_total"] = eta_total
        row[f"{label}_effectivity_res"] = eta_res / err if err > 0.0 else float("inf")
        row[f"{label}_effectivity_total"] = eta_total / err if err > 0.0 else float("inf")
    return row


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--levels", nargs="+", type=int, default=[8, 16, 32])
    parser.add_argument("--theta1", type=float, default=0.08)
    parser.add_argument("--theta2", type=float, default=-0.06)
    parser.add_argument("--perturb", type=float, default=0.03)
    parser.add_argument(
        "--out",
        type=Path,
        default=Path(
            "certified_geometry_neural_operators/experiments/results/"
            "poisson_deformed_square_pullback_summary.json"
        ),
    )
    args = parser.parse_args()

    j_min = jacobian_min_on_grid(args.theta1, args.theta2)
    if j_min <= 0.05:
        raise SystemExit(f"Jacobian too small on sampling grid: {j_min}")

    results = [run_case(n, args.theta1, args.theta2, args.perturb) for n in args.levels]
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(results, indent=2, sort_keys=True), encoding="utf-8")

    headers = [
        "n",
        "jacobian_min_grid",
        "fe_energy_error",
        "fe_eta_total",
        "fe_effectivity_total",
        "perturbed_energy_error",
        "perturbed_eta_total",
        "perturbed_effectivity_total",
        "perturbed_delta_h",
    ]
    print(" ".join(f"{h:>24}" for h in headers))
    for row in results:
        print(" ".join(f"{row[h]:24.8e}" for h in headers))
    print(f"wrote {args.out}")


if __name__ == "__main__":
    main()
