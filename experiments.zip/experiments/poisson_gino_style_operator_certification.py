"""Certify a lightweight GINO-style geometry graph surrogate on the Poisson pool.

This diagnostic complements the MLP, DeepONet-style, and grid-FNO-style
operator baselines with a geometry-aware graph/message-passing surrogate.  The
model receives per-node reference coordinates, deformed coordinates, geometry
displacement, coefficient values, Jacobian determinant, and broadcast
parameters on the shared P1 mesh.  Local graph aggregation over the triangular
mesh predicts the nodal field, after which the same conforming boundary
projection and residual/jump/delta_h certifier are applied.

The script is intentionally named "GINO-style": it is a small reproducible
geometry-aware diagnostic, not a full industrial GINO benchmark.
"""

from __future__ import annotations

import argparse
import json
import math
import random
import statistics
import sys
from pathlib import Path
from typing import Any

import numpy as np
import torch

sys.dont_write_bytecode = True
SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from poisson_deformed_square_coeff_sweep import scalar_coefficient
from poisson_deformed_square_pullback_p1 import (
    RefMesh,
    discrete_residual_norm,
    jacobian_matrix,
    jacobian_min_on_grid,
)
from poisson_parametric_mlp_certification import (
    PARAM_NAMES,
    energy_error,
    make_cases,
    residual_estimator,
    score_error_correlation,
    solve_case,
    summarize_acquisition,
    write_csv,
)


class GraphBlock(torch.nn.Module):
    def __init__(self, width: int) -> None:
        super().__init__()
        self.self_layer = torch.nn.Linear(width, width)
        self.neighbor_layer = torch.nn.Linear(width, width)
        self.mix = torch.nn.Sequential(
            torch.nn.Linear(width, width),
            torch.nn.GELU(),
            torch.nn.Linear(width, width),
        )
        self.norm = torch.nn.LayerNorm(width)

    def forward(self, x: torch.Tensor, adjacency: torch.Tensor) -> torch.Tensor:
        neighbor = torch.einsum("ij,bjw->biw", adjacency, x)
        update = torch.nn.functional.gelu(self.self_layer(x) + self.neighbor_layer(neighbor))
        return self.norm(x + self.mix(update))


class GeometryGraphOperator(torch.nn.Module):
    def __init__(self, in_channels: int, width: int, layers: int) -> None:
        super().__init__()
        self.lift = torch.nn.Linear(in_channels, width)
        self.blocks = torch.nn.ModuleList([GraphBlock(width) for _ in range(layers)])
        self.project = torch.nn.Sequential(
            torch.nn.Linear(width, width),
            torch.nn.GELU(),
            torch.nn.Linear(width, 1),
        )

    def forward(self, features: torch.Tensor, adjacency: torch.Tensor) -> torch.Tensor:
        x = self.lift(features)
        for block in self.blocks:
            x = block(x, adjacency)
        return self.project(x).squeeze(-1)


def physical_coordinates(nodes: np.ndarray, theta1: float, theta2: float) -> np.ndarray:
    xi = nodes[:, 0]
    eta = nodes[:, 1]
    shape = np.sin(math.pi * xi) * np.sin(math.pi * eta)
    return np.column_stack([xi + theta1 * shape, eta + theta2 * shape])


def case_node_features(mesh: RefMesh, theta1: float, theta2: float, mu: float) -> np.ndarray:
    nodes = mesh.nodes
    x_phys = physical_coordinates(nodes, theta1, theta2)
    disp = x_phys - nodes
    coeff = np.array([scalar_coefficient(point, mu) for point in nodes], dtype=float)
    jac_det = np.array(
        [float(np.linalg.det(jacobian_matrix(point, theta1, theta2))) for point in nodes],
        dtype=float,
    )
    return np.column_stack(
        [
            nodes[:, 0],
            nodes[:, 1],
            x_phys[:, 0],
            x_phys[:, 1],
            disp[:, 0],
            disp[:, 1],
            coeff,
            jac_det,
            np.full(len(nodes), theta1),
            np.full(len(nodes), theta2),
            np.full(len(nodes), mu),
        ]
    ).astype(float)


def normalized_adjacency(mesh: RefMesh) -> np.ndarray:
    num_nodes = len(mesh.nodes)
    adj = np.eye(num_nodes, dtype=float)
    for tri in mesh.triangles:
        vertices = [int(v) for v in tri]
        for a, b in ((vertices[0], vertices[1]), (vertices[1], vertices[2]), (vertices[2], vertices[0])):
            adj[a, b] = 1.0
            adj[b, a] = 1.0
    degree = adj.sum(axis=1)
    inv_sqrt = 1.0 / np.sqrt(np.maximum(degree, 1.0))
    return (inv_sqrt[:, None] * adj * inv_sqrt[None, :]).astype(float)


def normalize_features(
    features: np.ndarray, mean: np.ndarray, scale: np.ndarray
) -> np.ndarray:
    if features.ndim == 2 and mean.ndim == 3:
        return (features - mean[0]) / scale[0]
    return (features - mean) / scale


def train_model(
    train_x: np.ndarray,
    train_y: np.ndarray,
    adjacency: np.ndarray,
    epochs: int,
    width: int,
    layers: int,
    lr: float,
    seed: int,
) -> tuple[GeometryGraphOperator, list[dict[str, float]]]:
    torch.manual_seed(seed)
    torch.set_num_threads(1)
    model = GeometryGraphOperator(train_x.shape[2], width, layers)
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    x = torch.tensor(train_x, dtype=torch.float32)
    y = torch.tensor(train_y, dtype=torch.float32)
    a = torch.tensor(adjacency, dtype=torch.float32)
    history: list[dict[str, float]] = []
    report_every = max(1, epochs // 10)
    for epoch in range(1, epochs + 1):
        opt.zero_grad(set_to_none=True)
        pred = model(x, a)
        loss = torch.mean((pred - y) ** 2)
        loss.backward()
        opt.step()
        if epoch == 1 or epoch == epochs or epoch % report_every == 0:
            history.append({"epoch": float(epoch), "mse": float(loss.detach().cpu())})
    return model, history


def predict_values(
    model: GeometryGraphOperator,
    features: np.ndarray,
    adjacency: np.ndarray,
    boundary: np.ndarray,
) -> np.ndarray:
    with torch.no_grad():
        x = torch.tensor(features[None, :, :], dtype=torch.float32)
        a = torch.tensor(adjacency, dtype=torch.float32)
        values = model(x, a)[0].cpu().numpy()
    values = np.asarray(values, dtype=float)
    values[boundary] = 0.0
    return values


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--level", type=int, default=10)
    parser.add_argument("--epochs", type=int, default=1000)
    parser.add_argument("--width", type=int, default=48)
    parser.add_argument("--layers", type=int, default=4)
    parser.add_argument("--lr", type=float, default=2.0e-3)
    parser.add_argument("--seed", type=int, default=62626)
    parser.add_argument("--random-repeats", type=int, default=200)
    parser.add_argument("--budgets", nargs="+", type=int, default=[4, 8, 12])
    parser.add_argument(
        "--out",
        type=Path,
        default=Path(
            "certified_geometry_neural_operators/experiments/results/"
            "poisson_gino_style_operator_certification_summary.json"
        ),
    )
    parser.add_argument(
        "--csv-out",
        type=Path,
        default=Path(
            "certified_geometry_neural_operators/experiments/results/"
            "poisson_gino_style_operator_certification_rows.csv"
        ),
    )
    args = parser.parse_args()

    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.set_num_threads(1)

    train_cases = make_cases([-0.12, 0.0, 0.12], [-0.09, 0.0, 0.09], [0.0, 0.5, 1.0])
    test_cases = make_cases(
        [-0.10, -0.033, 0.033, 0.10],
        [-0.075, -0.025, 0.025, 0.075],
        [0.125, 0.375, 0.625, 0.875],
    )

    train_features = []
    train_targets = []
    train_jac_mins = []
    mesh0: RefMesh | None = None
    for case in train_cases:
        mesh, _, _, values = solve_case(args.level, case)
        if mesh0 is None:
            mesh0 = mesh
        train_features.append(case_node_features(mesh, case.theta1, case.theta2, case.mu))
        train_targets.append(values)
        train_jac_mins.append(jacobian_min_on_grid(case.theta1, case.theta2))
    if mesh0 is None:
        raise RuntimeError("empty training set")

    raw_train_x = np.stack(train_features)
    feature_mean = raw_train_x.mean(axis=(0, 1), keepdims=True)
    feature_scale = raw_train_x.std(axis=(0, 1), keepdims=True)
    feature_scale[feature_scale == 0.0] = 1.0
    train_x = normalize_features(raw_train_x, feature_mean, feature_scale)
    train_y = np.stack(train_targets)
    adjacency = normalized_adjacency(mesh0)

    model, history = train_model(
        train_x=train_x,
        train_y=train_y,
        adjacency=adjacency,
        epochs=args.epochs,
        width=args.width,
        layers=args.layers,
        lr=args.lr,
        seed=args.seed,
    )

    rows: list[dict[str, float]] = []
    for case_id, case in enumerate(test_cases):
        mesh, stiffness, rhs, fe_values = solve_case(args.level, case)
        raw_features = case_node_features(mesh, case.theta1, case.theta2, case.mu)
        features = normalize_features(raw_features, feature_mean, feature_scale)
        pred = predict_values(model, features, adjacency, mesh.boundary)
        eta_res, eta_volume, eta_jump = residual_estimator(mesh, pred, case)
        delta = discrete_residual_norm(stiffness, rhs, pred, mesh.boundary)
        eta_total = math.sqrt(eta_res**2 + delta**2)
        err = energy_error(mesh, pred, case)
        fe_err = energy_error(mesh, fe_values, case)
        nodal_rel_l2 = float(
            np.linalg.norm(pred - fe_values) / max(np.linalg.norm(fe_values), 1.0e-14)
        )
        rows.append(
            {
                "case_id": float(case_id),
                "theta1": case.theta1,
                "theta2": case.theta2,
                "mu": case.mu,
                "jacobian_min_grid": jacobian_min_on_grid(case.theta1, case.theta2),
                "energy_error": err,
                "fe_energy_error": fe_err,
                "eta_res": eta_res,
                "eta_volume": eta_volume,
                "eta_jump": eta_jump,
                "delta_h": delta,
                "eta_total": eta_total,
                "effectivity_total": eta_total / err if err > 0.0 else float("inf"),
                "nodal_rel_l2_to_fe": nodal_rel_l2,
            }
        )

    coverage = [row["eta_total"] >= row["energy_error"] for row in rows]
    effectivities = [row["effectivity_total"] for row in rows]
    errors = [row["energy_error"] for row in rows]
    deltas = [row["delta_h"] for row in rows]
    acquisition = summarize_acquisition(rows, args.budgets, args.random_repeats, args.seed)

    result: dict[str, Any] = {
        "config": {
            "architecture": "lightweight_gino_style_graph",
            "level": args.level,
            "epochs": args.epochs,
            "width": args.width,
            "layers": args.layers,
            "lr": args.lr,
            "seed": args.seed,
            "input_channels": int(train_x.shape[2]),
            "param_names": list(PARAM_NAMES),
            "train_cases": len(train_cases),
            "test_cases": len(test_cases),
            "budgets": args.budgets,
            "random_repeats": args.random_repeats,
        },
        "training": {
            "history": history,
            "final_mse": history[-1]["mse"],
            "jacobian_min_train": min(train_jac_mins),
            "graph_nodes": int(adjacency.shape[0]),
            "graph_density": float(np.count_nonzero(adjacency) / adjacency.size),
        },
        "test_summary": {
            "num_cases": len(rows),
            "jacobian_min_test": min(row["jacobian_min_grid"] for row in rows),
            "raw_coverage_rate": sum(coverage) / len(coverage),
            "max_raw_underestimate": max(
                max(0.0, row["energy_error"] - row["eta_total"]) for row in rows
            ),
            "energy_error_mean": statistics.fmean(errors),
            "energy_error_max": max(errors),
            "delta_h_mean": statistics.fmean(deltas),
            "delta_h_max": max(deltas),
            "effectivity_min": min(effectivities),
            "effectivity_mean": statistics.fmean(effectivities),
            "effectivity_median": statistics.median(effectivities),
            "effectivity_max": max(effectivities),
            "score_error_correlation": score_error_correlation(rows),
        },
        "acquisition": acquisition,
        "rows": rows,
    }

    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, indent=2, sort_keys=True), encoding="utf-8")
    write_csv(args.csv_out, rows)

    summary = result["test_summary"]
    print(f"architecture {result['config']['architecture']}")
    print(f"train_cases {len(train_cases)}")
    print(f"test_cases {len(rows)}")
    print(f"final_train_mse {history[-1]['mse']:.6e}")
    print(f"coverage {summary['raw_coverage_rate']:.3f}")
    print(
        "effectivity",
        f"[{summary['effectivity_min']:.3f},"
        f"{summary['effectivity_mean']:.3f},{summary['effectivity_max']:.3f}]",
    )
    print(f"delta_h_max {summary['delta_h_max']:.6e}")
    corr = summary["score_error_correlation"]
    print("score_error_correlation", "None" if corr is None else f"{corr:.6f}")
    for row in acquisition:
        if row["strategy"] == "max_estimator":
            print(
                f"max_estimator budget={row['budget']} "
                f"selected_error_sq={row['selected_error_sq_fraction']:.3f} "
                f"worst_case_capture={row['worst_case_captured']}"
            )
    print(f"wrote {args.out}")
    print(f"wrote {args.csv_out}")


if __name__ == "__main__":
    main()
