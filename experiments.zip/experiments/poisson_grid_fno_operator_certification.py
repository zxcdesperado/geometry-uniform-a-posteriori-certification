"""Certify a lightweight grid-FNO-style surrogate on the Poisson PDE pool.

The MLP baseline sees only the parameter vector, and the DeepONet-style
baseline separates parameters and coordinates.  This script adds a more
FNO/Geo-FNO-like gate: the surrogate receives grid fields on the reference
mesh, including coordinates, geometry displacement, scalar coefficient,
Jacobian determinant, and broadcast parameters.  It outputs the whole P1 nodal
field, which is then certified by the same residual, flux-jump, and ``delta_h``
wrapper used elsewhere in the project.
"""

from __future__ import annotations

import argparse
import json
import math
import random
import statistics
import sys
from pathlib import Path
from typing import Any

import numpy as np
import torch

sys.dont_write_bytecode = True
SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from poisson_deformed_square_coeff_sweep import scalar_coefficient
from poisson_deformed_square_pullback_p1 import (
    discrete_residual_norm,
    jacobian_matrix,
    jacobian_min_on_grid,
)
from poisson_parametric_mlp_certification import (
    PARAM_NAMES,
    energy_error,
    make_cases,
    residual_estimator,
    score_error_correlation,
    solve_case,
    summarize_acquisition,
    write_csv,
)


class SpectralConv2d(torch.nn.Module):
    def __init__(self, in_channels: int, out_channels: int, modes: int) -> None:
        super().__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.modes = modes
        scale = 1.0 / max(1, in_channels * out_channels)
        self.weight_pos = torch.nn.Parameter(
            scale
            * torch.randn(in_channels, out_channels, modes, modes, dtype=torch.cfloat)
        )
        self.weight_neg = torch.nn.Parameter(
            scale
            * torch.randn(in_channels, out_channels, modes, modes, dtype=torch.cfloat)
        )

    def complex_mul(self, x: torch.Tensor, weights: torch.Tensor) -> torch.Tensor:
        return torch.einsum("bixy,ioxy->boxy", x, weights)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        batch_size, _, height, width = x.shape
        x_ft = torch.fft.rfft2(x)
        out_ft = torch.zeros(
            batch_size,
            self.out_channels,
            height,
            width // 2 + 1,
            dtype=torch.cfloat,
            device=x.device,
        )
        modes_h = min(self.modes, height)
        modes_w = min(self.modes, width // 2 + 1)
        out_ft[:, :, :modes_h, :modes_w] = self.complex_mul(
            x_ft[:, :, :modes_h, :modes_w],
            self.weight_pos[:, :, :modes_h, :modes_w],
        )
        out_ft[:, :, -modes_h:, :modes_w] = self.complex_mul(
            x_ft[:, :, -modes_h:, :modes_w],
            self.weight_neg[:, :, :modes_h, :modes_w],
        )
        return torch.fft.irfft2(out_ft, s=(height, width))


class FNOBlock(torch.nn.Module):
    def __init__(self, width: int, modes: int) -> None:
        super().__init__()
        self.spectral = SpectralConv2d(width, width, modes)
        self.pointwise = torch.nn.Conv2d(width, width, kernel_size=1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return torch.nn.functional.gelu(self.spectral(x) + self.pointwise(x))


class GridFNOSurrogate(torch.nn.Module):
    def __init__(
        self,
        in_channels: int,
        width: int,
        modes: int,
        layers: int,
    ) -> None:
        super().__init__()
        self.lift = torch.nn.Conv2d(in_channels, width, kernel_size=1)
        self.blocks = torch.nn.ModuleList([FNOBlock(width, modes) for _ in range(layers)])
        self.project = torch.nn.Sequential(
            torch.nn.Conv2d(width, 2 * width, kernel_size=1),
            torch.nn.GELU(),
            torch.nn.Conv2d(2 * width, 1, kernel_size=1),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        z = self.lift(x)
        for block in self.blocks:
            z = block(z)
        return self.project(z)


def case_feature_grid(nodes: np.ndarray, theta1: float, theta2: float, mu: float) -> np.ndarray:
    side = int(round(math.sqrt(len(nodes))))
    coords = nodes.reshape(side, side, 2)
    xi = coords[:, :, 0]
    eta = coords[:, :, 1]
    shape = np.sin(math.pi * xi) * np.sin(math.pi * eta)
    disp_x = theta1 * shape
    disp_y = theta2 * shape
    coeff = np.vectorize(lambda x, y: scalar_coefficient(np.array([x, y]), mu))(xi, eta)
    jac_det = np.zeros_like(xi)
    for i in range(side):
        for j in range(side):
            jac_det[i, j] = np.linalg.det(jacobian_matrix(coords[i, j], theta1, theta2))
    return np.stack(
        [
            xi,
            eta,
            disp_x,
            disp_y,
            coeff,
            jac_det,
            np.full_like(xi, theta1),
            np.full_like(xi, theta2),
            np.full_like(xi, mu),
        ],
        axis=0,
    ).astype(float)


def normalize_features(
    features: np.ndarray, mean: np.ndarray, scale: np.ndarray
) -> np.ndarray:
    if features.ndim == 3 and mean.ndim == 4:
        return (features - mean[0]) / scale[0]
    return (features - mean) / scale


def train_model(
    train_x: np.ndarray,
    train_y: np.ndarray,
    epochs: int,
    width: int,
    modes: int,
    layers: int,
    lr: float,
    seed: int,
) -> tuple[GridFNOSurrogate, list[dict[str, float]]]:
    torch.manual_seed(seed)
    torch.set_num_threads(1)
    model = GridFNOSurrogate(train_x.shape[1], width, modes, layers)
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    x = torch.tensor(train_x, dtype=torch.float32)
    y = torch.tensor(train_y, dtype=torch.float32)
    history: list[dict[str, float]] = []
    report_every = max(1, epochs // 10)
    for epoch in range(1, epochs + 1):
        opt.zero_grad(set_to_none=True)
        pred = model(x)
        loss = torch.mean((pred - y) ** 2)
        loss.backward()
        opt.step()
        if epoch == 1 or epoch == epochs or epoch % report_every == 0:
            history.append({"epoch": float(epoch), "mse": float(loss.detach().cpu())})
    return model, history


def predict_values(
    model: GridFNOSurrogate,
    features: np.ndarray,
    boundary: np.ndarray,
) -> np.ndarray:
    with torch.no_grad():
        grid = model(torch.tensor(features[None, :, :, :], dtype=torch.float32))
        values = grid[0, 0].cpu().numpy().reshape(-1)
    values = np.asarray(values, dtype=float)
    values[boundary] = 0.0
    return values


def values_to_grid(values: np.ndarray) -> np.ndarray:
    side = int(round(math.sqrt(len(values))))
    return values.reshape(1, side, side)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--level", type=int, default=10)
    parser.add_argument("--epochs", type=int, default=1000)
    parser.add_argument("--width", type=int, default=32)
    parser.add_argument("--modes", type=int, default=5)
    parser.add_argument("--layers", type=int, default=4)
    parser.add_argument("--lr", type=float, default=2.0e-3)
    parser.add_argument("--seed", type=int, default=51515)
    parser.add_argument("--random-repeats", type=int, default=200)
    parser.add_argument("--budgets", nargs="+", type=int, default=[4, 8, 12])
    parser.add_argument(
        "--out",
        type=Path,
        default=Path(
            "certified_geometry_neural_operators/experiments/results/"
            "poisson_grid_fno_operator_certification_summary.json"
        ),
    )
    parser.add_argument(
        "--csv-out",
        type=Path,
        default=Path(
            "certified_geometry_neural_operators/experiments/results/"
            "poisson_grid_fno_operator_certification_rows.csv"
        ),
    )
    args = parser.parse_args()

    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.set_num_threads(1)

    train_cases = make_cases([-0.12, 0.0, 0.12], [-0.09, 0.0, 0.09], [0.0, 0.5, 1.0])
    test_cases = make_cases(
        [-0.10, -0.033, 0.033, 0.10],
        [-0.075, -0.025, 0.025, 0.075],
        [0.125, 0.375, 0.625, 0.875],
    )

    train_features = []
    train_targets = []
    train_jac_mins = []
    for case in train_cases:
        mesh, _, _, values = solve_case(args.level, case)
        train_features.append(case_feature_grid(mesh.nodes, case.theta1, case.theta2, case.mu))
        train_targets.append(values_to_grid(values))
        train_jac_mins.append(jacobian_min_on_grid(case.theta1, case.theta2))
    raw_train_x = np.stack(train_features)
    feature_mean = raw_train_x.mean(axis=(0, 2, 3), keepdims=True)
    feature_scale = raw_train_x.std(axis=(0, 2, 3), keepdims=True)
    feature_scale[feature_scale == 0.0] = 1.0
    train_x = normalize_features(raw_train_x, feature_mean, feature_scale)
    train_y = np.stack(train_targets)

    model, history = train_model(
        train_x=train_x,
        train_y=train_y,
        epochs=args.epochs,
        width=args.width,
        modes=args.modes,
        layers=args.layers,
        lr=args.lr,
        seed=args.seed,
    )

    rows: list[dict[str, float]] = []
    for case_id, case in enumerate(test_cases):
        mesh, stiffness, rhs, fe_values = solve_case(args.level, case)
        raw_features = case_feature_grid(mesh.nodes, case.theta1, case.theta2, case.mu)
        features = normalize_features(raw_features, feature_mean, feature_scale)
        pred = predict_values(model, features, mesh.boundary)
        eta_res, eta_volume, eta_jump = residual_estimator(mesh, pred, case)
        delta = discrete_residual_norm(stiffness, rhs, pred, mesh.boundary)
        eta_total = math.sqrt(eta_res**2 + delta**2)
        err = energy_error(mesh, pred, case)
        fe_err = energy_error(mesh, fe_values, case)
        nodal_rel_l2 = float(
            np.linalg.norm(pred - fe_values) / max(np.linalg.norm(fe_values), 1.0e-14)
        )
        rows.append(
            {
                "case_id": float(case_id),
                "theta1": case.theta1,
                "theta2": case.theta2,
                "mu": case.mu,
                "jacobian_min_grid": jacobian_min_on_grid(case.theta1, case.theta2),
                "energy_error": err,
                "fe_energy_error": fe_err,
                "eta_res": eta_res,
                "eta_volume": eta_volume,
                "eta_jump": eta_jump,
                "delta_h": delta,
                "eta_total": eta_total,
                "effectivity_total": eta_total / err if err > 0.0 else float("inf"),
                "nodal_rel_l2_to_fe": nodal_rel_l2,
            }
        )

    coverage = [row["eta_total"] >= row["energy_error"] for row in rows]
    effectivities = [row["effectivity_total"] for row in rows]
    errors = [row["energy_error"] for row in rows]
    deltas = [row["delta_h"] for row in rows]
    acquisition = summarize_acquisition(rows, args.budgets, args.random_repeats, args.seed)

    result: dict[str, Any] = {
        "config": {
            "architecture": "lightweight_grid_fno",
            "level": args.level,
            "epochs": args.epochs,
            "width": args.width,
            "modes": args.modes,
            "layers": args.layers,
            "lr": args.lr,
            "seed": args.seed,
            "input_channels": int(train_x.shape[1]),
            "param_names": list(PARAM_NAMES),
            "train_cases": len(train_cases),
            "test_cases": len(test_cases),
            "budgets": args.budgets,
            "random_repeats": args.random_repeats,
        },
        "training": {
            "history": history,
            "final_mse": history[-1]["mse"],
            "jacobian_min_train": min(train_jac_mins),
        },
        "test_summary": {
            "num_cases": len(rows),
            "jacobian_min_test": min(row["jacobian_min_grid"] for row in rows),
            "raw_coverage_rate": sum(coverage) / len(coverage),
            "max_raw_underestimate": max(
                max(0.0, row["energy_error"] - row["eta_total"]) for row in rows
            ),
            "energy_error_mean": statistics.fmean(errors),
            "energy_error_max": max(errors),
            "delta_h_mean": statistics.fmean(deltas),
            "delta_h_max": max(deltas),
            "effectivity_min": min(effectivities),
            "effectivity_mean": statistics.fmean(effectivities),
            "effectivity_median": statistics.median(effectivities),
            "effectivity_max": max(effectivities),
            "score_error_correlation": score_error_correlation(rows),
        },
        "acquisition": acquisition,
        "rows": rows,
    }

    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, indent=2, sort_keys=True), encoding="utf-8")
    write_csv(args.csv_out, rows)

    summary = result["test_summary"]
    print(f"architecture {result['config']['architecture']}")
    print(f"train_cases {len(train_cases)}")
    print(f"test_cases {len(rows)}")
    print(f"final_train_mse {history[-1]['mse']:.6e}")
    print(f"coverage {summary['raw_coverage_rate']:.3f}")
    print(
        "effectivity",
        f"[{summary['effectivity_min']:.3f},"
        f"{summary['effectivity_mean']:.3f},{summary['effectivity_max']:.3f}]",
    )
    print(f"delta_h_max {summary['delta_h_max']:.6e}")
    corr = summary["score_error_correlation"]
    print("score_error_correlation", "None" if corr is None else f"{corr:.6f}")
    for row in acquisition:
        if row["strategy"] == "max_estimator":
            print(
                f"max_estimator budget={row['budget']} "
                f"selected_error_sq={row['selected_error_sq_fraction']:.3f} "
                f"worst_case_capture={row['worst_case_captured']}"
            )
    print(f"wrote {args.out}")
    print(f"wrote {args.csv_out}")


if __name__ == "__main__":
    main()
