"""Machine-rigorous scalar majorants on a polynomial curved 3D domain."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import sys
from fractions import Fraction
from pathlib import Path
from typing import TypeAlias

sys.dont_write_bytecode = True
SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from elasticity_machine_strict_mixed_interval import sqrt_fraction_interval
from poisson_machine_strict_interval import (
    interval_div,
    interval_mul,
    interval_record,
    pi_interval,
)


Polynomial3: TypeAlias = dict[tuple[int, int, int], Fraction]


def add(*polynomials: Polynomial3) -> Polynomial3:
    result: Polynomial3 = {}
    for polynomial in polynomials:
        for power, value in polynomial.items():
            result[power] = result.get(power, Fraction(0)) + value
    return {power: value for power, value in result.items() if value}


def scale(polynomial: Polynomial3, factor: Fraction) -> Polynomial3:
    return {power: factor * value for power, value in polynomial.items() if factor * value}


def multiply(first: Polynomial3, second: Polynomial3) -> Polynomial3:
    result: Polynomial3 = {}
    for first_power, first_value in first.items():
        for second_power, second_value in second.items():
            power = tuple(a + b for a, b in zip(first_power, second_power))
            result[power] = result.get(power, Fraction(0)) + first_value * second_value
    return {power: value for power, value in result.items() if value}


def derivative(polynomial: Polynomial3, axis: int) -> Polynomial3:
    result: Polynomial3 = {}
    for powers, value in polynomial.items():
        exponent = powers[axis]
        if exponent:
            new_power = list(powers)
            new_power[axis] -= 1
            result[tuple(new_power)] = exponent * value
    return result


def integral(polynomial: Polynomial3) -> Fraction:
    return sum(
        value / Fraction(px + 1) / Fraction(py + 1) / Fraction(pz + 1)
        for (px, py, pz), value in polynomial.items()
    )


def square_integral(polynomial: Polynomial3) -> Fraction:
    return integral(multiply(polynomial, polynomial))


def solution() -> Polynomial3:
    one_dim = ({0: Fraction(0), 1: Fraction(1), 2: Fraction(-1)})
    result: Polynomial3 = {}
    for px, vx in one_dim.items():
        for py, vy in one_dim.items():
            for pz, vz in one_dim.items():
                value = vx * vy * vz
                if value:
                    result[(px, py, pz)] = value
    return result


def exact_energy_and_forcing(curvature: Fraction) -> tuple[Fraction, Fraction]:
    u = solution()
    u_xi, u_eta, u_zeta = (derivative(u, axis) for axis in range(3))
    # h=s*eta*(1-eta)*zeta*(1-zeta), with a=h_eta and b=h_zeta.
    h: Polynomial3 = {
        (0, 1, 1): curvature,
        (0, 2, 1): -curvature,
        (0, 1, 2): -curvature,
        (0, 2, 2): curvature,
    }
    a = derivative(h, 1)
    b = derivative(h, 2)
    grad_x = u_xi
    grad_y = add(u_eta, scale(multiply(a, u_xi), Fraction(-1)))
    grad_z = add(u_zeta, scale(multiply(b, u_xi), Fraction(-1)))
    energy_squared = sum(square_integral(component) for component in (grad_x, grad_y, grad_z))
    laplacian = add(
        derivative(grad_x, 0),
        scale(multiply(a, derivative(grad_y, 0)), Fraction(-1)),
        derivative(grad_y, 1),
        scale(multiply(b, derivative(grad_z, 0)), Fraction(-1)),
        derivative(grad_z, 2),
    )
    forcing = scale(laplacian, Fraction(-1))
    return energy_squared, square_integral(forcing)


def build_case(curvature: Fraction, alpha: Fraction) -> dict[str, object]:
    energy_squared, forcing_squared = exact_energy_and_forcing(curvature)
    factor = (1 - alpha, 1 - alpha)
    # |h_eta|,|h_zeta| <= s/4, hence ||J||_F^2 <= 3+s^2/8.
    jacobian_bound = sqrt_fraction_interval(3 + curvature * curvature / 8)
    reference_constant = interval_div(
        (Fraction(1), Fraction(1)),
        interval_mul(pi_interval(), sqrt_fraction_interval(Fraction(3))),
    )
    physical_constant = interval_mul(reference_constant, jacobian_bound)
    majorant = interval_mul(
        factor,
        interval_mul(physical_constant, sqrt_fraction_interval(forcing_squared)),
    )
    true_error = interval_mul(factor, sqrt_fraction_interval(energy_squared))
    return {
        "curvature": str(curvature),
        "alpha": str(alpha),
        "non_affine": curvature != 0,
        "energy_squared_fraction": str(energy_squared),
        "forcing_squared_fraction": str(forcing_squared),
        "majorant": interval_record(majorant),
        "true_error": interval_record(true_error),
        "strict_cover": majorant[1] >= true_error[1],
    }


def run(config: dict[str, object]) -> tuple[dict[str, object], list[dict[str, object]]]:
    cases = [
        build_case(Fraction(curvature), Fraction(alpha))
        for curvature in config["curvatures"]
        for alpha in config["alphas"]
    ]
    return {
        "protocol": config["protocol"],
        "case_count": len(cases),
        "non_affine_case_count": sum(bool(case["non_affine"]) for case in cases),
        "all_machine_strict_covers": all(bool(case["strict_cover"]) for case in cases),
        "max_curvature": max(float(Fraction(case["curvature"])) for case in cases),
        "arithmetic": "exact rational polynomial algebra and outward rational enclosures",
        "quadrature": "none",
        "claim_scope": config["claim_scope"],
        "non_claim": "No industrial-scale 3D cost or generic CAD enclosure is claimed.",
    }, cases


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--config",
        type=Path,
        default=Path("experiments/configs/poisson_machine_strict_curved_3d_suite_2026-08-01.json"),
    )
    parser.add_argument(
        "--summary-out",
        type=Path,
        default=Path("experiments/results/poisson_machine_strict_curved_3d_summary.json"),
    )
    parser.add_argument(
        "--rows-out",
        type=Path,
        default=Path("experiments/results/poisson_machine_strict_curved_3d_rows.csv"),
    )
    args = parser.parse_args()
    raw = args.config.read_bytes()
    config = json.loads(raw)
    summary, cases = run(config)
    summary["config_sha256"] = hashlib.sha256(raw).hexdigest()
    if not summary["all_machine_strict_covers"]:
        raise AssertionError("a 3D curved case failed")
    args.summary_out.parent.mkdir(parents=True, exist_ok=True)
    args.summary_out.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    rows = [
        {
            "curvature": case["curvature"],
            "alpha": case["alpha"],
            "non_affine": case["non_affine"],
            "majorant_upper": case["majorant"]["upper_decimal_outward"],
            "true_error_upper": case["true_error"]["upper_decimal_outward"],
            "strict_cover": case["strict_cover"],
        }
        for case in cases
    ]
    with args.rows_out.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
