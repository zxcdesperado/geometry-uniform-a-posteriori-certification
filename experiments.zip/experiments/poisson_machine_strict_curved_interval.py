"""Machine-rigorous functional majorants on a polynomial curved geometry."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import sys
from fractions import Fraction
from pathlib import Path

sys.dont_write_bytecode = True
SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from elasticity_machine_strict_mixed_interval import (
    Polynomial,
    poly_add,
    poly_derivative,
    poly_integral_unit_square,
    poly_multiply,
    poly_scale,
    sqrt_fraction_interval,
)
from poisson_machine_strict_interval import (
    Interval,
    interval_div,
    interval_mul,
    interval_record,
    pi_interval,
)


def polynomial_solution() -> Polynomial:
    # xi*(1-xi)*eta*(1-eta)
    return {
        (1, 1): Fraction(1),
        (2, 1): Fraction(-1),
        (1, 2): Fraction(-1),
        (2, 2): Fraction(1),
    }


def square_integral(polynomial: Polynomial) -> Fraction:
    return poly_integral_unit_square(poly_multiply(polynomial, polynomial))


def exact_energy_and_forcing(curvature: Fraction) -> tuple[Fraction, Fraction]:
    """Return exact squared norms of grad_x u and f=-Delta_x u."""
    u = polynomial_solution()
    u_xi = poly_derivative(u, 0)
    u_eta = poly_derivative(u, 1)
    # J=[[1,a],[0,1]], a=s(1-2 eta), det J=1.
    a: Polynomial = {(0, 0): curvature, (0, 1): -2 * curvature}
    grad_x = u_xi
    grad_y = poly_add(u_eta, poly_scale(poly_multiply(a, u_xi), Fraction(-1)))
    energy_squared = square_integral(grad_x) + square_integral(grad_y)
    # d/dx=d/dxi and d/dy=-a*d/dxi+d/deta.
    divergence_gradient = poly_add(
        poly_derivative(grad_x, 0),
        poly_scale(poly_multiply(a, poly_derivative(grad_y, 0)), Fraction(-1)),
        poly_derivative(grad_y, 1),
    )
    forcing = poly_scale(divergence_gradient, Fraction(-1))
    forcing_squared = square_integral(forcing)
    return energy_squared, forcing_squared


def build_case(curvature: Fraction, alpha: Fraction) -> dict[str, object]:
    if curvature < 0 or curvature >= 1:
        raise ValueError("suite uses 0 <= curvature < 1")
    if not 0 < alpha < 1:
        raise ValueError("alpha must lie in (0,1)")
    energy_squared, forcing_squared = exact_energy_and_forcing(curvature)
    energy_norm = sqrt_fraction_interval(energy_squared)
    forcing_norm = sqrt_fraction_interval(forcing_squared)
    jacobian_frobenius_bound = sqrt_fraction_interval(2 + curvature * curvature)
    reference_friedrichs = interval_div(
        (Fraction(1), Fraction(1)),
        interval_mul(pi_interval(), sqrt_fraction_interval(Fraction(2))),
    )
    physical_friedrichs = interval_mul(
        reference_friedrichs, jacobian_frobenius_bound
    )
    factor: Interval = (1 - alpha, 1 - alpha)
    majorant = interval_mul(factor, interval_mul(physical_friedrichs, forcing_norm))
    true_error = interval_mul(factor, energy_norm)
    cover = majorant[1] >= true_error[1]
    return {
        "curvature": str(curvature),
        "alpha": str(alpha),
        "map": "F_s(xi,eta)=(xi+s*eta*(1-eta),eta)",
        "jacobian_determinant": "1 exactly",
        "non_affine": curvature != 0,
        "energy_squared_fraction": str(energy_squared),
        "forcing_squared_fraction": str(forcing_squared),
        "physical_friedrichs_upper": interval_record(physical_friedrichs),
        "majorant": interval_record(majorant),
        "true_energy_error": interval_record(true_error),
        "strict_cover": cover,
        "arithmetic": "exact Fraction polynomial algebra and outward rational enclosures",
        "quadrature": "none",
        "geometry_error": "none; the polynomial map and det(J)=1 are exact",
    }


def run(config: dict[str, object]) -> tuple[dict[str, object], list[dict[str, object]]]:
    cases = [
        build_case(Fraction(curvature), Fraction(alpha))
        for curvature in config["curvatures"]
        for alpha in config["alphas"]
    ]
    summary = {
        "protocol": config["protocol"],
        "case_count": len(cases),
        "non_affine_case_count": sum(bool(case["non_affine"]) for case in cases),
        "all_machine_strict_covers": all(bool(case["strict_cover"]) for case in cases),
        "max_curvature": max(float(Fraction(case["curvature"])) for case in cases),
        "claim_scope": config["claim_scope"],
        "non_claim": (
            "This manufactured exact-geometry suite does not enclose a generic "
            "CAD geometry approximation or ordinary floating-point mesh pipeline."
        ),
    }
    return summary, cases


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--config",
        type=Path,
        default=Path("experiments/configs/poisson_machine_strict_curved_suite_2026-08-01.json"),
    )
    parser.add_argument(
        "--summary-out",
        type=Path,
        default=Path("experiments/results/poisson_machine_strict_curved_summary.json"),
    )
    parser.add_argument(
        "--rows-out",
        type=Path,
        default=Path("experiments/results/poisson_machine_strict_curved_rows.csv"),
    )
    args = parser.parse_args()
    raw_config = args.config.read_bytes()
    config = json.loads(raw_config)
    summary, cases = run(config)
    summary["config_sha256"] = hashlib.sha256(raw_config).hexdigest()
    if not summary["all_machine_strict_covers"]:
        raise AssertionError("a curved-geometry majorant failed")
    args.summary_out.parent.mkdir(parents=True, exist_ok=True)
    args.summary_out.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    rows = [
        {
            "curvature": case["curvature"],
            "alpha": case["alpha"],
            "non_affine": case["non_affine"],
            "majorant_upper": case["majorant"]["upper_decimal_outward"],
            "true_error_upper": case["true_energy_error"]["upper_decimal_outward"],
            "strict_cover": case["strict_cover"],
        }
        for case in cases
    ]
    with args.rows_out.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
