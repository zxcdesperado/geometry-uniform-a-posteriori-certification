"""Machine-rigorous functional-majorant interval using exact rationals.

The manufactured problem is -Delta u = f on the unit square with homogeneous
Dirichlet data,

    u = sin(pi x) sin(pi y),       v = alpha u,       y = grad(v).

For alpha in (0, 1), the flux mismatch vanishes and the equilibrium part of
the Repin majorant equals the energy error.  Pi is enclosed by the Machin
formula with alternating-series remainders and sqrt(2) by rational bisection.
All interval endpoints are Fraction objects.  Decimal strings are produced
only for human-readable reporting and are outward rounded.
"""

from __future__ import annotations

import argparse
import csv
import json
from decimal import Decimal, ROUND_CEILING, ROUND_FLOOR, localcontext
from fractions import Fraction
from pathlib import Path


Interval = tuple[Fraction, Fraction]


def atan_reciprocal_interval(q: int, terms: int) -> Interval:
    """Enclose atan(1/q) with an alternating Taylor partial sum."""
    if q <= 1 or terms <= 0:
        raise ValueError("q must exceed one and terms must be positive")
    total = Fraction(0)
    for k in range(terms):
        term = Fraction(1, (2 * k + 1) * q ** (2 * k + 1))
        total += term if k % 2 == 0 else -term
    next_term = Fraction(1, (2 * terms + 1) * q ** (2 * terms + 1))
    if terms % 2 == 0:
        return total, total + next_term
    return total - next_term, total


def pi_interval() -> Interval:
    """Machin enclosure pi = 16 atan(1/5) - 4 atan(1/239)."""
    a_lo, a_hi = atan_reciprocal_interval(5, 80)
    b_lo, b_hi = atan_reciprocal_interval(239, 20)
    return 16 * a_lo - 4 * b_hi, 16 * a_hi - 4 * b_lo


def sqrt_two_interval(steps: int = 384) -> Interval:
    """Enclose sqrt(2) by exact rational bisection."""
    lo, hi = Fraction(1), Fraction(2)
    for _ in range(steps):
        midpoint = (lo + hi) / 2
        if midpoint * midpoint < 2:
            lo = midpoint
        else:
            hi = midpoint
    return lo, hi


def interval_mul(a: Interval, b: Interval) -> Interval:
    if a[0] < 0 or b[0] < 0:
        raise ValueError("this experiment only multiplies nonnegative intervals")
    return a[0] * b[0], a[1] * b[1]


def interval_div(a: Interval, b: Interval) -> Interval:
    if a[0] < 0 or b[0] <= 0:
        raise ValueError("division requires nonnegative numerator and positive divisor")
    return a[0] / b[1], a[1] / b[0]


def interval_square(a: Interval) -> Interval:
    if a[0] < 0:
        raise ValueError("squaring is implemented only for nonnegative intervals")
    return a[0] * a[0], a[1] * a[1]


def decimal_endpoint(value: Fraction, digits: int, rounding: str) -> str:
    with localcontext() as context:
        context.prec = digits
        context.rounding = rounding
        return format(Decimal(value.numerator) / Decimal(value.denominator), "f")


def interval_record(interval: Interval, digits: int = 50) -> dict[str, str]:
    lo, hi = interval
    return {
        "lower_fraction": f"{lo.numerator}/{lo.denominator}",
        "upper_fraction": f"{hi.numerator}/{hi.denominator}",
        "lower_decimal_outward": decimal_endpoint(lo, digits, ROUND_FLOOR),
        "upper_decimal_outward": decimal_endpoint(hi, digits, ROUND_CEILING),
    }


def build_result(alpha: Fraction) -> dict[str, object]:
    if not 0 < alpha < 1:
        raise ValueError("alpha must lie strictly between zero and one")
    factor: Interval = (1 - alpha, 1 - alpha)
    pi = pi_interval()
    sqrt_two = sqrt_two_interval()

    # ||f + div y|| = (1-alpha) pi^2 and C_F = 1/(pi sqrt(2)).
    equilibrium = interval_mul(factor, interval_square(pi))
    friedrichs = interval_div((Fraction(1), Fraction(1)), interval_mul(pi, sqrt_two))
    majorant = interval_mul(equilibrium, friedrichs)

    # The exact energy error is (1-alpha) pi/sqrt(2).
    true_energy_error = interval_div(interval_mul(factor, pi), sqrt_two)
    strict_cover = majorant[1] >= true_energy_error[1]
    positive_gap = majorant[1] - true_energy_error[1]

    return {
        "benchmark": "unit_square_poisson_machine_rigorous_interval",
        "manufactured_solution": "u=sin(pi*x)*sin(pi*y)",
        "reconstruction": f"v=({alpha.numerator}/{alpha.denominator})*u",
        "flux": "y=grad(v)",
        "arithmetic": (
            "All mathematical endpoints use Python Fraction exact rational "
            "arithmetic; decimal strings are outward rounded."
        ),
        "quadrature": "none; all norms are integrated analytically",
        "pi_enclosure": interval_record(pi),
        "sqrt_two_enclosure": interval_record(sqrt_two),
        "equilibrium_norm_enclosure": interval_record(equilibrium),
        "friedrichs_constant_enclosure": interval_record(friedrichs),
        "flux_mismatch": interval_record((Fraction(0), Fraction(0))),
        "functional_majorant_enclosure": interval_record(majorant),
        "true_energy_error_enclosure": interval_record(true_energy_error),
        "strict_upper_covers_true_error_upper": strict_cover,
        "certified_positive_gap": interval_record((positive_gap, positive_gap)),
        "claim_scope": (
            "This is a machine-rigorous analytic manufactured case. It does "
            "not certify ordinary floating-point quadrature in other backends."
        ),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--alpha-numerator", type=int, default=7)
    parser.add_argument("--alpha-denominator", type=int, default=10)
    parser.add_argument(
        "--summary-out",
        type=Path,
        default=Path(
            "certified_geometry_neural_operators/experiments/results/"
            "poisson_machine_strict_interval_summary.json"
        ),
    )
    parser.add_argument(
        "--rows-out",
        type=Path,
        default=Path(
            "certified_geometry_neural_operators/experiments/results/"
            "poisson_machine_strict_interval_rows.csv"
        ),
    )
    args = parser.parse_args()

    result = build_result(Fraction(args.alpha_numerator, args.alpha_denominator))
    if not result["strict_upper_covers_true_error_upper"]:
        raise AssertionError("the rational upper-bound check failed")

    args.summary_out.parent.mkdir(parents=True, exist_ok=True)
    args.summary_out.write_text(json.dumps(result, indent=2), encoding="utf-8")

    majorant = result["functional_majorant_enclosure"]
    error = result["true_energy_error_enclosure"]
    row = {
        "majorant_lower": majorant["lower_decimal_outward"],
        "majorant_upper": majorant["upper_decimal_outward"],
        "true_error_lower": error["lower_decimal_outward"],
        "true_error_upper": error["upper_decimal_outward"],
        "strict_cover": result["strict_upper_covers_true_error_upper"],
    }
    args.rows_out.parent.mkdir(parents=True, exist_ok=True)
    with args.rows_out.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(row))
        writer.writeheader()
        writer.writerow(row)

    print(
        "machine-rigorous majorant upper = "
        f"{majorant['upper_decimal_outward']}"
    )
    print(f"true-error upper = {error['upper_decimal_outward']}")
    print("strict rational coverage = true")
    print(f"wrote {args.summary_out}")
    print(f"wrote {args.rows_out}")


if __name__ == "__main__":
    main()
