"""Certify a lightweight neural surrogate on a geometry/coefficient PDE pool.

The previous manufactured sweeps used exact, interpolated, or prescribed
perturbed conforming outputs.  This script adds the first trained black-box
surrogate.  A small PyTorch MLP maps the parameter vector

    p = (theta1, theta2, mu)

to P1 nodal values on the reference mesh.  The prediction is then treated like
any other conforming neural-operator output: boundary values are projected to
zero, residual and flux-jump indicators are evaluated, and the non-Galerkin
finite-dimensional residual `delta_h` is included.

This is still a compact benchmark, not the final architecture comparison.  Its
role is to test the certification wrapper on an actually trained surrogate.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import random
import statistics
import sys
from dataclasses import dataclass
from itertools import product
from pathlib import Path
from typing import Any

import numpy as np
import torch
from scipy.sparse import coo_matrix

sys.dont_write_bytecode = True
SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from poisson_deformed_square_coeff_sweep import (
    coefficient_b_mu,
    div_b_mu_grad_constant,
    finite_difference_divergence_field,
)
from poisson_deformed_square_pullback_p1 import (
    RefMesh,
    basis_gradients,
    build_edges,
    discrete_residual_norm,
    dunavant_degree5,
    edge_gauss_2,
    jacobian_min_on_grid,
    make_mesh,
    outward_normal,
    solve_dirichlet,
    triangle_area,
    triangle_gradients,
)


PARAM_NAMES = ("theta1", "theta2", "mu")


@dataclass(frozen=True)
class ParamCase:
    theta1: float
    theta2: float
    mu: float


def exact_value_param(point: np.ndarray, case: ParamCase) -> float:
    xi, eta = point
    sx = math.sin(math.pi * xi)
    sy = math.sin(math.pi * eta)
    base = sx * sy
    mod = (
        1.0
        + 0.35 * case.mu * xi * (1.0 - xi) * eta * (1.0 - eta)
        + 1.5 * case.theta1 * math.sin(2.0 * math.pi * xi) * sy
        + 1.5 * case.theta2 * sx * math.sin(2.0 * math.pi * eta)
    )
    return base * mod


def exact_grad_param(point: np.ndarray, case: ParamCase) -> np.ndarray:
    xi, eta = point
    sx = math.sin(math.pi * xi)
    sy = math.sin(math.pi * eta)
    cx = math.cos(math.pi * xi)
    cy = math.cos(math.pi * eta)
    s2x = math.sin(2.0 * math.pi * xi)
    s2y = math.sin(2.0 * math.pi * eta)
    c2x = math.cos(2.0 * math.pi * xi)
    c2y = math.cos(2.0 * math.pi * eta)

    base = sx * sy
    grad_base = np.array([math.pi * cx * sy, math.pi * sx * cy], dtype=float)
    mod = (
        1.0
        + 0.35 * case.mu * xi * (1.0 - xi) * eta * (1.0 - eta)
        + 1.5 * case.theta1 * s2x * sy
        + 1.5 * case.theta2 * sx * s2y
    )
    grad_mod = np.array(
        [
            0.35 * case.mu * (1.0 - 2.0 * xi) * eta * (1.0 - eta)
            + 3.0 * math.pi * case.theta1 * c2x * sy
            + 1.5 * math.pi * case.theta2 * cx * s2y,
            0.35 * case.mu * xi * (1.0 - xi) * (1.0 - 2.0 * eta)
            + 1.5 * math.pi * case.theta1 * s2x * cy
            + 3.0 * math.pi * case.theta2 * sx * c2y,
        ],
        dtype=float,
    )
    return grad_base * mod + base * grad_mod


def exact_flux_param(point: np.ndarray, case: ParamCase) -> np.ndarray:
    return (
        coefficient_b_mu(point, case.theta1, case.theta2, case.mu)
        @ exact_grad_param(point, case)
    )


def forcing_hat_param(point: np.ndarray, case: ParamCase) -> float:
    return -finite_difference_divergence_field(lambda x: exact_flux_param(x, case), point)


def assemble(mesh: RefMesh, case: ParamCase) -> tuple[Any, np.ndarray]:
    rows: list[int] = []
    cols: list[int] = []
    data: list[float] = []
    rhs = np.zeros(len(mesh.nodes))
    quad = dunavant_degree5()
    for tri in mesh.triangles:
        coords = mesh.nodes[tri]
        area = triangle_area(coords)
        grads = basis_gradients(coords)
        local_k = np.zeros((3, 3), dtype=float)
        local_b = np.zeros(3, dtype=float)
        for weight, bary in quad:
            lam = np.array(bary)
            q = lam @ coords
            bmat = coefficient_b_mu(q, case.theta1, case.theta2, case.mu)
            f_q = forcing_hat_param(q, case)
            for a in range(3):
                local_b[a] += weight * area * f_q * lam[a]
                for b in range(3):
                    local_k[a, b] += weight * area * float(
                        grads[a] @ bmat @ grads[b]
                    )
        for a in range(3):
            rhs[tri[a]] += local_b[a]
            for b in range(3):
                rows.append(int(tri[a]))
                cols.append(int(tri[b]))
                data.append(float(local_k[a, b]))
    stiffness = coo_matrix(
        (data, (rows, cols)), shape=(len(mesh.nodes), len(mesh.nodes))
    )
    return stiffness.tocsr(), rhs


def nodal_exact(mesh: RefMesh, case: ParamCase) -> np.ndarray:
    return np.array([exact_value_param(x, case) for x in mesh.nodes], dtype=float)


def residual_estimator(
    mesh: RefMesh, values: np.ndarray, case: ParamCase
) -> tuple[float, float, float]:
    grads = triangle_gradients(mesh, values)
    quad = dunavant_degree5()
    volume = 0.0
    for tri_idx, tri in enumerate(mesh.triangles):
        coords = mesh.nodes[tri]
        area = triangle_area(coords)
        edge_lengths = [
            np.linalg.norm(coords[1] - coords[0]),
            np.linalg.norm(coords[2] - coords[1]),
            np.linalg.norm(coords[0] - coords[2]),
        ]
        h_k = max(edge_lengths)
        int_r2 = 0.0
        grad_uh = grads[tri_idx]
        for weight, bary in quad:
            q = np.array(bary) @ coords
            residual = forcing_hat_param(q, case) + div_b_mu_grad_constant(
                q, grad_uh, case.theta1, case.theta2, case.mu
            )
            int_r2 += weight * area * residual**2
        volume += h_k**2 * int_r2

    jump = 0.0
    for edge, adj in build_edges(mesh.triangles).items():
        if len(adj) != 2:
            continue
        n0 = outward_normal(mesh, adj[0], edge)
        n1 = outward_normal(mesh, adj[1], edge)
        pa = mesh.nodes[edge[0]]
        pb = mesh.nodes[edge[1]]
        edge_length = float(np.linalg.norm(pb - pa))
        int_jump2 = 0.0
        for weight, t in edge_gauss_2():
            q = (1.0 - t) * pa + t * pb
            bmat = coefficient_b_mu(q, case.theta1, case.theta2, case.mu)
            flux0 = bmat @ grads[adj[0]]
            flux1 = bmat @ grads[adj[1]]
            flux_jump = float(np.dot(flux0, n0) + np.dot(flux1, n1))
            int_jump2 += weight * edge_length * flux_jump**2
        jump += edge_length * int_jump2
    return math.sqrt(volume + jump), math.sqrt(volume), math.sqrt(jump)


def energy_error(mesh: RefMesh, values: np.ndarray, case: ParamCase) -> float:
    uh_grads = triangle_gradients(mesh, values)
    quad = dunavant_degree5()
    err2 = 0.0
    for tri_idx, tri in enumerate(mesh.triangles):
        coords = mesh.nodes[tri]
        area = triangle_area(coords)
        for weight, bary in quad:
            q = np.array(bary) @ coords
            diff = exact_grad_param(q, case) - uh_grads[tri_idx]
            bmat = coefficient_b_mu(q, case.theta1, case.theta2, case.mu)
            err2 += weight * area * float(diff @ bmat @ diff)
    return math.sqrt(err2)


def solve_case(n: int, case: ParamCase) -> tuple[RefMesh, Any, np.ndarray, np.ndarray]:
    mesh = make_mesh(n, case.theta1, case.theta2)
    stiffness, rhs = assemble(mesh, case)
    values = solve_dirichlet(stiffness, rhs, mesh.boundary)
    return mesh, stiffness, rhs, values


def make_cases(
    theta1_values: list[float], theta2_values: list[float], mu_values: list[float]
) -> list[ParamCase]:
    return [
        ParamCase(theta1, theta2, mu)
        for theta1, theta2, mu in product(theta1_values, theta2_values, mu_values)
    ]


def normalize_params(params: np.ndarray, mean: np.ndarray, scale: np.ndarray) -> np.ndarray:
    return (params - mean) / scale


def build_model(num_nodes: int, width: int) -> torch.nn.Module:
    return torch.nn.Sequential(
        torch.nn.Linear(3, width),
        torch.nn.Tanh(),
        torch.nn.Linear(width, width),
        torch.nn.Tanh(),
        torch.nn.Linear(width, num_nodes),
    )


def train_model(
    train_x: np.ndarray,
    train_y: np.ndarray,
    epochs: int,
    width: int,
    lr: float,
    seed: int,
) -> tuple[torch.nn.Module, list[dict[str, float]]]:
    torch.manual_seed(seed)
    torch.set_num_threads(1)
    model = build_model(train_y.shape[1], width)
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    x = torch.tensor(train_x, dtype=torch.float32)
    y = torch.tensor(train_y, dtype=torch.float32)
    history: list[dict[str, float]] = []
    report_every = max(1, epochs // 10)
    for epoch in range(1, epochs + 1):
        opt.zero_grad(set_to_none=True)
        pred = model(x)
        loss = torch.mean((pred - y) ** 2)
        loss.backward()
        opt.step()
        if epoch == 1 or epoch == epochs or epoch % report_every == 0:
            history.append({"epoch": float(epoch), "mse": float(loss.detach().cpu())})
    return model, history


def predict_values(
    model: torch.nn.Module, param: np.ndarray, boundary: np.ndarray
) -> np.ndarray:
    with torch.no_grad():
        values = model(torch.tensor(param[None, :], dtype=torch.float32))[0].cpu().numpy()
    values = np.asarray(values, dtype=float)
    values[boundary] = 0.0
    return values


def score_error_correlation(rows: list[dict[str, float]]) -> float | None:
    scores = [row["eta_total"] for row in rows]
    errors = [row["energy_error"] for row in rows]
    if len(rows) < 2 or min(scores) == max(scores) or min(errors) == max(errors):
        return None
    return statistics.correlation(scores, errors)


def select_top(rows: list[dict[str, float]], budget: int) -> list[int]:
    order = sorted(range(len(rows)), key=lambda i: (-rows[i]["eta_total"], rows[i]["case_id"]))
    return order[: min(budget, len(order))]


def select_random(
    rows: list[dict[str, float]], budget: int, repeats: int, seed: int
) -> dict[str, float]:
    rng = random.Random(seed)
    fractions = []
    captures = []
    total = sum(row["energy_error"] ** 2 for row in rows)
    worst = max(row["energy_error"] for row in rows)
    for _ in range(repeats):
        selected = rng.sample(range(len(rows)), min(budget, len(rows)))
        selected_mass = sum(rows[i]["energy_error"] ** 2 for i in selected)
        fractions.append(selected_mass / total if total > 0.0 else 0.0)
        captures.append(
            any(math.isclose(rows[i]["energy_error"], worst, rel_tol=1.0e-12) for i in selected)
        )
    return {
        "selected_error_sq_fraction_mean": statistics.fmean(fractions),
        "selected_error_sq_fraction_std": statistics.pstdev(fractions),
        "worst_case_capture_rate": sum(captures) / len(captures),
    }


def summarize_acquisition(
    rows: list[dict[str, float]], budgets: list[int], repeats: int, seed: int
) -> list[dict[str, Any]]:
    total = sum(row["energy_error"] ** 2 for row in rows)
    worst = max(row["energy_error"] for row in rows)
    out: list[dict[str, Any]] = []
    for budget in budgets:
        selected = select_top(rows, budget)
        selected_mass = sum(rows[i]["energy_error"] ** 2 for i in selected)
        out.append(
            {
                "strategy": "max_estimator",
                "budget": budget,
                "selected_error_sq_fraction": selected_mass / total if total > 0.0 else 0.0,
                "worst_case_captured": any(
                    math.isclose(rows[i]["energy_error"], worst, rel_tol=1.0e-12)
                    for i in selected
                ),
                "selected_case_ids": [int(rows[i]["case_id"]) for i in selected],
            }
        )
        random_stats = select_random(rows, budget, repeats, seed + budget)
        out.append({"strategy": "random_mean", "budget": budget, **random_stats})
    return out


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = sorted({key for row in rows for key in row.keys()})
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(
                {
                    key: " ".join(str(x) for x in value)
                    if isinstance(value, list)
                    else value
                    for key, value in row.items()
                }
            )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--level", type=int, default=10)
    parser.add_argument("--epochs", type=int, default=900)
    parser.add_argument("--width", type=int, default=64)
    parser.add_argument("--lr", type=float, default=2.0e-3)
    parser.add_argument("--seed", type=int, default=31415)
    parser.add_argument("--random-repeats", type=int, default=200)
    parser.add_argument("--budgets", nargs="+", type=int, default=[4, 8, 12])
    parser.add_argument(
        "--out",
        type=Path,
        default=Path(
            "certified_geometry_neural_operators/experiments/results/"
            "poisson_parametric_mlp_certification_summary.json"
        ),
    )
    parser.add_argument(
        "--csv-out",
        type=Path,
        default=Path(
            "certified_geometry_neural_operators/experiments/results/"
            "poisson_parametric_mlp_certification_rows.csv"
        ),
    )
    args = parser.parse_args()

    random.seed(args.seed)
    np.random.seed(args.seed)
    train_cases = make_cases([-0.12, 0.0, 0.12], [-0.09, 0.0, 0.09], [0.0, 0.5, 1.0])
    test_cases = make_cases(
        [-0.10, -0.033, 0.033, 0.10],
        [-0.075, -0.025, 0.025, 0.075],
        [0.125, 0.375, 0.625, 0.875],
    )

    train_params_raw = np.array(
        [[case.theta1, case.theta2, case.mu] for case in train_cases], dtype=float
    )
    param_mean = train_params_raw.mean(axis=0)
    param_scale = train_params_raw.std(axis=0)
    param_scale[param_scale == 0.0] = 1.0

    train_targets = []
    train_jac_mins = []
    for case in train_cases:
        mesh, _, _, values = solve_case(args.level, case)
        train_targets.append(values)
        train_jac_mins.append(jacobian_min_on_grid(case.theta1, case.theta2))
    train_y = np.vstack(train_targets)
    train_x = normalize_params(train_params_raw, param_mean, param_scale)

    model, history = train_model(
        train_x, train_y, epochs=args.epochs, width=args.width, lr=args.lr, seed=args.seed
    )

    rows: list[dict[str, float]] = []
    for case_id, case in enumerate(test_cases):
        mesh, stiffness, rhs, fe_values = solve_case(args.level, case)
        x_raw = np.array([case.theta1, case.theta2, case.mu], dtype=float)
        x_norm = normalize_params(x_raw, param_mean, param_scale)
        pred = predict_values(model, x_norm, mesh.boundary)
        eta_res, eta_volume, eta_jump = residual_estimator(mesh, pred, case)
        delta = discrete_residual_norm(stiffness, rhs, pred, mesh.boundary)
        eta_total = math.sqrt(eta_res**2 + delta**2)
        err = energy_error(mesh, pred, case)
        fe_err = energy_error(mesh, fe_values, case)
        nodal_rel_l2 = float(
            np.linalg.norm(pred - fe_values) / max(np.linalg.norm(fe_values), 1.0e-14)
        )
        rows.append(
            {
                "case_id": float(case_id),
                "theta1": case.theta1,
                "theta2": case.theta2,
                "mu": case.mu,
                "jacobian_min_grid": jacobian_min_on_grid(case.theta1, case.theta2),
                "energy_error": err,
                "fe_energy_error": fe_err,
                "eta_res": eta_res,
                "eta_volume": eta_volume,
                "eta_jump": eta_jump,
                "delta_h": delta,
                "eta_total": eta_total,
                "effectivity_total": eta_total / err if err > 0.0 else float("inf"),
                "nodal_rel_l2_to_fe": nodal_rel_l2,
            }
        )

    coverage = [row["eta_total"] >= row["energy_error"] for row in rows]
    effectivities = [row["effectivity_total"] for row in rows]
    errors = [row["energy_error"] for row in rows]
    deltas = [row["delta_h"] for row in rows]
    acquisition = summarize_acquisition(rows, args.budgets, args.random_repeats, args.seed)

    result: dict[str, Any] = {
        "config": {
            "level": args.level,
            "epochs": args.epochs,
            "width": args.width,
            "lr": args.lr,
            "seed": args.seed,
            "param_names": list(PARAM_NAMES),
            "train_cases": len(train_cases),
            "test_cases": len(test_cases),
            "budgets": args.budgets,
            "random_repeats": args.random_repeats,
        },
        "training": {
            "history": history,
            "final_mse": history[-1]["mse"],
            "jacobian_min_train": min(train_jac_mins),
        },
        "test_summary": {
            "num_cases": len(rows),
            "jacobian_min_test": min(row["jacobian_min_grid"] for row in rows),
            "raw_coverage_rate": sum(coverage) / len(coverage),
            "max_raw_underestimate": max(
                max(0.0, row["energy_error"] - row["eta_total"]) for row in rows
            ),
            "energy_error_mean": statistics.fmean(errors),
            "energy_error_max": max(errors),
            "delta_h_mean": statistics.fmean(deltas),
            "delta_h_max": max(deltas),
            "effectivity_min": min(effectivities),
            "effectivity_mean": statistics.fmean(effectivities),
            "effectivity_median": statistics.median(effectivities),
            "effectivity_max": max(effectivities),
            "score_error_correlation": score_error_correlation(rows),
        },
        "acquisition": acquisition,
        "rows": rows,
    }

    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, indent=2, sort_keys=True), encoding="utf-8")
    write_csv(args.csv_out, rows)

    summary = result["test_summary"]
    print(f"train_cases {len(train_cases)}")
    print(f"test_cases {len(rows)}")
    print(f"final_train_mse {history[-1]['mse']:.6e}")
    print(f"coverage {summary['raw_coverage_rate']:.3f}")
    print(
        "effectivity",
        f"[{summary['effectivity_min']:.3f},"
        f"{summary['effectivity_mean']:.3f},{summary['effectivity_max']:.3f}]",
    )
    print(f"delta_h_max {summary['delta_h_max']:.6e}")
    corr = summary["score_error_correlation"]
    print("score_error_correlation", "None" if corr is None else f"{corr:.6f}")
    for row in acquisition:
        if row["strategy"] == "max_estimator":
            print(
                f"max_estimator budget={row['budget']} "
                f"selected_error_sq={row['selected_error_sq_fraction']:.3f} "
                f"worst_case_capture={row['worst_case_captured']}"
            )
    print(f"wrote {args.out}")
    print(f"wrote {args.csv_out}")


if __name__ == "__main__":
    main()
