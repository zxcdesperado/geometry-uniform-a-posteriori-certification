"""Audit RT functional majorants on genuinely trained neural-operator outputs.

The experiment matrix was predeclared and frozen before the reported runs in
``experiments/configs/cost_benchmark_base_config.json``.  It reuses the
existing lightweight grid-FNO-style and GINO-style architectures, trains three
fixed seeds on the existing affine manufactured Poisson family, and evaluates
the frozen predictors on in-distribution, mild-OOD, and strong-OOD pools.

The RT calculations use the same exact-arithmetic upper-sum formulas as the
existing higher-order audit.  This program uses ordinary floating arithmetic;
coverage is therefore an empirical audit and not a machine-enclosed interval.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import random
import statistics
import sys
import time
from dataclasses import dataclass
from itertools import product
from pathlib import Path
from typing import Any, Callable

import numpy as np
import torch
from scipy.stats import pearsonr, spearmanr
from skfem.element import ElementTriRT1, ElementTriRT2

sys.dont_write_bytecode = True
SCRIPT_DIR = Path(__file__).resolve().parent
ROOT = SCRIPT_DIR.parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from higher_order_flux_majorant import (
    fit_element_polynomials,
    optimize_flux,
    taylor_upper_sum,
)
from independent_flux_audit import (
    assemble_problem,
    build_mesh,
    coefficient,
    energy_error_diagnostic,
    element_geometry,
    exact_reference_value,
    is_dirichlet_node,
    solve_problem,
    triangle_rule,
)
from optimized_rt0_majorant import (
    majorant_optimized_flux,
    quadratic_components,
    taylor_functional_upper_sum,
)
from poisson_gino_style_operator_certification import (
    predict_values as predict_gino,
    train_model as train_gino,
)
from poisson_grid_fno_operator_certification import (
    predict_values as predict_fno,
    train_model as train_fno,
)


@dataclass(frozen=True)
class ParametricCase:
    split: str
    case_id: int
    shear: float
    stretch: float
    contrast: float


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def cases_from_grid(split: str, grid: dict[str, list[float]]) -> list[ParametricCase]:
    return [
        ParametricCase(split, index, float(shear), float(stretch), float(contrast))
        for index, (shear, stretch, contrast) in enumerate(
            product(grid["shears"], grid["stretches"], grid["contrasts"])
        )
    ]


def affine_feature_grid(mesh: Any, contrast: float) -> np.ndarray:
    side = int(round(math.sqrt(len(mesh.reference_nodes))))
    reference = mesh.reference_nodes.reshape(side, side, 2)
    physical = mesh.physical_nodes.reshape(side, side, 2)
    displacement = physical - reference
    material = coefficient(reference, contrast)
    determinant = np.full((side, side), mesh.stretch, dtype=float)
    return np.stack(
        [
            reference[:, :, 0],
            reference[:, :, 1],
            physical[:, :, 0],
            physical[:, :, 1],
            displacement[:, :, 0],
            displacement[:, :, 1],
            material,
            determinant,
            np.full((side, side), mesh.shear, dtype=float),
            np.full((side, side), mesh.stretch, dtype=float),
            np.full((side, side), math.log10(contrast), dtype=float),
        ],
        axis=0,
    )


def audit_normalized_adjacency(mesh: Any) -> np.ndarray:
    """Match the existing GINO-style graph normalization for ``AuditMesh``."""
    num_nodes = len(mesh.reference_nodes)
    adjacency = np.eye(num_nodes, dtype=float)
    for triangle in mesh.elements:
        vertices = [int(vertex) for vertex in triangle]
        for first, second in (
            (vertices[0], vertices[1]),
            (vertices[1], vertices[2]),
            (vertices[2], vertices[0]),
        ):
            adjacency[first, second] = 1.0
            adjacency[second, first] = 1.0
    degree = adjacency.sum(axis=1)
    inverse_sqrt = 1.0 / np.sqrt(np.maximum(degree, 1.0))
    return inverse_sqrt[:, None] * adjacency * inverse_sqrt[None, :]


def solve_label(level: int, shear: float, stretch: float, contrast: float) -> tuple[Any, np.ndarray]:
    mesh = build_mesh(level, shear, stretch)
    matrix, load = assemble_problem(mesh, "dirichlet", contrast)
    fixed = is_dirichlet_node(mesh, "dirichlet")
    return mesh, solve_problem(matrix, load, fixed)


def median_elapsed(function: Callable[[], Any], repeats: int) -> tuple[float, Any]:
    timings: list[float] = []
    result: Any = None
    for _ in range(repeats):
        start = time.perf_counter()
        result = function()
        timings.append(time.perf_counter() - start)
    return statistics.median(timings), result


def cold_fe_time(level: int, case: ParametricCase, repeats: int) -> float:
    mesh = build_mesh(level, case.shear, case.stretch)
    fixed = is_dirichlet_node(mesh, "dirichlet")

    def assemble_and_solve() -> np.ndarray:
        matrix, load = assemble_problem(mesh, "dirichlet", case.contrast)
        return solve_problem(matrix, load, fixed)

    elapsed, _ = median_elapsed(assemble_and_solve, repeats)
    return elapsed


def l2_error_diagnostic(mesh: Any, values: np.ndarray) -> tuple[float, float]:
    """Return physical-domain L2 error and exact-solution L2 norm."""
    _, _, areas = element_geometry(mesh)
    error_sq = 0.0
    exact_sq = 0.0
    for element_index, triangle in enumerate(mesh.elements):
        reference = mesh.reference_nodes[triangle]
        local_values = values[triangle]
        for weight, barycentric in triangle_rule():
            bary = np.asarray(barycentric, dtype=float)
            point = bary @ reference
            exact = float(exact_reference_value(point))
            approximate = float(np.dot(bary, local_values))
            scale = float(weight * areas[element_index])
            error_sq += scale * (exact - approximate) ** 2
            exact_sq += scale * exact**2
    return math.sqrt(max(error_sq, 0.0)), math.sqrt(max(exact_sq, 0.0))


def prepare_training_data(
    level: int,
    grid: dict[str, list[float]],
) -> tuple[np.ndarray, np.ndarray, Any]:
    features: list[np.ndarray] = []
    targets: list[np.ndarray] = []
    mesh0 = None
    for shear, stretch, contrast in product(
        grid["shears"], grid["stretches"], grid["contrasts"]
    ):
        mesh, values = solve_label(level, float(shear), float(stretch), float(contrast))
        if mesh0 is None:
            mesh0 = mesh
        features.append(affine_feature_grid(mesh, float(contrast)))
        targets.append(values)
    if mesh0 is None:
        raise RuntimeError("empty predeclared training grid")
    return np.stack(features), np.stack(targets), mesh0


def train_operator(
    architecture: str,
    raw_features: np.ndarray,
    targets: np.ndarray,
    mesh: Any,
    config: dict[str, Any],
    seed: int,
) -> dict[str, Any]:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.set_num_threads(1)
    epochs = int(config["epochs"])
    lr = float(config["learning_rate"])
    start = time.perf_counter()
    if architecture == "existing_grid_fno_style":
        mean = raw_features.mean(axis=(0, 2, 3), keepdims=True)
        scale = raw_features.std(axis=(0, 2, 3), keepdims=True)
        scale[scale == 0.0] = 1.0
        normalized = (raw_features - mean) / scale
        side = int(round(math.sqrt(targets.shape[1])))
        target_grids = targets.reshape(len(targets), 1, side, side)
        fno = config["fno"]
        model, history = train_fno(
            normalized,
            target_grids,
            epochs,
            int(fno["width"]),
            int(fno["modes"]),
            int(fno["layers"]),
            lr,
            seed,
        )

        def predictor(feature_grid: np.ndarray, boundary: np.ndarray) -> np.ndarray:
            normalized_feature = (feature_grid - mean[0]) / scale[0]
            return predict_fno(model, normalized_feature, boundary)

        metadata = {
            "width": int(fno["width"]),
            "modes": int(fno["modes"]),
            "layers": int(fno["layers"]),
        }
    elif architecture == "existing_gino_style":
        node_features = np.moveaxis(raw_features, 1, -1).reshape(
            raw_features.shape[0], -1, raw_features.shape[1]
        )
        mean = node_features.mean(axis=(0, 1), keepdims=True)
        scale = node_features.std(axis=(0, 1), keepdims=True)
        scale[scale == 0.0] = 1.0
        normalized = (node_features - mean) / scale
        adjacency = audit_normalized_adjacency(mesh)
        gino = config["gino_style"]
        model, history = train_gino(
            normalized,
            targets,
            adjacency,
            epochs,
            int(gino["width"]),
            int(gino["layers"]),
            lr,
            seed,
        )

        def predictor(feature_grid: np.ndarray, boundary: np.ndarray) -> np.ndarray:
            nodes = np.moveaxis(feature_grid, 0, -1).reshape(-1, feature_grid.shape[0])
            normalized_feature = (nodes - mean[0]) / scale[0]
            return predict_gino(model, normalized_feature, adjacency, boundary)

        metadata = {
            "width": int(gino["width"]),
            "layers": int(gino["layers"]),
            "graph_nodes": int(adjacency.shape[0]),
        }
    else:
        raise ValueError(f"unknown predeclared architecture: {architecture}")
    training_seconds = time.perf_counter() - start
    return {
        "model": model,
        "predictor": predictor,
        "history": history,
        "training_seconds": training_seconds,
        "metadata": metadata,
    }


def rt0_certificate(
    mesh: Any,
    prediction: np.ndarray,
    contrast: float,
    depth: int,
    quadrature_order: int,
    reweight_iterations: int,
) -> tuple[float, float, dict[str, float]]:
    start = time.perf_counter()
    components = quadratic_components(
        mesh, prediction, "dirichlet", contrast, quadrature_order
    )
    flux = majorant_optimized_flux(
        mesh,
        "dirichlet",
        components,
        reweight_iterations=reweight_iterations,
    )
    upper = taylor_functional_upper_sum(
        mesh, "dirichlet", contrast, depth, flux
    )
    elapsed = time.perf_counter() - start
    return float(upper["functional_majorant"]), elapsed, upper


def higher_order_certificate(
    mesh: Any,
    prediction: np.ndarray,
    contrast: float,
    element: Any,
    depth: int,
    quadrature_order: int,
    reweight_iterations: int,
) -> tuple[float, float, dict[str, float]]:
    start = time.perf_counter()
    optimized = optimize_flux(
        mesh,
        prediction,
        "dirichlet",
        contrast,
        element,
        quadrature_order,
        reweight_iterations,
    )
    polynomial = fit_element_polynomials(mesh, optimized)
    upper = taylor_upper_sum(
        mesh, prediction, "dirichlet", contrast, polynomial, depth
    )
    elapsed = time.perf_counter() - start
    upper["max_value_polynomial_fit_defect"] = float(
        polynomial["max_value_fit_defect"]
    )
    upper["max_divergence_polynomial_fit_defect"] = float(
        polynomial["max_divergence_fit_defect"]
    )
    upper["max_fitted_interior_normal_jump"] = float(
        polynomial["max_fitted_interior_normal_jump"]
    )
    return float(upper["functional_majorant"]), elapsed, upper


def finite_correlation(x: list[float], y: list[float], kind: str) -> float | None:
    if len(x) < 3 or len(set(x)) < 2 or len(set(y)) < 2:
        return None
    value = pearsonr(x, y).statistic if kind == "pearson" else spearmanr(x, y).statistic
    return None if not math.isfinite(float(value)) else float(value)


def summarize_group(rows: list[dict[str, Any]]) -> dict[str, Any]:
    effects = [float(row["effectivity"]) for row in rows]
    errors = [float(row["energy_error"]) for row in rows]
    majorants = [float(row["majorant"]) for row in rows]
    ratios = [float(row["certification_over_fe_cold"]) for row in rows]
    return {
        "cases": len(rows),
        "energy_error_mean": statistics.fmean(errors),
        "energy_error_median": statistics.median(errors),
        "energy_error_max": max(errors),
        "effectivity_mean": statistics.fmean(effects),
        "effectivity_median": statistics.median(effects),
        "effectivity_q95": float(np.quantile(effects, 0.95)),
        "effectivity_max": max(effects),
        "floating_coverage_rate": statistics.fmean(float(row["floating_coverage"]) for row in rows),
        "certification_seconds_median": statistics.median(
            float(row["certification_seconds"]) for row in rows
        ),
        "certification_over_fe_cold_mean": statistics.fmean(ratios),
        "certification_over_fe_cold_median": statistics.median(ratios),
        "certification_faster_than_fe_cold_rate": statistics.fmean(
            float(ratio < 1.0) for ratio in ratios
        ),
        "error_majorant_pearson": finite_correlation(errors, majorants, "pearson"),
        "error_majorant_spearman": finite_correlation(errors, majorants, "spearman"),
        "log_error_majorant_pearson": finite_correlation(
            [math.log(max(value, 1.0e-30)) for value in errors],
            [math.log(max(value, 1.0e-30)) for value in majorants],
            "pearson",
        ),
        "max_value_polynomial_fit_defect": max(
            float(row.get("max_value_polynomial_fit_defect", 0.0)) for row in rows
        ),
        "max_divergence_polynomial_fit_defect": max(
            float(row.get("max_divergence_polynomial_fit_defect", 0.0)) for row in rows
        ),
        "max_fitted_interior_normal_jump": max(
            float(row.get("max_fitted_interior_normal_jump", 0.0)) for row in rows
        ),
    }


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = sorted({key for row in rows for key in row})
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--config",
        type=Path,
        default=Path("experiments/configs/cost_benchmark_base_config.json"),
    )
    parser.add_argument("--quick", action="store_true")
    parser.add_argument("--cost-repeats", type=int, default=3)
    parser.add_argument(
        "--summary-out",
        type=Path,
        default=Path("experiments/results/trained_operator_rt_majorant_summary.json"),
    )
    parser.add_argument(
        "--rows-out",
        type=Path,
        default=Path("experiments/results/trained_operator_rt_majorant_rows.csv"),
    )
    parser.add_argument(
        "--training-out",
        type=Path,
        default=Path("experiments/results/trained_operator_rt_training_rows.csv"),
    )
    parser.add_argument(
        "--checkpoint-dir",
        type=Path,
        default=Path("experiments/results/trained_operator_rt_checkpoints"),
    )
    args = parser.parse_args()
    full_config = json.loads(args.config.read_text(encoding="utf-8"))
    config = dict(full_config["trained_output_rt"])
    if args.quick:
        config["epochs"] = min(5, int(config["epochs"]))
        config["seeds"] = [int(config["seeds"][0])]
        for split in config["splits"].values():
            split["shears"] = split["shears"][:1]
            split["stretches"] = split["stretches"][:1]
            split["contrasts"] = split["contrasts"][:1]

    level = int(config["level"])
    raw_train_features, train_targets, train_mesh = prepare_training_data(
        level, config["training_grid"]
    )
    test_cases = [
        case
        for split, grid in config["splits"].items()
        for case in cases_from_grid(split, grid)
    ]
    rows: list[dict[str, Any]] = []
    training_rows: list[dict[str, Any]] = []
    args.checkpoint_dir.mkdir(parents=True, exist_ok=True)
    total_start = time.perf_counter()
    for architecture in config["models"]:
        for seed in config["seeds"]:
            trained = train_operator(
                architecture,
                raw_train_features,
                train_targets,
                train_mesh,
                config,
                int(seed),
            )
            checkpoint = args.checkpoint_dir / f"{architecture}_seed{seed}.pt"
            torch.save(trained["model"].state_dict(), checkpoint)
            training_rows.append(
                {
                    "architecture": architecture,
                    "seed": int(seed),
                    "epochs": int(config["epochs"]),
                    "final_mse": float(trained["history"][-1]["mse"]),
                    "training_seconds": float(trained["training_seconds"]),
                    "parameter_count": int(
                        sum(parameter.numel() for parameter in trained["model"].parameters())
                    ),
                    "checkpoint": checkpoint.as_posix(),
                    "checkpoint_sha256": sha256(checkpoint),
                }
            )
            print(
                f"trained {architecture} seed={seed} "
                f"mse={trained['history'][-1]['mse']:.3e} "
                f"seconds={trained['training_seconds']:.2f}",
                flush=True,
            )
            for case in test_cases:
                mesh, _ = solve_label(
                    level, case.shear, case.stretch, case.contrast
                )
                boundary = is_dirichlet_node(mesh, "dirichlet")
                features = affine_feature_grid(mesh, case.contrast)
                prediction_seconds, prediction = median_elapsed(
                    lambda: trained["predictor"](features, boundary),
                    5,
                )
                prediction = np.asarray(prediction, dtype=float)
                prediction[boundary] = 0.0
                error = energy_error_diagnostic(mesh, prediction, case.contrast)
                exact_energy_norm = energy_error_diagnostic(
                    mesh, np.zeros_like(prediction), case.contrast
                )
                l2_error, exact_l2_norm = l2_error_diagnostic(mesh, prediction)
                fe_seconds = cold_fe_time(level, case, args.cost_repeats)
                method_results = []
                method_results.append(
                    (
                        "optimized_RT0_edge",
                        *rt0_certificate(
                            mesh,
                            prediction,
                            case.contrast,
                            int(config["depth"]),
                            int(config["quadrature_order"]),
                            int(config["reweight_iterations"]),
                        ),
                    )
                )
                for method, element in (
                    ("scikit_fem_ElementTriRT1_lowest_order", ElementTriRT1()),
                    ("scikit_fem_ElementTriRT2_next_order", ElementTriRT2()),
                ):
                    method_results.append(
                        (
                            method,
                            *higher_order_certificate(
                                mesh,
                                prediction,
                                case.contrast,
                                element,
                                int(config["depth"]),
                                int(config["quadrature_order"]),
                                int(config["reweight_iterations"]),
                            ),
                        )
                    )
                for method, majorant, certification_seconds, details in method_results:
                    rows.append(
                        {
                            "architecture": architecture,
                            "seed": int(seed),
                            "split": case.split,
                            "case_id": int(case.case_id),
                            "shear": case.shear,
                            "stretch": case.stretch,
                            "contrast": case.contrast,
                            "method": method,
                            "energy_error": error,
                            "exact_energy_norm": exact_energy_norm,
                            "relative_energy_error": error
                            / max(exact_energy_norm, 1.0e-30),
                            "l2_error": l2_error,
                            "exact_l2_norm": exact_l2_norm,
                            "relative_l2_error": l2_error
                            / max(exact_l2_norm, 1.0e-30),
                            "majorant": majorant,
                            "effectivity": majorant / max(error, 1.0e-30),
                            "floating_coverage": bool(majorant + 1.0e-10 >= error),
                            "prediction_seconds": prediction_seconds,
                            "certification_seconds": certification_seconds,
                            "prediction_plus_certification_seconds": prediction_seconds
                            + certification_seconds,
                            "direct_fe_cold_seconds": fe_seconds,
                            "certification_over_fe_cold": certification_seconds
                            / fe_seconds,
                            "prediction_plus_certification_over_fe_cold": (
                                prediction_seconds + certification_seconds
                            )
                            / fe_seconds,
                            "flux_mismatch_upper": float(details["flux_mismatch_upper"]),
                            "equilibrium_residual_upper": float(
                                details["equilibrium_residual_upper"]
                            ),
                            "neumann_residual_upper": float(
                                details["neumann_residual_upper"]
                            ),
                            "max_fitted_interior_normal_jump": float(
                                details.get("max_fitted_interior_normal_jump", 0.0)
                            ),
                        }
                    )
                print(
                    f"{architecture} seed={seed} split={case.split} "
                    f"case={case.case_id} error={error:.3e} "
                    + " ".join(
                        f"{method.split('_')[0]}={majorant / max(error, 1.0e-30):.2f}"
                        for method, majorant, _, _ in method_results
                    ),
                    flush=True,
                )

    grouped: dict[str, Any] = {}
    for architecture in config["models"]:
        grouped[architecture] = {}
        for split in config["splits"]:
            grouped[architecture][split] = {}
            for method in sorted({row["method"] for row in rows}):
                group = [
                    row
                    for row in rows
                    if row["architecture"] == architecture
                    and row["split"] == split
                    and row["method"] == method
                ]
                grouped[architecture][split][method] = summarize_group(group)

    overall_methods = {
        method: summarize_group([row for row in rows if row["method"] == method])
        for method in sorted({row["method"] for row in rows})
    }
    coverage_failures = [row for row in rows if not row["floating_coverage"]]
    worst_effectivities = sorted(
        rows, key=lambda row: float(row["effectivity"]), reverse=True
    )[:12]
    report = {
        "benchmark": "predeclared_trained_operator_rt_majorant",
        "claim_boundary": {
            "models": "existing lightweight grid-FNO-style and GINO-style architectures; no new architecture",
            "pde_geometry": "existing affine manufactured Poisson family",
            "strictness": "upper-sum formulas are theorem-backed in exact arithmetic; these are ordinary floating evaluations, not machine-enclosed intervals",
            "coverage": "coverage is audited against the manufactured energy error and is not used for calibration",
            "cost": "certification timing includes flux-system assembly, solve, polynomial reconstruction, and upper-sum evaluation; training time is reported separately",
        },
        "config_file": args.config.as_posix(),
        "config_sha256": sha256(args.config),
        "config": config,
        "training": training_rows,
        "unique_training_parameters": int(len(train_targets)),
        "unique_test_parameters_by_split": {
            split: int(sum(case.split == split for case in test_cases))
            for split in config["splits"]
        },
        "grouped": grouped,
        "overall_methods": overall_methods,
        "coverage_failure_count": len(coverage_failures),
        "coverage_failures": coverage_failures,
        "worst_effectivity_rows": worst_effectivities,
        "elapsed_seconds": time.perf_counter() - total_start,
        "rows": rows,
    }
    args.summary_out.parent.mkdir(parents=True, exist_ok=True)
    args.summary_out.write_text(
        json.dumps(report, indent=2, sort_keys=True), encoding="utf-8"
    )
    write_csv(args.rows_out, rows)
    write_csv(args.training_out, training_rows)
    print(f"coverage_failures {len(coverage_failures)}")
    for method, summary in overall_methods.items():
        print(
            method,
            f"median={summary['effectivity_median']:.3f}",
            f"q95={summary['effectivity_q95']:.3f}",
            f"max={summary['effectivity_max']:.3f}",
            f"coverage={summary['floating_coverage_rate']:.3f}",
            f"cost/FE={summary['certification_over_fe_cold_median']:.3f}",
        )
    print(f"wrote {args.summary_out}")
    print(f"wrote {args.rows_out}")
    print(f"wrote {args.training_out}")


if __name__ == "__main__":
    main()
