"""Train and audit a faithful GINO on geometry-level ID/OOD cohorts."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import random
import statistics
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Hashable

import numpy as np
import torch
from skfem.element import ElementTriRT1, ElementTriRT2

sys.dont_write_bytecode = True
SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from faithful_gino_operator import FaithfulGINO, grid_edge_sets, parameter_count, relative_energy_loss
from higher_order_flux_majorant import optimize_flux
from independent_flux_audit import (
    build_mesh,
    coefficient,
    element_geometry,
    energy_error_diagnostic,
    is_dirichlet_node,
)
from native_rt_witness import native_quadrature_result
from trained_operator_rt_majorant import solve_label


@dataclass(frozen=True)
class GeometryCase:
    split: str
    geometry_id: int
    shear: float
    stretch: float
    contrast: float


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def latin_hypercube_cases(
    split: str,
    count: int,
    bounds: dict[str, list[float]],
    seed: int,
) -> list[GeometryCase]:
    generator = np.random.default_rng(seed)
    unit = np.empty((count, 3), dtype=float)
    for dimension in range(3):
        permutation = generator.permutation(count)
        unit[:, dimension] = (permutation + generator.random(count)) / count
    shear = bounds["shear"][0] + unit[:, 0] * (bounds["shear"][1] - bounds["shear"][0])
    stretch = bounds["stretch"][0] + unit[:, 1] * (
        bounds["stretch"][1] - bounds["stretch"][0]
    )
    log_low, log_high = math.log10(bounds["contrast"][0]), math.log10(bounds["contrast"][1])
    contrast = 10.0 ** (log_low + unit[:, 2] * (log_high - log_low))
    return [
        GeometryCase(split, index, float(shear[index]), float(stretch[index]), float(contrast[index]))
        for index in range(count)
    ]


def case_arrays(mesh: Any, contrast: float) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    reference = np.asarray(mesh.reference_nodes, dtype=float)
    physical = np.asarray(mesh.physical_nodes, dtype=float)
    displacement = physical - reference
    material = coefficient(reference, contrast)[:, None]
    determinant = np.full((len(reference), 1), float(mesh.stretch), dtype=float)
    globals_ = np.column_stack(
        [
            np.full(len(reference), float(mesh.shear)),
            np.full(len(reference), float(mesh.stretch)),
            np.full(len(reference), math.log10(float(contrast))),
        ]
    )
    features = np.column_stack([reference, displacement, material, determinant, globals_])
    boundary = is_dirichlet_node(mesh, "dirichlet")
    free_mask = (~boundary).astype(float)
    return features, physical, reference, free_mask


def prepare_cases(level: int, cases: list[GeometryCase]) -> dict[str, Any]:
    features = []
    physical = []
    references = []
    masks = []
    targets = []
    for case in cases:
        mesh, values = solve_label(level, case.shear, case.stretch, case.contrast)
        feature, coordinates, reference, mask = case_arrays(mesh, case.contrast)
        features.append(feature)
        physical.append(coordinates)
        references.append(reference)
        masks.append(mask)
        targets.append(values)
    return {
        "features": np.stack(features),
        "physical": np.stack(physical),
        "reference": np.stack(references),
        "mask": np.stack(masks),
        "target": np.stack(targets),
    }


def normalize(train: dict[str, Any], data: dict[str, Any] | None = None) -> tuple[dict[str, Any], np.ndarray, np.ndarray]:
    mean = train["features"].mean(axis=(0, 1), keepdims=True)
    scale = train["features"].std(axis=(0, 1), keepdims=True)
    scale[scale == 0.0] = 1.0
    source = train if data is None else data
    output = dict(source)
    output["features"] = (source["features"] - mean) / scale
    return output, mean, scale


def to_tensor(data: np.ndarray) -> torch.Tensor:
    return torch.tensor(data, dtype=torch.float32)


def train_gino(
    data: dict[str, Any],
    config: dict[str, Any],
    seed: int,
) -> tuple[FaithfulGINO, list[dict[str, float]], float]:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.set_num_threads(int(config.get("torch_threads", 1)))
    side = int(round(math.sqrt(data["features"].shape[1])))
    model = FaithfulGINO(
        data["features"].shape[2],
        side,
        width=int(config["width"]),
        modes=int(config["modes"]),
        layers=int(config["layers"]),
        kernel_hidden=int(config["kernel_hidden"]),
        kernel_sigma=float(config["kernel_sigma"]),
    )
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=float(config["learning_rate"]), weight_decay=float(config["weight_decay"])
    )
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        optimizer, T_max=int(config["epochs"]), eta_min=float(config["learning_rate"]) * 0.05
    )
    tensors = {key: to_tensor(value) for key, value in data.items()}
    horizontal, vertical, diagonal = grid_edge_sets(side)
    batch_size = int(config["batch_size"])
    generator = np.random.default_rng(seed)
    history = []
    start = time.perf_counter()
    for epoch in range(1, int(config["epochs"]) + 1):
        permutation = generator.permutation(len(tensors["target"]))
        epoch_loss = 0.0
        batches = 0
        model.train()
        for offset in range(0, len(permutation), batch_size):
            index = permutation[offset : offset + batch_size]
            optimizer.zero_grad(set_to_none=True)
            prediction = model(
                tensors["features"][index],
                tensors["physical"][index],
                tensors["reference"][index],
                tensors["physical"][index],
                tensors["mask"][index],
            )
            loss = relative_energy_loss(
                prediction,
                tensors["target"][index],
                horizontal,
                vertical,
                diagonal,
                float(config["gradient_loss_weight"]),
            )
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), float(config["gradient_clip"]))
            optimizer.step()
            epoch_loss += float(loss.detach())
            batches += 1
        scheduler.step()
        if epoch == 1 or epoch == int(config["epochs"]) or epoch % int(config["report_every"]) == 0:
            history.append({
                "epoch": float(epoch),
                "loss": epoch_loss / max(batches, 1),
                "learning_rate": float(scheduler.get_last_lr()[0]),
            })
    return model, history, time.perf_counter() - start


def predict(model: FaithfulGINO, data: dict[str, np.ndarray]) -> np.ndarray:
    model.eval()
    with torch.no_grad():
        values = model(
            to_tensor(data["features"]),
            to_tensor(data["physical"]),
            to_tensor(data["reference"]),
            to_tensor(data["physical"]),
            to_tensor(data["mask"]),
        )
    return values.cpu().numpy().astype(float)


def discrete_energy_norm(mesh: Any, values: np.ndarray, contrast: float) -> float:
    """Energy norm of a P1 field; affine material integration is exact at centroids."""
    _, gradients, areas = element_geometry(mesh)
    field_gradients = np.einsum("ti,tij->tj", values[mesh.elements], gradients)
    centroids = np.mean(mesh.reference_nodes[mesh.elements], axis=1)
    material = coefficient(centroids, contrast)
    return math.sqrt(
        max(float(np.sum(areas * material * np.sum(field_gradients**2, axis=1))), 0.0)
    )


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = sorted({key for row in rows for key in row})
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def cluster_bootstrap(
    values: dict[Hashable, list[float]], seed: int, draws: int = 5000
) -> dict[str, float]:
    """Bootstrap geometry-level medians without merging different cohorts.

    Geometry identifiers are local to each split, so the mapping key must be
    the full cohort/identifier pair (or another globally unique hashable key).
    """
    geometry_keys = sorted(values, key=repr)
    geometry_values = np.asarray(
        [statistics.fmean(values[index]) for index in geometry_keys], dtype=float
    )
    generator = np.random.default_rng(seed)
    samples = generator.choice(geometry_values, size=(draws, len(geometry_values)), replace=True)
    statistic = np.median(samples, axis=1)
    return {
        "geometry_clusters": int(len(geometry_values)),
        "estimate": float(np.median(geometry_values)),
        "lower_95": float(np.quantile(statistic, 0.025)),
        "upper_95": float(np.quantile(statistic, 0.975)),
        "draws": int(draws),
    }


def summarize(rows: list[dict[str, Any]], seed: int) -> dict[str, Any]:
    effects = [float(row["rt2_native_floating_effectivity"]) for row in rows]
    errors = [float(row["operator_relative_energy_error"]) for row in rows]
    continuous_errors = [float(row["continuous_relative_energy_error"]) for row in rows]
    clustered: dict[tuple[str, int], list[float]] = {}
    for row in rows:
        key = (str(row["split"]), int(row["geometry_id"]))
        clustered.setdefault(key, []).append(
            float(row["rt2_native_floating_effectivity"])
        )
    return {
        "predictions": len(rows),
        "unique_geometries": len(clustered),
        "operator_relative_energy_error_median": float(np.median(errors)),
        "operator_relative_energy_error_q90": float(np.quantile(errors, 0.90)),
        "operator_relative_energy_error_q95": float(np.quantile(errors, 0.95)),
        "operator_relative_energy_error_max": float(max(errors)),
        "continuous_relative_energy_error_median": float(np.median(continuous_errors)),
        "continuous_relative_energy_error_q95": float(np.quantile(continuous_errors, 0.95)),
        "fraction_below_10_percent": float(np.mean(np.asarray(errors) < 0.10)),
        "fraction_below_5_percent": float(np.mean(np.asarray(errors) < 0.05)),
        "rt2_effectivity_median": float(np.median(effects)),
        "rt2_effectivity_q90": float(np.quantile(effects, 0.90)),
        "rt2_effectivity_q95": float(np.quantile(effects, 0.95)),
        "rt2_effectivity_max": float(max(effects)),
        "rt2_effectivity_geometry_cluster_bootstrap_95": cluster_bootstrap(clustered, seed),
        "native_hdiv_membership_rate": float(np.mean([bool(row["exact_discrete_hdiv_membership"]) for row in rows])),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--config",
        type=Path,
        default=Path("experiments/configs/faithful_gino_formal_prespecified_2026-07-29.json"),
    )
    parser.add_argument("--quick", action="store_true")
    parser.add_argument("--pilot-epochs", type=int, default=None)
    parser.add_argument("--pilot-training-geometries", type=int, default=None)
    parser.add_argument("--pilot-test-geometries", type=int, default=None)
    parser.add_argument("--pilot-seeds", type=int, default=None)
    parser.add_argument("--pilot-gradient-weight", type=float, default=None)
    parser.add_argument(
        "--load-checkpoint",
        type=Path,
        default=None,
        help="Evaluate one existing checkpoint under the requested pilot cohort without retraining.",
    )
    parser.add_argument(
        "--load-checkpoint-dir",
        type=Path,
        default=None,
        help="Evaluate the matching faithful_gino_seed<seed>.pt checkpoint for every frozen seed.",
    )
    parser.add_argument(
        "--summary-out", type=Path,
        default=Path("experiments/results/true_gino_large_geometry_summary.json"),
    )
    parser.add_argument(
        "--rows-out", type=Path,
        default=Path("experiments/results/true_gino_large_geometry_rows.csv"),
    )
    parser.add_argument(
        "--training-out", type=Path,
        default=Path("experiments/results/true_gino_training_rows.csv"),
    )
    parser.add_argument(
        "--training-reference",
        type=Path,
        default=None,
        help=(
            "Existing training-provenance CSV to preserve when evaluating saved "
            "weights. Checkpoint-only evaluation cannot reconstruct optimizer loss "
            "history or the original training wall time."
        ),
    )
    parser.add_argument(
        "--checkpoint-dir", type=Path,
        default=Path("experiments/results/true_gino_checkpoints"),
    )
    args = parser.parse_args()

    document = json.loads(args.config.read_text(encoding="utf-8"))
    config = dict(document["faithful_gino"])
    if args.pilot_epochs is not None:
        config["epochs"] = int(args.pilot_epochs)
    if args.pilot_training_geometries is not None:
        config["training_geometries"] = int(args.pilot_training_geometries)
    if args.pilot_test_geometries is not None:
        config["test_geometries_per_split"] = int(args.pilot_test_geometries)
    if args.pilot_seeds is not None:
        config["seeds"] = list(config["seeds"][: int(args.pilot_seeds)])
    if args.pilot_gradient_weight is not None:
        config["gradient_loss_weight"] = float(args.pilot_gradient_weight)
    if args.quick:
        config["epochs"] = min(2, int(config["epochs"]))
        config["seeds"] = [int(config["seeds"][0])]
        config["training_geometries"] = min(4, int(config["training_geometries"]))
        config["test_geometries_per_split"] = min(2, int(config["test_geometries_per_split"]))
        config["reweight_iterations"] = min(2, int(config["reweight_iterations"]))

    training_cases = latin_hypercube_cases(
        "train", int(config["training_geometries"]), config["training_bounds"], int(config["geometry_seed"])
    )
    test_cases = []
    for split_index, (split, bounds) in enumerate(config["test_bounds"].items()):
        test_cases.extend(
            latin_hypercube_cases(
                split,
                int(config["test_geometries_per_split"]),
                bounds,
                int(config["geometry_seed"]) + 101 * (split_index + 1),
            )
        )
    raw_train = prepare_cases(int(config["level"]), training_cases)
    train, mean, scale = normalize(raw_train)
    raw_test = prepare_cases(int(config["level"]), test_cases)
    test, _, _ = normalize(raw_train, raw_test)

    rows = []
    training_rows = []
    training_reference: dict[int, dict[str, str]] = {}
    if args.training_reference is not None:
        if not args.training_reference.is_file():
            raise FileNotFoundError(args.training_reference)
        with args.training_reference.open(newline="", encoding="utf-8") as handle:
            for reference_row in csv.DictReader(handle):
                training_reference[int(reference_row["seed"])] = reference_row
    args.checkpoint_dir.mkdir(parents=True, exist_ok=True)
    total_start = time.perf_counter()
    for seed in config["seeds"]:
        if args.load_checkpoint is None and args.load_checkpoint_dir is None:
            model, history, training_seconds = train_gino(train, config, int(seed))
            checkpoint = args.checkpoint_dir / f"faithful_gino_seed{seed}.pt"
            torch.save(
                {
                    "model_state": model.state_dict(),
                    "feature_mean": mean,
                    "feature_scale": scale,
                    "config": config,
                },
                checkpoint,
            )
        else:
            checkpoint = (
                args.load_checkpoint
                if args.load_checkpoint is not None
                else args.load_checkpoint_dir / f"faithful_gino_seed{seed}.pt"
            )
            if not checkpoint.is_file():
                raise FileNotFoundError(checkpoint)
            payload = torch.load(checkpoint, map_location="cpu", weights_only=True)
            side = int(round(math.sqrt(train["features"].shape[1])))
            model = FaithfulGINO(
                train["features"].shape[2],
                side,
                width=int(config["width"]),
                modes=int(config["modes"]),
                layers=int(config["layers"]),
                kernel_hidden=int(config["kernel_hidden"]),
                kernel_sigma=float(config["kernel_sigma"]),
            )
            model.load_state_dict(payload["model_state"])
            mean = np.asarray(payload["feature_mean"])
            scale = np.asarray(payload["feature_scale"])
            test, _, _ = normalize(
                {**raw_train, "features": (raw_train["features"] - mean) / scale},
                raw_test,
            )
            test["features"] = (raw_test["features"] - mean) / scale
            reference_row = training_reference.get(int(seed))
            history = [
                {
                    "loss": (
                        float(reference_row["final_loss"])
                        if reference_row is not None
                        else math.nan
                    )
                }
            ]
            training_seconds = (
                float(reference_row["training_seconds"])
                if reference_row is not None
                else 0.0
            )
        training_rows.append({
            "seed": int(seed),
            "epochs": int(config["epochs"]),
            "parameter_count": parameter_count(model),
            "training_seconds": training_seconds,
            "final_loss": float(history[-1]["loss"]),
            "checkpoint": checkpoint.as_posix(),
            "checkpoint_sha256": sha256(checkpoint),
        })
        predictions = predict(model, test)
        for case, prediction, target in zip(test_cases, predictions, raw_test["target"]):
            mesh = build_mesh(int(config["level"]), case.shear, case.stretch)
            error = energy_error_diagnostic(mesh, prediction, case.contrast)
            norm = energy_error_diagnostic(mesh, np.zeros_like(prediction), case.contrast)
            operator_error = discrete_energy_norm(mesh, prediction - target, case.contrast)
            target_norm = discrete_energy_norm(mesh, target, case.contrast)
            certificates = {}
            for name, element in (("RT1", ElementTriRT1()), ("RT2", ElementTriRT2())):
                optimized = optimize_flux(
                    mesh,
                    prediction,
                    "dirichlet",
                    case.contrast,
                    element,
                    int(config["quadrature_order"]),
                    int(config["reweight_iterations"]),
                )
                certificates[name] = native_quadrature_result(optimized)
            audit = certificates["RT2"]["native_hdiv_audit"]
            rows.append({
                "seed": int(seed),
                "split": case.split,
                "geometry_id": int(case.geometry_id),
                "shear": case.shear,
                "stretch": case.stretch,
                "contrast": case.contrast,
                "energy_error": error,
                "continuous_relative_energy_error": error / max(norm, 1e-300),
                "operator_energy_error": operator_error,
                "operator_relative_energy_error": operator_error / max(target_norm, 1e-300),
                "rt1_native_floating_majorant": certificates["RT1"]["functional_majorant"],
                "rt1_native_floating_effectivity": certificates["RT1"]["functional_majorant"] / max(error, 1e-300),
                "rt2_native_floating_majorant": certificates["RT2"]["functional_majorant"],
                "rt2_native_floating_effectivity": certificates["RT2"]["functional_majorant"] / max(error, 1e-300),
                "exact_discrete_hdiv_membership": audit["exact_discrete_hdiv_membership"],
                "max_sampled_interior_normal_jump": audit["max_sampled_interior_normal_jump"],
            })
        print(
            f"faithful GINO seed={seed} params={parameter_count(model)} "
            f"training_seconds={training_seconds:.2f}",
            flush=True,
        )

    by_split = {
        split: summarize([row for row in rows if row["split"] == split], int(config["bootstrap_seed"]))
        for split in config["test_bounds"]
    }
    report = {
        "benchmark": "faithful_gino_large_geometry_native_rt_audit",
        "architecture": (
            "learned physical-point-to-grid kernel integral transform, latent spectral FNO, "
            "and learned grid-to-physical-point kernel integral transform"
        ),
        "provenance_boundary": "faithful compact GINO implementation; not claimed to be the official upstream code",
        "config_file": args.config.as_posix(),
        "config_sha256": sha256(args.config),
        "config": config,
        "training": training_rows,
        "overall": summarize(rows, int(config["bootstrap_seed"])),
        "by_split": by_split,
        "elapsed_seconds": time.perf_counter() - total_start,
        "rows": rows,
        "strictness": (
            "Native global H(div) membership is exact at the discrete-space level; the bulk "
            "RT1/RT2 majorants in this experiment use ordinary quadrature. A separate "
            "pre-specified subset receives machine-enclosed integration."
        ),
    }
    args.summary_out.parent.mkdir(parents=True, exist_ok=True)
    args.summary_out.write_text(json.dumps(report, indent=2, sort_keys=True), encoding="utf-8")
    write_csv(args.rows_out, rows)
    write_csv(args.training_out, training_rows)
    print(json.dumps(report["overall"], indent=2, sort_keys=True))
    print(f"wrote {args.summary_out}")


if __name__ == "__main__":
    main()
